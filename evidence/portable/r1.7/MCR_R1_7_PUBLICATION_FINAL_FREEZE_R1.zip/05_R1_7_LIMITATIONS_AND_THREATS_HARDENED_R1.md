# Limitations and Threats to Validity (Publication Hardened)

## Limitations (carried forward from frozen evidence, not new)

- P3/P4 are single-model studies (qwen3:8b). P5 extends to 3 model strata
  total; still a small, purposively chosen set, not a representative sample
  of deployed LLMs.
- All of P3-P5 use a synthetic DS-12-style benchmark corpus, not production
  traffic or a naturally occurring task distribution.
- P6 uses a single live SAP destination (TRL_EN) and a deliberately narrow
  3-tool live-read allowlist; only 6 cases ever reached live execution, and
  P6 has no baseline-comparison arm, so no significance claim is made for it.
- P6 client/mandant identity is not exposed by the available ADT MCP tool
  surface and is not independently verified anywhere in this program.
- P7 (long-duration / fault-injection) and P8 (independent external
  replication) have not been attempted.

## Threats to validity

- **Construct validity**: "mission success" and "correct capability
  selection" are defined by the frozen adjudication policy for each stage;
  they are internally consistent within a stage but are not externally
  validated against independent human judgment.
- **Internal validity**: All P3-P5 comparisons are sealed, pre-registered,
  and Holm-corrected, which mitigates but does not eliminate the risk of
  benchmark-specific artifacts (e.g., the descriptor-poisoning and
  candidate-crowding families in P4/P5 show the mission-qualified arm is
  *not* uniformly best -- e.g., F07/F08 in P4/P5 show comparable or
  occasionally lower success than some other arms, which the evidence
  reports honestly rather than masking).
- **External validity**: Findings are bounded to the specific benchmark
  families, models, and (for P6) the specific SAP destination and tool
  allowlist tested. No claim in this manuscript extends beyond those
  boundaries. P3-P5 significance findings do not extend to P6, and the P6
  mechanism-integrity finding does not extend to a baseline-superiority
  claim.
- **Statistical conclusion validity**: P3-P5 use Holm correction across
  primary comparisons; P6 uses deterministic (non-statistical) pass/fail
  gates appropriate to its small, fully-enumerated 60-case design rather
  than inferential statistics -- P6 is not, and is not presented as, a
  sealed statistical test.
