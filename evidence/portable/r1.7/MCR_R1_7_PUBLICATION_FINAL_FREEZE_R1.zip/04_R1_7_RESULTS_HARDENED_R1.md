# P2-P6 Results (Publication Hardened, verified from frozen evidence on disk)

No experimental numbers below differ from the prior consolidation package;
only presentation/wording has been corrected.

## P2 -- Reference implementation

- Deterministic capability-selection/binding runtime and adjudication engine
  (pytest-adjudicated), producing a verified Method Freeze
  (`METHOD_FREEZE_VERIFIED_20260902-130100`) that is the direct input to the
  P3 sealed confirmatory stage.
- No statistical hypothesis is attached to P2; it establishes that the
  runtime exists, is deterministic, and is adjudicated as correct prior to
  any sealed confirmatory execution.
- Note for the record: an earlier development-pipeline attempt on
  2026-09-01 recorded an intermediate `BLOCK_DEVELOPMENT_OR_ADJUDICATION`
  status before a later resumed closure run completed development,
  adjudication, and the validation lock, from which the verified Method
  Freeze was produced. The superseded intermediate status is not evidence of
  a defect in the frozen Method Freeze that P3 actually consumed.

## P3 -- Controlled empirical capability-selection (R2-H17), sealed confirmatory

Source: `MCR_R2E_P3_DS12_SEALED_TEST_AUTHORIZATION_AND_EXECUTION_R1`,
`R2_H17_CONFIRMATORY_RESULT_R1.json`.

- 48 sealed cases, 864 raw observations, single frozen local model (qwen3:8b).
- **A4 significantly outperformed broad exposure, semantic retrieval,
  generic progressive, and the frozen random-k control**, as supported by
  the actual P3 comparisons/results: mission-qualified progressive
  capability disclosure (A4) achieved 83.3% correct capability selection vs.
  60.4% (generic progressive, A3), 60.4% (semantic retrieval, A2), 54.2%
  (broad exposure, A0), and 10.4% (random-k, A1).
- A4 vs A3: risk difference +22.9pp, p_holm = 0.00325.
- A4 vs A2 (semantic retrieval): risk difference +22.9pp, p_holm = 0.0018.
- A4 vs A0 (broad): risk difference +29.2pp, p_holm = 0.0009.
- `r2_h17_result: "SUPPORTED"`.
- Generalization boundary stated in the frozen evidence itself: "Single
  frozen local open-weight model / one DS-12 synthetic benchmark setting;
  not a general MCP claim."

## P4 -- Adversarial failure testing (R2-H18), sealed confirmatory

Source: `MCR_R2E_P4_ADVERSARIAL_SEALED_CONFIRMATORY_EXECUTION_R1`,
`R2_H18_CONFIRMATORY_RESULT_R1.json`.

- 120 sealed cases, 1440 raw observations, 10 adversarial families (near-miss
  semantic decoy, authority conflict, tenant boundary collision, policy state
  conflict, trust downgrade, transaction mismatch, descriptor poisoning,
  candidate crowding, unavailable-provider substitution, no-valid-capability
  abstention).
- **A4 significantly outperformed the frozen A2 semantic-retrieval and A3
  generic-progressive primary comparators under the adversarial benchmark**:
  mission-qualified path (A4) achieved 90% mission success, 10%
  invalid-capability proposal rate, 100% correct abstention on the
  no-valid-capability family.
- A4 vs A3: mission-success risk difference +31.9pp, p_holm = 4.0e-05.
- A4 vs A2: mission-success risk difference +37.5pp, p_holm = 4.0e-05.
- `r2_h18_result: "SUPPORTED"`.
- Generalization boundary stated in the frozen evidence itself: "Synthetic
  adversarial capability-selection benchmark, one frozen qwen3:8b local
  runtime; not downstream enterprise execution or model-independent
  generalization."

## P5 -- Cross-model replication (R2-H20), sealed confirmatory

Source: `MCR_R2E_P5_CROSS_MODEL_SEALED_CONFIRMATORY_EXECUTION_R1` (HF02
finalization), `R2_H20_CONFIRMATORY_RESULT_R1_HF02.json`.

- 120 sealed cases x 3 model strata (M0 qwen3 anchor, M1 llama replication,
  M2 gemma replication) x 3 repetitions = 4320 raw observations.
- **The A4 advantage over A2 and A3 replicated across the three frozen model
  strata and pooled analysis**: all 3 model strata directionally positive
  for both primary comparisons (A4 vs A2, A4 vs A3); all 3 meet the full 5pp
  CI gate (minimum required: 2).
- Pooled A4 vs A3: risk difference +35.6pp, p_holm = 4.0e-05.
- Pooled A4 vs A2: risk difference +39.4pp, p_holm = 4.0e-05.
- No material model-specific reversal detected.
- `r2_h20_result: "SUPPORTED"`.
- Generalization boundary stated in the frozen evidence itself: "Cross-model
  replication of synthetic adversarial capability-selection behavior only."

## P6 -- Frozen bounded enterprise read-only proof of concept (R2-H21)

Source: `MCR_R2E_P6_SCIENTIFIC_CLOSURE_R1.zip` (verified sha256
`23847b129bcb775f44a7278c7ae8d41d4a3ed1b54268683f1f0823795e7f427b`).

**No comparative-baseline superiority claim is made for P6.** There is no
A0/A2/A3 baseline arm in the P6 corpus; P6 establishes bounded live
read-only mechanism integrity, not a significance result against baselines.

- 60-case / 10-family corpus (same frozen family structure as P3/P4 in
  spirit, purpose-built for enterprise read-only qualification).
- Live target: TRL_EN, confirmed via the official sap-adt-mcp server
  (20-tool contract, matching P6-A's frozen tool contract exactly).
- 6 cases were eligible under a deliberately narrow 3-tool live-read
  allowlist; **6/6 P6-C-eligible live reads succeeded** as real,
  non-mutating reads. `ELIGIBLE_LIVE_READ_COMPLETION=6/6`.
- The remaining 54 cases were correctly denied/abstained: 48 by frozen
  policy families (authority/tenant/policy/trust/transaction/
  provider-unavailable/no-valid-capability), 6 by allowlist-scope
  restriction specific to P6-C (these are `ALLOWLIST_SCOPE_ABSTENTION`, not
  execution failures).
- Binding-record completeness, receipt-chain completeness, and
  deterministic offline replay: 60/60 (100%) each.
- SAP writes: 0. Unauthorized executor reach: 0.
- `CLIENT_IDENTITY=NOT_EXPOSED`; `CLIENT_100_CLAIM=NOT_MADE`;
  `IDENTITY_GAP_DOCUMENTED=TRUE`. The F03 tenant value "100" is a frozen
  policy-corpus constant, not evidence of the live SAP mandant.
- `r2_h21_result: "SUPPORTED"`.
- P6 is a **frozen bounded enterprise read-only POC**, not a sealed test.
