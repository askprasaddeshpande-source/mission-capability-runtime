# Evidence Ladder / Proof Taxonomy (Publication Hardened)

| Level | Description | Status | Evidence |
|---|---|---|---|
| P0 | Literature | Background only | N/A |
| P1 | Formal / reference design | Background only | N/A |
| P2 | Reference implementation (deterministic runtime evidence) | **COMPLETED** | Deterministic capability-selection/binding engine, adjudicated via automated test suite; verified Method Freeze underpinning the P3 sealed confirmatory stage |
| P3 | Controlled empirical (capability-selection), sealed confirmatory | **COMPLETED** | R2-H17 = SUPPORTED (48 sealed cases, 864 raw observations, single frozen local model) |
| P4 | Adversarial failure testing, sealed confirmatory | **COMPLETED** | R2-H18 = SUPPORTED (120 sealed cases, 1440 raw observations, 10 adversarial families) |
| P5 | Cross-model replication, sealed confirmatory | **COMPLETED** | R2-H20 = SUPPORTED (120 sealed cases x 3 model strata, 4320 raw observations) |
| P6 | Frozen bounded enterprise read-only proof of concept (not a sealed test) | **COMPLETED** | R2-H21 = SUPPORTED (60-case corpus, 6/6 eligible live reads against authenticated TRL_EN SAP destination, 0 writes) |
| P7 | Long-duration / fault-injection simulation | NOT STARTED | Future work |
| P8 | Independent external replication | NOT STARTED | Future work |

## Ladder discipline

Each level tests a distinct property. A higher level does not retroactively
prove properties only tested at a lower or adjacent level, and stages are not
described collectively as "independent" of one another -- independent
replication is reserved for P8:

- P3 establishes that mission-qualified capability selection significantly
  outperforms naive/broad/random exposure strategies under controlled,
  non-adversarial conditions, on one model.
- P4 establishes that the mission-qualified path significantly outperforms
  the frozen semantic-retrieval and generic-progressive comparators under
  deliberately adversarial conditions (authority conflicts, tenant
  collisions, policy conflicts, trust downgrades, transaction mismatches,
  descriptor poisoning, candidate crowding, unavailable-provider
  substitution, no-valid-capability abstention), still on one model.
- P5 establishes that the P4 adversarial advantage over the same two
  comparators replicates across three frozen model strata (anchor + two
  replication models) and in the pooled analysis, not that it generalizes to
  all models or all tasks.
- P6 establishes that the qualification/binding/receipt/replay mechanics
  operate correctly and fail-closed when the executor is a real external
  system (SAP via the official ADT MCP server) under a narrow, explicitly
  bounded read-only capability allowlist. P6 makes **no comparative-baseline
  superiority claim** -- there is no A0/A2/A3 baseline arm in the P6 design.
  It is a mechanism-integrity check, not evidence that the mechanism is safe
  or effective for writes, for other enterprise systems, or at unrestricted
  scale.

Terminology discipline: P3-P5 may be described as sealed confirmatory
empirical stages. P6 must never be described as a "sealed test" -- it is a
frozen bounded enterprise read-only proof of concept. P3-P6 together are
"four escalating evidence stages," not "four independent stages."

P7 and P8 are explicitly future work. No claim in this manuscript should be
read as satisfying either.
