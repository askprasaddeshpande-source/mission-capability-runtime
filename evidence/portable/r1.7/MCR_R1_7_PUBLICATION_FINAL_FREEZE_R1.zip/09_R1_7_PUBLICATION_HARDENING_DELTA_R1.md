# R1.7 Publication Hardening Delta

Wording-only and packaging-only corrections applied to the prior R1.7
consolidation package. No experimental number, hypothesis result, or
scientific artifact was changed.

## 1. Wording corrections

- **Removed the collective claim** that "the mission-qualified path
  consistently and significantly outperforms naive, broad, random, and
  generic-progressive capability-exposure baselines" across all four stages.
  Replaced with stage-specific wording:
  - P3: A4 significantly outperformed broad exposure, semantic retrieval,
    generic progressive, and the frozen random-k control.
  - P4: A4 significantly outperformed the frozen A2 semantic-retrieval and
    A3 generic-progressive primary comparators under the adversarial
    benchmark.
  - P5: The A4 advantage over A2 and A3 replicated across the three frozen
    model strata and pooled analysis.
  - P6: No comparative-baseline superiority claim. P6 establishes bounded
    live read-only mechanism integrity only (6/6 eligible live reads, zero
    writes, complete receipts/replay).
- **Removed "sealed" as a description of P6.** P6 is now uniformly described
  as a "frozen bounded enterprise read-only proof of concept." "Sealed" is
  reserved for P3-P5.
- **Removed "independent" as a collective descriptor of the four stages.**
  The prior conclusion read "four independent, escalating, sealed evidence
  stages" -- corrected to "four escalating evidence stages" throughout
  (abstract, evidence ladder, discussion, conclusion, Section 4). "Independent
  model strata" (referring to the 3 separate models in P5) is retained where
  it correctly describes model independence, not stage independence.

## 2. Sections updated

Abstract, Contribution statement (item 4/5 wording), Section 4 (Experimental
methodology), Section 8 (P6 results), Section 9 (Evidence ladder), Section
13 (Discussion), Section 15 (Conclusion), the claim-evidence matrix, the
evidence ladder document, the results document, the limitations document,
the P6 integration notes, and the publication-claims document.

## 3. Packaging fix

The prior consolidation ZIP
(`MCR_R1_7_MANUSCRIPT_CONSOLIDATION_R1.zip`, sha256
`a607d5546134c8d9b9f238dfca0a7ae04b377cdea5762348e1e9523b9c5e5f4c`, verified
matching its recorded hash) contained a nested copy of itself as a 15323-byte
zip entry, produced because the archive was built while the output zip file
already existed inside the directory being scanned. This package is built by
writing every generated file into a clean directory
(`D:\MCP\MCR_R1_7_PUBLICATION_HARDENING_R1`) and creating the final zip
(`D:\MCP\MCR_R1_7_PUBLICATION_HARDENING_R1.zip`) **outside** that directory
first, then verifying zero self-referential entries before finalizing.

## 4. No scientific-result changes

`R2_H17_RESULT`, `R2_H18_RESULT`, `R2_H20_RESULT`, `R2_H21_RESULT`, and
`P2_STATUS` are unchanged from the verified source evidence. No SAP, MCP, or
model calls were made in producing this package.
