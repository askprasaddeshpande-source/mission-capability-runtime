# Publication-Safe Claims (R1.7, Publication Hardened)

## Primary thesis (R2-E)

MCP can expose/discover capabilities. R2-E adds mission-qualified capability
admission under constraints such as tenant, authority, policy, trust,
transaction, provider availability, and evidence requirements before
deterministic binding/execution.

- DISCOVERABLE != AUTHORIZED_TO_EXECUTE
- TRUSTED_TO_DESCRIBE != AUTHORIZED_TO_EXECUTE
- The LLM proposes semantics; a deterministic runtime binds authority.

The novelty claimed is the mission-qualified admission/binding layer, not
progressive capability discovery by itself.

## Stage claims (stage-specific, not pooled across stages)

**P3 (R2-H17, SUPPORTED)**: A4 significantly outperformed broad exposure,
semantic retrieval, generic progressive, and the frozen random-k control, as
supported by the actual P3 comparisons/results (all pairwise p_holm < 0.005),
under controlled, non-adversarial conditions on a single frozen local model.

**P4 (R2-H18, SUPPORTED)**: A4 significantly outperformed the frozen A2
semantic-retrieval and A3 generic-progressive primary comparators under the
adversarial benchmark (10 adversarial failure families, both primary
comparisons p_holm ~4e-05, 100% correct abstention on no-valid-capability
cases), on the same single frozen model.

**P5 (R2-H20, SUPPORTED)**: The A4 advantage over A2 and A3 replicated across
the three frozen model strata and pooled analysis; all 3 strata are
directionally positive and meet the pre-registered effect-size gate for both
primary comparisons, with no material model-specific reversal.

**P6 (R2-H21, SUPPORTED)**: No comparative-baseline superiority claim. P6
establishes bounded live read-only mechanism integrity -- use this wording
verbatim or with light edits that preserve meaning:

> R2-H21 was supported in the frozen bounded P6-C enterprise read-only proof
> of concept: the mission-qualified governed path completed all
> P6-C-eligible live read executions (6/6) against the authenticated TRL_EN
> SAP destination while preserving zero SAP writes, zero unauthorized
> executor reach, complete proof-carrying receipt chains, and deterministic
> offline replay across the frozen 60-case corpus. Client/mandant identity
> was not exposed by the available ADT interface and is therefore not
> independently claimed.

## Terminology rules

- P3-P5: may be called "sealed confirmatory empirical stages."
- P6: must be called a "frozen bounded enterprise read-only proof of
  concept," never a "sealed test."
- P3-P6 collectively: "four escalating evidence stages," never "four
  independent stages." Independent replication is reserved for P8 (future
  work).

## Explicitly excluded claims

The manuscript must not state or imply any of the following:

- production security proven
- SAP write safety proven
- client 100 verified
- generic tenant isolation proven
- enterprise-wide effectiveness proven
- universal SAP applicability proven
- live cross-provider failover proven
- independent external replication proven (P8)
- P6-D completed
- unrestricted model independence
- unrestricted JCS conformance
- generic security/auditability/multi-tenancy empirically proven
- P6 baseline-comparison superiority (no such comparison exists in P6)
- P3-P6 collectively described as "sealed" or as "independent stages"
