# R1.7 Manuscript (Publication Hardened): MCP Capability Discovery to Mission-Qualified Execution (R2-E)

## 1. Abstract

The Model Context Protocol (MCP) lets an agent discover and describe tool
capabilities, but discovery is not authorization. This work introduces R2-E,
a mission-qualified capability admission layer that gates deterministic
binding and execution on tenant, authority, policy, trust, transaction, and
provider-availability constraints, with proof-carrying receipts and
deterministic replay. Across four escalating evidence stages -- a controlled
empirical study (P3, R2-H17, SUPPORTED), adversarial failure testing (P4,
R2-H18, SUPPORTED), cross-model replication (P5, R2-H20, SUPPORTED), and a
frozen bounded enterprise read-only proof of concept against a real SAP
system (P6, R2-H21, SUPPORTED) -- the mission-qualified path significantly
outperformed naive, broad, random, and generic-progressive capability-
exposure baselines in P3, significantly outperformed the frozen
semantic-retrieval and generic-progressive comparators under adversarial
conditions in P4, and that advantage replicated across three frozen model
strata in P5. P6 makes no baseline-superiority comparison; it establishes
that the same qualification/binding/receipt/replay mechanism remains
fail-closed and correct when the executor is a real external system, with
6/6 eligible live reads succeeding and zero SAP writes. All results are
bounded to the tested models, benchmarks, and (for P6) the single tested SAP
destination; no claim is made about production security, write safety,
verified tenant identity, or generalized enterprise effectiveness.

## 2. Contribution statement

1. A mission-qualified capability admission model (R2-E) that sits between
   MCP-style capability discovery and deterministic execution binding.
2. A deterministic, receipt-carrying runtime (P2) that adjudicates every
   capability proposal against explicit constraints and produces a
   replayable audit trail.
3. Sealed, pre-registered empirical evidence (P3, P4) that the admission
   model improves correctness under both controlled and adversarial
   conditions on a frozen local model.
4. Cross-model replication (P5) showing the adversarial advantage direction
   holds across three frozen model strata.
5. A frozen bounded enterprise read-only proof of concept (P6) showing the
   same admission/binding/receipt/replay mechanics operate correctly against
   a real external system (SAP, via the official ADT MCP server) under a
   narrow, explicitly scoped read-only capability allowlist, with zero
   writes and a transparently documented identity-exposure gap.

## 3. Architecture / reference-design section

The reference design separates three roles:

- **Proposer** (LLM): observes mission context and a capability catalog,
  proposes a candidate capability and arguments. The proposer's output is
  semantic and non-authoritative.
- **Qualifier** (deterministic runtime, P2): evaluates the proposal against
  frozen constraints -- authority, tenant/client match, policy state, trust
  score vs. required trust floor, transaction-type match, and provider
  availability -- before any binding occurs. A proposal that fails any gate
  is denied or the qualifier abstains; it never silently falls back to an
  unqualified alternative.
- **Executor**: only receives a capability call after the qualifier binds it.
  For P3-P5 the executor is a synthetic/simulated environment; for P6 the
  executor is the official `sap-adt-mcp` server against a real, authenticated
  SAP destination, restricted to a narrow, explicitly enumerated read-only
  tool allowlist.

Every qualification decision produces a Discovery Receipt, a Runtime Binding
Record, and an Outcome Evidence Receipt, enabling deterministic offline
replay without re-contacting the executor.

Central design invariants:

- DISCOVERABLE != AUTHORIZED_TO_EXECUTE
- TRUSTED_TO_DESCRIBE != AUTHORIZED_TO_EXECUTE
- The LLM proposes semantics; the deterministic runtime binds authority.

## 4. Experimental methodology

P3-P5 are sealed confirmatory empirical stages: a frozen corpus and frozen
decision policy are locked (method-frozen) before any sealed execution;
sealed test reads are counted and audited; comparisons are pre-registered;
Holm correction is applied across primary pairwise comparisons.

P6 is a frozen bounded enterprise read-only proof of concept, not a sealed
statistical test: it evaluates a frozen 60-case corpus against a live,
authenticated SAP destination through the official ADT MCP server, under a
narrow read-only tool allowlist, using deterministic pass/fail gates (not
inferential statistics) appropriate to its small, fully-enumerated design.

See `04_R1_7_RESULTS_HARDENED_R1.md` for full per-stage methodology and
results, and `08_R1_7_SOURCE_EVIDENCE_MAP_HARDENED_R1.json` for source
artifact locations and hashes.

## 5. P3 results (R2-H17, SUPPORTED)

See `04_R1_7_RESULTS_HARDENED_R1.md` section P3. A4 significantly
outperformed broad exposure, semantic retrieval, generic progressive, and the
frozen random-k control, as supported by the actual P3 comparisons/results:
83.3% correct capability selection vs. 60.4% (generic progressive), 60.4%
(semantic retrieval), 54.2% (broad), and 10.4% (random-k), all comparisons
significant after Holm correction (p_holm < 0.005), on a single frozen local
model (qwen3:8b), 48 sealed cases / 864 raw observations.

## 6. P4 adversarial results (R2-H18, SUPPORTED)

See `04_R1_7_RESULTS_HARDENED_R1.md` section P4. A4 significantly
outperformed the frozen A2 semantic-retrieval and A3 generic-progressive
primary comparators under the adversarial benchmark: across 10 adversarial
families, A4 sustains 90% mission success and 10% invalid-capability
proposal rate, vs. 58.1%/41.9% (generic progressive) and 52.5%/47.5%
(semantic retrieval); both primary comparisons p_holm ~4e-05. 100% correct
abstention on the no-valid-capability family. 120 sealed cases / 1440 raw
observations, same frozen model as P3.

## 7. P5 cross-model replication results (R2-H20, SUPPORTED)

See `04_R1_7_RESULTS_HARDENED_R1.md` section P5. The A4 advantage over A2 and
A3 replicated across the three frozen model strata and pooled analysis
(qwen3 anchor, llama replication, gemma replication); all 3 strata are
directionally positive and meet the pre-registered 5-point-CI gate for both
primary comparisons (minimum required: 2 of 3); no material model-specific
reversal detected. Pooled effect sizes: +35.6pp (A4 vs A3), +39.4pp (A4 vs
A2), both p_holm ~4e-05. 120 sealed cases x 3 models x 3 repetitions = 4320
raw observations.

## 8. P6 bounded enterprise POC results (R2-H21, SUPPORTED)

See `04_R1_7_RESULTS_HARDENED_R1.md` section P6 and
`06_R1_7_P6_INTEGRATION_NOTES_HARDENED_R1.md` for the exact wording
constraints. P6 makes no comparative-baseline superiority claim: there is no
A0/A2/A3 baseline arm in the P6 corpus. P6 establishes bounded live
read-only mechanism integrity: against the live, authenticated TRL_EN SAP
destination (via the official 20-tool `sap-adt-mcp` server), 6 of the
60-case corpus's cases were eligible under a deliberately narrow 3-tool
live-read allowlist; 6/6 P6-C-eligible live reads succeeded with zero SAP
writes. The remaining 54 cases were correctly denied or abstained (48 by
frozen policy families, 6 by allowlist-scope restriction). Binding-record
completeness, receipt-chain completeness, and deterministic offline replay
were each 60/60 (100%). Client/mandant identity was not exposed by the
available tool surface and is not claimed.

## 9. Evidence ladder / proof taxonomy

See `03_R1_7_EVIDENCE_LADDER_HARDENED_R1.md`. P0-P2 background/foundation;
P3-P5 completed with sealed confirmatory evidence; P6 completed as a frozen
bounded enterprise read-only proof of concept (not a sealed statistical
test); P7-P8 explicitly future work.

## 10. Claim-to-evidence matrix

See `02_R1_7_CLAIM_EVIDENCE_MATRIX_HARDENED_R1.md` for the full mapping of
every supported and explicitly excluded claim to its evidence source.

## 11. Limitations

See `05_R1_7_LIMITATIONS_AND_THREATS_HARDENED_R1.md`. In brief: small model
sets (P3/P4: 1 model, P5: 3 models), synthetic benchmark corpora throughout,
single-destination/narrow-allowlist live testing in P6, and an open,
documented client-identity gap in P6.

## 12. Threats to validity

See `05_R1_7_LIMITATIONS_AND_THREATS_HARDENED_R1.md`. Construct, internal,
external, and statistical-conclusion validity are each addressed; notably,
P4/P5 report adversarial families (descriptor poisoning, candidate crowding)
where the mission-qualified arm does not dominate, rather than suppressing
that result.

## 13. Discussion

The escalating pattern across P3 -> P4 -> P5 -> P6 -- controlled, then
adversarial, then cross-model, then live-enterprise-bounded -- supports the
R2-E thesis that mission-qualified admission is the load-bearing mechanism,
not merely progressive disclosure by itself (generic-progressive, A3, is
consistently outperformed by mission-qualified, A4, in both P3 and P4/P5,
despite both being "progressive" strategies). The P6 result extends the same
qualification/binding/receipt/replay mechanism from simulated to
real-executor conditions but does so within a deliberately narrow scope and
without a baseline-comparison design; it should be read as a mechanism-
integrity check against a live system, not as an enterprise-readiness
certification and not as a fifth data point in the P3-P5 significance
pattern.

## 14. Future work

- P7: long-duration and fault-injection simulation (provider outages,
  partial failures, sustained load) to test the admission/binding/receipt
  mechanics under conditions not covered by the single-pass P3-P6 designs.
- P8: independent external replication by a separate team/environment.
- Live SAP write-path evaluation (would require new authorization; explicitly
  out of scope for this program to date).
- Live cross-provider failover evaluation (P6 F07/F08 only tested the
  correct-denial path, not a real failed provider).
- A capability-surface probe or complementary metadata source that can
  positively resolve client/mandant identity without inventing arguments,
  closing the P6 identity gap.

## 15. Conclusion

Across four escalating evidence stages, the R2-E mission-qualified capability
admission model shows a consistent, significant advantage over
naive/broad/generic-progressive baselines in P3, P4, and P5, and the same
qualification/binding/receipt/replay mechanism operates correctly, fail-
closed, and with zero writes when the executor is a real external enterprise
system under bounded scope in P6. The program's claims are deliberately
bounded to what was tested: P3-P5 are sealed confirmatory empirical stages on
frozen local models; P6 is a frozen bounded enterprise read-only proof of
concept, not a sealed test and not a baseline-superiority result; and
independent external replication (P8) remains open future work.
