# Claim-to-Evidence Matrix (Publication Hardened)

| Claim | Status | Evidence level | Source |
|---|---|---|---|
| Discoverable != authorized to execute | SUPPORTED | P3, P4 | Naive/broad/generic-progressive arms consistently over-propose invalid capabilities relative to mission-qualified arm (A3/A0/A2 vs A4, sealed P3/P4 comparisons) |
| Discoverable != authorized to execute (enterprise-live mechanism check) | SUPPORTED | P6 | 48/48 non-execution cases in the P6 corpus were correctly denied/abstained by the deterministic runtime rather than executed on discovery alone; this is a mechanism-integrity check, not a baseline-comparison result |
| Trusted to describe != authorized to execute | SUPPORTED | P4, P6 | Descriptor-poisoning family (F07) and authority/tenant/policy/trust/transaction denial families show that plausible-sounding capability descriptions do not bypass deterministic runtime gates |
| LLM proposes semantics, deterministic runtime binds authority | SUPPORTED | P2, P3, P4, P5, P6 | Deterministic engine (P2) adjudicates all proposals in P3-P6; 100% correct denial/abstention in P6 (48/48 non-execution cases), 100% deterministic replay in P6 (60/60) |
| Mission-qualified capability selection significantly outperforms naive/broad/random exposure (single model, non-adversarial) | SUPPORTED | P3 | R2-H17 SUPPORTED, 3 pairwise comparisons all p_holm < 0.005 |
| Mission-qualified path significantly outperforms frozen semantic-retrieval and generic-progressive comparators under adversarial conditions (single model) | SUPPORTED | P4 | R2-H18 SUPPORTED, 10 adversarial families, both primary comparisons p_holm ~4e-05 |
| That adversarial advantage replicates across three frozen model strata | SUPPORTED | P5 | R2-H20 SUPPORTED, 3/3 model strata directionally positive and gate-passing, pooled p_holm ~4e-05 |
| Governed path remains fail-closed and correct against a real enterprise system under bounded read-only scope (mechanism integrity, not baseline superiority) | SUPPORTED | P6 | R2-H21 SUPPORTED, 6/6 P6-C-eligible live reads succeeded, 0 writes, 60/60 receipt/replay completeness; no comparative baseline arm exists in P6 |
| SAP client/mandant identity verified | **NOT CLAIMED** | -- | P6 explicitly could not expose client identity via the live tool surface; documented as an open gap |
| Production security proven | **NOT CLAIMED** | -- | Out of scope for all P2-P6 evidence |
| SAP write safety proven | **NOT CLAIMED** | -- | No write capability was ever exercised in any stage |
| Generic tenant isolation proven | **NOT CLAIMED** | -- | P6 F03 tenant check uses a synthetic policy constant, not a second live tenant |
| Enterprise-wide effectiveness proven | **NOT CLAIMED** | -- | P6 is a single-destination, 6-live-case POC |
| Universal SAP applicability proven | **NOT CLAIMED** | -- | Only ADT MCP / TRL_EN tested |
| Live cross-provider failover proven | **NOT CLAIMED** | -- | P6 F07/F08 provider-unavailable cases were correctly denied, not exercised against a real failed provider |
| Independent external replication proven | **NOT CLAIMED** | -- | P8 not started |
| P6-D completed | **NOT CLAIMED** | -- | P6-D not authorized, not started |
| Unrestricted model independence | **NOT CLAIMED** | -- | P5 tested exactly 3 model strata |
| Unrestricted JCS conformance | **NOT CLAIMED** | -- | Not evaluated in any stage |
| Generic security/auditability/multi-tenancy empirically proven | **NOT CLAIMED** | -- | Out of scope for all P2-P6 evidence |

Note on terminology: P3-P5 are sealed confirmatory empirical stages. P6 is a
frozen bounded enterprise read-only proof of concept and is never described
as a "sealed test." P3-P6 are collectively described as "four escalating
evidence stages," not as "four independent stages" -- independent
replication is reserved for P8 (future work).

`CLAIM_EVIDENCE_MAPPING_COMPLETE=TRUE`
