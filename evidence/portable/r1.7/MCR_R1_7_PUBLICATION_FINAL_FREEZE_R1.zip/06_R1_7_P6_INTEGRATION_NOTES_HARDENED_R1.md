# P6 Integration Notes for R1.7 (Publication Hardened)

- Use `TARGET_BINDING=TRL_EN`, `TARGET_BINDING_VERIFIED=TRUE`.
- Use `CLIENT_IDENTITY=NOT_EXPOSED`, `CLIENT_100_CLAIM=NOT_MADE`,
  `IDENTITY_GAP_DOCUMENTED=TRUE`. Never write "client 100 verified" or
  similar anywhere in the manuscript.
- Use `LIVE_MISSION_EXECUTIONS=6`, `LIVE_READ_SUCCESSES=6`,
  `ELIGIBLE_LIVE_READ_COMPLETION=6/6`. Never report 12/12 -- the other 6
  F01/F10 cases were outside the narrower P6-C 3-tool live allowlist and are
  `ALLOWLIST_SCOPE_ABSTENTION`, not execution attempts, let alone failures.
- Use `SAP_WRITES=0`, `BINDING_RECORD_COMPLETENESS=60/60`,
  `RECEIPT_CHAIN_COMPLETENESS=60/60`, `DETERMINISTIC_REPLAY=60/60`.
- The F03 tenant-mismatch family's "100" value is a frozen synthetic
  policy-corpus constant used purely to test deny-on-mismatch logic. It must
  never be cited as evidence of the live SAP mandant.
- **Never describe P6 as a "sealed test."** Use "frozen bounded enterprise
  read-only proof of concept" (or "frozen bounded enterprise read-only POC").
  "Sealed" is reserved for the P3-P5 pre-registered statistical stages.
- **Never state or imply that P6 shows baseline-comparison superiority.**
  P6 has no A0/A2/A3 arm; its result is mechanism integrity (qualification,
  binding, receipts, replay) against a live executor, not a significance
  finding.
- **Never describe P3-P6 collectively as "four independent stages."** Use
  "four escalating evidence stages." Independent replication is reserved for
  P8 (future work); "independent model strata" (P5) is a distinct and
  correctly-scoped usage referring to the three separate models tested, not
  to the stages themselves.
- Publication-safe P6 claim (use verbatim or lightly edited for flow, but
  preserve meaning): see `07_R1_7_PUBLICATION_CLAIMS_HARDENED_R1.md`.
