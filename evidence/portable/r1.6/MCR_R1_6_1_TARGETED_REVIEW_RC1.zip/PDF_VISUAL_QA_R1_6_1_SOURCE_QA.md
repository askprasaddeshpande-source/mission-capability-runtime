# PDF Visual QA - R1.6.1 Format-Preserved Build

## Authoritative base verification

- R1.6 PDF SHA-256 verified: `6238ED55CD6282517C54B2AC70D02447353246965581D2C5BE2C6D2206320F06`
- R1.6 source ZIP SHA-256 verified: `EB3BDD84C874EF7CC7D6D4B86039E5B94D068B24BA2E53A8A1503DCAA0580CAE`
- Build source: exact R1.6 `main.tex`, `references.bib`, and V1.6 figure/source tree extracted from the authoritative bundle.

## Layout preservation

- compiler: `pdflatex + biber + pdflatex + pdflatex`
- pages: `19`
- page size: `612 x 792 pt` (US Letter), identical to R1.6
- document class: `10pt,twocolumn`
- typography: V1.6 NewTX text/math retained
- margins / column gap: V1.6 geometry retained
- architecture figures: `6/6 PRESENT`
- Figure 3 post-LLM reasoning boundary: PRESENT
- Figure 4 dynamic mission-capability architecture: PRESENT
- Figure 5 dynamic recomposition loop: PRESENT
- Figure 6 prerequisite-conditioned horizons: PRESENT
- Figure 4, Figure 5, Figure 6 external PDF visual assets are byte-identical to R1.6; Figure 3 changes only the visible `R1.6` -> `R1.6.1` rule label.

## Visual inspection

All 19 pages were rendered and inspected after compilation.

- clipping: NONE OBSERVED
- overlap: NONE OBSERVED
- broken glyphs / black squares: NONE OBSERVED
- broken table boundaries: NONE OBSERVED
- missing architecture figures: NONE
- unresolved citations/references: NONE

## Science regression gate

- new experiment/model/provider/SAP execution: `NONE`
- raw evidence modified: `FALSE`
- empirical numbers changed: `FALSE`
- empirical claims strengthened: `FALSE`
- frozen science SHA-256 retained: `E589393C6EEA0BA92E4EC521D1577A6F561F9ADFA38FF9EEE97A94695C666D90`

`FORMAT_PRESERVATION_QA=PASS`
`PDF_VISUAL_QA=PASS`

R1.6.1 canonical targeted-review PDF SHA-256: `AD45F74150D9FEB188C7CA78E427DB960443069EE4A3C1B2B65AF3C53DE0140A`

Byte-identity note: an earlier packaged copy had SHA-256 `A1E76C87C98C8AF3606BE5FD33D88BD7C8AE6E81D18CB90C4EE32E4AF0E9E85E`. Extracted text and all 19 rendered pages were verified identical to the canonical RC1 PDF; RC1 nevertheless uses one exact byte identity for reproducible review.
R1.6.1 source ZIP SHA-256: `DDE86F8CE0751F098EA8C9E436E5CC9334FED086F55319A347A506C962C3C40D`
