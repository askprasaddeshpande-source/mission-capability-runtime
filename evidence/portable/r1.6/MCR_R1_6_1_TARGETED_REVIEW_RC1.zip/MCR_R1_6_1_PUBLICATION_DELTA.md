# MCR / MCWS R1.6.1 Publication Delta

## Release posture

R1.6.1 is a bounded adversarial-review hardening release built directly from the authoritative R1.6 source archive. The V1.6 document class, page geometry, typography, two-column layout, table structure, figure placement strategy, and architecture visual language are preserved.

## Accepted Gemini / Claude corrections

- clarified MCWS vs deterministic runtime attribution;
- separated measured mission-success evidence from unmeasured security/auditability/policy rationale;
- added ToolLLM, Gorilla, AnyTool, and ToolRet to the LLM-era tool-retrieval lineage;
- disclosed the missing size-matched subset control;
- narrowed H2 to implementation-conformance evidence;
- stated held-out results as n=4 independent cases;
- stated provider-substitution mechanism validation as 4 of 5 prequalified cases;
- added semantic-funneling validation at the deterministic boundary;
- made DEGRADED_CAPABILITY re-authorization explicit;
- made composite substitution / Saga limitations explicit;
- marked threat controls as reference design rather than tested security guarantees;
- conceded Queen-Bee / Tool Forge overlap without architectural-priority language;
- retained protocol independence as a design constraint to be tested.

## Deliberately unchanged

- frozen experiment and raw evidence;
- Broad / Static / MCWS primary counts and rates;
- Holm-adjusted p-values;
- SAP/MCP/Capella/BAS engineering proof records;
- six-figure architecture/roadmap visual structure;
- historical OWL-S/WSMO/SOA/Saga/Temporal concessions;
- CURRENT / EMERGING / ARCHITECTURE HYPOTHESIS / LONG-HORIZON visual encoding.

## Figure preservation

Figures 1 and 2 remain native TikZ structures in the V1.6 master manuscript. Figures 3-6 retain the V1.6 external figure design and geometry. Figure 3 receives only the version-label update `R1.6` -> `R1.6.1`; Figures 4-6 are visually unchanged.
