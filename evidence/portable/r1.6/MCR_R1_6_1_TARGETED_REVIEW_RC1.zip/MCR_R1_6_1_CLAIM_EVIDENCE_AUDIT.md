# MCR / MCWS R1.6.1 Claim-Evidence Audit — Targeted Review RC1

This audit is aligned to the format-preserved R1.6.1 article and the consolidated Gemini/Claude adjudication.

| ID | Claim | Evidence class | Evidence strength | R1.6.1 boundary |
|---|---|---|---|---|
| C01 | MCWS has higher primary mission success than Broad and Static in the corrected frozen benchmark | EMPIRICAL | LIMITED / BOUNDED | Broad 5/48, Static 17/48, MCWS 30/48; bounded to the evaluated benchmark/model |
| C02 | Broad vs Static is directional only | EMPIRICAL | LIMITED | Holm-adjusted p=0.2266; no significance claim |
| C03 | Held-out split favors MCWS directionally | EMPIRICAL | ILLUSTRATIVE | Broad 0/12, Static 2/12, MCWS 7/12 from n=4 independent held-out cases; descriptive/directional only |
| C04 | Stage-visible exposure was reduced by MCWS construction | IMPLEMENTATION CONFORMANCE | MODERATE FOR CONFORMANCE | Does not establish downstream security/cost/auditability causality |
| C05 | Mission-stage relevance specifically causes the MCWS advantage | EMPIRICAL CAUSAL | UNRESOLVED | No size-matched selection-logic control; smaller-vs-smarter scoping is not isolated |
| C06 | Capability/tool catalogs are active LLM reasoning input | PRIOR-WORK-GROUNDED ARCHITECTURAL | MODERATE | ToolLLM, Gorilla, AnyTool and ToolRet acknowledged; not claimed as a novel observation |
| C07 | MCWS reduces attack surface / improves auditability | SECURITY / ARCHITECTURAL RATIONALE | NONE AS EMPIRICAL OUTCOME | No security proof; bounded exposure is rationale/design objective only |
| C08 | Provider abstraction/independence belongs to MCR binding/runtime layer | ARCHITECTURAL | N/A | Explicitly not credited to MCWS empirical evidence |
| C09 | LLM proposes semantics; deterministic runtime binds authority | DESIGN CONSTRAINT | MODERATE AS DESIGN | LLM-authored demand is validated before eligibility/ranking; model does not grant authority or own final ranking |
| C10 | Runtime Binding Record mitigates TOCTOU | SECURITY / REFERENCE DESIGN | NONE AS DEPLOYED CONTROL | Do not claim prevention/elimination; point-of-use revalidation is architecture design |
| C11 | Directional stage-relative substitution | ARCHITECTURE HYPOTHESIS | ILLUSTRATIVE | 4 of 5 prequalified mechanism cases; no population-level provider-independence claim |
| C12 | Composite substitution is solved | ARCHITECTURE | NONE | Explicitly unresolved; Saga compensation is not rollback |
| C13 | Multi-tenant isolation is proven | SECURITY | NONE | Required architecture control, not tested result |
| C14 | DEGRADED_CAPABILITY is safe by inheritance | ARCHITECTURE HYPOTHESIS | NONE | False by design: degraded binding requires current deterministic re-authorization |
| C15 | Protocol independence is demonstrated | DESIGN CONSTRAINT | N/A | Design constraint to be tested, not empirically demonstrated |
| C16 | Cyber-physical path is functionally safe | LONG-HORIZON | NONE | Safety-certified deterministic control remains authoritative outside the LLM |
| C17 | Enterprise POCs validate surrounding runtime plumbing | ENGINEERING | MODERATE FOR ENGINEERING CLAIM | Not scientific validation of the full MCR stack |
| C18 | Full MCWS + deterministic binding + recomposition stack was empirically validated as a unit | SYSTEM-LEVEL EMPIRICAL | NONE | Explicitly not claimed; R1.6.1 pairs bounded evidence with a practitioner architecture pattern |
| C19 | M003 common-target correction changed frozen execution evidence | RESEARCH INTEGRITY | FALSE | Persisted Static outputs were regraded against the already-frozen post-change target; no model/provider/SAP execution or experiment rerun |

## Frozen numerical anchors

```text
Broad=5/48
Static=17/48
MCWS=30/48
Broad_to_Static_Holm_p=0.2266
Broad_to_MCWS_Holm_p=0.00293
Static_to_MCWS_Holm_p=0.03125
```

## M003 timing boundary

R1.6.1 intentionally does **not** claim when the correction rule itself was decided beyond what the frozen artifacts establish. The publication claim is limited to the verified asymmetry, same-target regrading of persisted Static outputs, and zero execution reruns.

## Audit closure

```text
EMPIRICAL_CLAIMS_STRENGTHENED=FALSE
ENGINEERING_VS_SCIENCE_SEPARATION=PASS
CURRENT_FUTURE_BOUNDARY=PASS
SAME_SIZE_CAUSAL_CONFOUND=DISCLOSED
M003_UNSUPPORTED_TIMING_CLAIM=FALSE
```
