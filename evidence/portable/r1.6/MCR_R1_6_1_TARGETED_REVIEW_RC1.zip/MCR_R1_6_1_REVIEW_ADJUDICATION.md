# MCR / MCWS Whitepaper R1.6.1 — Consolidated Adversarial Review Adjudication

**Release type:** Minor publication-hardening release  
**Base:** R1.6  
**Date:** 31 August 2026  
**Frozen science SHA-256:** `E589393C6EEA0BA92E4EC521D1577A6F561F9ADFA38FF9EEE97A94695C666D90`

## Release rule

R1.6.1 is a bounded hardening release only.

- `NEW_EXPERIMENTS=0`
- `RAW_EVIDENCE_MODIFIED=FALSE`
- `EMPIRICAL_CLAIMS_STRENGTHENED=FALSE`
- no architecture expansion
- no new POC credited as scientific evidence
- no change to the frozen Broad / Static / MCWS results
- no security certification or production-readiness claim

Where Gemini and Claude differ, the stricter evidence interpretation governs.

## Review convergence

Both independent adversarial reviews conclude:

- core gate: PASS
- fatal findings: 0
- frozen science may remain unchanged
- external review is appropriate after bounded patches
- thesis remains defensible only with narrowing

## Consolidated adjudication

| ID | Source | Disposition | R1.6.1 treatment |
|---|---|---|---|
| P01 | Gemini M01 + Claude attribution concern | ACCEPT | Explicitly separate MCWS reasoning-surface exposure from MCR provider abstraction, ranking, substitution and binding. |
| P02 | Gemini M02 + Claude M1 | ACCEPT | Split measured outcomes from unmeasured security/auditability/policy rationale. |
| P03 | Claude M2 + Gemini prior-art gap | ACCEPT | Add pre-2026 LLM tool-retrieval / tool-subset-selection lineage and concede that dynamic/minimal tool selection is not new. |
| P04 | Claude M3 | ACCEPT | Add explicit same-size-control limitation; do not run a new experiment for R1.6.1. |
| P05 | Gemini M03 + Claude M4 | ACCEPT | Harden composite substitution/Saga language; non-compensable side effects require forward recovery/operator/policy handling. |
| P06 | Claude M5 | ACCEPT | Reword H2 as implementation-conformance evidence, not independent causal/security evidence. |
| P07 | Claude N1 | ACCEPT | Repeat `n=4 independent held-out cases` wherever held-out 0/12, 2/12, 7/12 is quoted. |
| P08 | Claude N2 | ACCEPT | Repeat `4 of 5 prequalified cases` wherever provider-substitution mechanism validation is cited. |
| P09 | Claude N5 | ACCEPT WITH EVIDENCE BOUNDARY | State only verified M003 correction facts; do not claim timing facts that are not in frozen evidence. |
| P10 | Claude security boundary | ACCEPT | Add semantic-funneling boundary: LLM-authored capability demand can shape eligibility, so capability requirements require deterministic validation before provider eligibility/ranking. |
| P11 | Claude threat-model audit + Gemini security caution | ACCEPT | State threat controls are architecture requirements/reference design, not adversarially tested mitigations. |
| P12 | Gemini degraded-operation concern | ACCEPT | `DEGRADED_CAPABILITY` requires current deterministic policy/authority re-authorization before execution. |
| P13 | Gemini protocol-independence minor | CONSISTENCY SWEEP | Preserve existing “design constraint to be tested” language; do not invent REST/gRPC/GraphQL POC validation. |
| P14 | Claude N3 | ACCEPT | Concede Queen-Bee / Tool Forge architectural overlap; distinguish evaluation scope and mission-stage synthesis, not novelty by renaming. |
| P15 | Claude thesis test | ACCEPT | Replace “specifically new post-LLM problem” freshness implication with “a post-LLM agent-tool-catalog problem”; use “pairs” rather than language implying the full stack was empirically validated. |
| P16 | Claude O1 | OPTIONAL / DEFER | Object-capability-security terminology citation may be added only if it improves disambiguation without expanding the paper. |
| P17 | Gemini stronger token/latency/security wording | REJECT | Do not carry forward claims stronger than the frozen study supports. |
| P18 | Future same-size / multi-model / security experiments | DEFER | Record as future work; not part of R1.6.1. |

## Scientific state preserved

Primary results remain exactly:

- Broad: `5/48 (10.4%)`
- Static: `17/48 (35.4%)`
- MCWS: `30/48 (62.5%)`
- Broad → Static Holm p: `0.2266`
- Broad → MCWS Holm p: `0.00293`
- Static → MCWS Holm p: `0.03125`

R1.6.1 must not reinterpret these as proof of:

- universal MCWS superiority
- security
- multi-tenant isolation
- prompt-injection prevention
- provider independence
- composite substitution correctness
- TOCTOU prevention in a deployed runtime
- cyber-physical safety
- protocol independence
- production readiness

## Target closure

```text
MCR_R1_6_1_ADVERSARIAL_PATCH_CLOSURE=PASS
FATAL_FINDINGS_OPEN=0
MAJOR_FINDINGS_OPEN=0
NEW_EXPERIMENTS=0
RAW_EVIDENCE_MODIFIED=FALSE
EMPIRICAL_CLAIMS_STRENGTHENED=FALSE
FROZEN_SCIENCE_UNCHANGED=TRUE
READY_FOR_EXTERNAL_REVIEW=TRUE
```
