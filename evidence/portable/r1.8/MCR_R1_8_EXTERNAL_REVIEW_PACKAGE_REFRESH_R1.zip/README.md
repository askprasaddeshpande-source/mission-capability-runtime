﻿# R1.8 External Review Package Refresh R1

Read first: `R1_8_EXTERNAL_REVIEW_MANUSCRIPT_R1.md`.

Read second: `R1_8_EXTERNAL_REVIEW_EVIDENCE_SUMMARY_R1.md`.

Claim/evidence mapping: `R1_8_EXTERNAL_REVIEW_CLAIM_EVIDENCE_MAP_R1.json`.

Claim audit: `R1_8_EXTERNAL_REVIEW_CLAIM_AUDIT_R1.json`.

This package is authoritative after verifying `PACKAGE_MANIFEST.json` and the ZIP SHA256 reported in `MANIFEST.json`.

This is an external-review package, not a claim of peer review.