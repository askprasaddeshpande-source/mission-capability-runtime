﻿# MCR R1.8: Mission-Qualified Capability Admission, Temporal Authority, and Outcome-Authoritative Execution for MCP-Based Enterprise Agents

**From Tools to Missions, Part II — R2-E Enterprise Agent Runtime Research**

**External Review Candidate V1.8 — 5 September 2026**

**Author:** Prasad Deshpande

---

## Abstract

P8-C1 adds bounded live evidence across four heterogeneous MCP providers: 41 live tools were contract-requalified, exactly four READ-authority business-tool calls were executed with 4/4 independently validated outcomes, and point-of-use provider contract fingerprints were revalidated before execution; the run used zero retries and produced zero SAP writes, zero provider scratch mutations, zero BTP calls, and zero model calls.


The Model Context Protocol (MCP) standardizes how AI applications discover and invoke tools, resources, and enterprise capabilities, but protocol-level discoverability, endpoint security, and backend authorization do not by themselves define whether a particular capability should execute *now*, for a particular mission, under a particular transaction budget, provider state, delegation chain, and outcome requirement. This paper presents **MCR**, a mission-control runtime layer for MCP-based enterprise agents. MCR keeps the LLM as a semantic proposer while placing deterministic mission qualification, binding, temporal authority revalidation, mutation budgeting, provider-substitution policy, and outcome evidence outside model control. Its core invariants are: DISCOVERABLE != AUTHORIZED_TO_EXECUTE; TRUSTED_TO_DESCRIBE != AUTHORIZED_TO_EXECUTE; EXECUTED != COMPLETE.

R1.8 extends the previously frozen R1.7 evidence ladder. P3 showed that mission-qualified progressive capability disclosure significantly outperformed the frozen broad-exposure, semantic-retrieval, and generic-progressive primary comparators on a controlled single-model benchmark (R2-H17, SUPPORTED). P4 showed a significant adversarial advantage over semantic retrieval and generic progressive disclosure (R2-H18, SUPPORTED). P5 replicated that direction across three frozen model strata (R2-H20, SUPPORTED). P6 then exercised the same deterministic admission/binding/receipt/replay mechanism against a live authenticated SAP destination through the official ADT MCP Server under a bounded read-only allowlist: 6/6 eligible live reads succeeded, zero SAP writes occurred, and receipt/replay completeness was 60/60 (R2-H21, SUPPORTED).

P7 extends the mechanism from static admission into **temporal and federated authority**. Across frozen offline and bounded live experiments, stale binding, revoked authority, incompatible contract drift, duplicate delivery, unauthorized provider substitution, and federated authority amplification remained at zero executor reach; provider equivalence was treated as directional; completion without valid outcome evidence remained zero. A deliberately destructive availability test produced an important negative result: after the local ADT MCP process itself was terminated, automatic process resurrection within the frozen timeout was **not observed**. The runtime failed closed and explicit host recovery was required. P7 therefore supports bounded fault/temporal resilience, not autonomous MCP self-healing (R2-H25 through R2-H29, SUPPORTED within scope).

P6-D1 adds the first tightly bounded live SAP write-path mechanism check. A frozen contract authorized exactly two SAP mutations against `TRL_EN`: creation and activation of one disposable ABAP class in `ZCLINE`. The runtime consumed exactly 2/2 authorized mutations, performed no unauthorized or duplicate write, and did not replay a mutation when the first post-write ATC observer call exceeded a 30-second HTTP timeout. A separate read-only continuation subsequently observed the exact object, type, and package through ATC, producing `FINAL_STATE=VALIDATED_COMPLETE`. This supports R2-H30 only as a **single bounded write-path mechanism-integrity POC**; it does not establish general SAP write safety, rollback correctness, distributed atomicity, or production security.

The resulting architectural position is deliberately complementary to SAP's current MCP direction. SAP's ADT, Fiori, UI5, CAP, BTP Administration, and Integration Suite MCP capabilities provide increasingly rich execution, development, identity, API-governance, and observability surfaces. MCR is not proposed as a replacement for those controls. It is a host/runtime **mission-control plane** that can consume such surfaces while adding mission-scoped admission, temporal revalidation, delegation attenuation, explicit mutation budgets, no-silent-fallback provider policy, deterministic receipts, and outcome-authoritative mission state. These latter properties are the research focus of MCR, not claims that SAP's platform controls are absent or insufficient.

All claims remain bounded to the frozen benchmarks, models, single live SAP destination, tested ADT MCP surface, and the one disposable live write case. Independent external replication, gateway-integrated multi-MCP evaluation, live agent-identity delegation, business-transaction write semantics, and generalized enterprise safety remain future work.

P8-C2 further evaluates bounded multi-mission live execution under observed contract drift and governed continuation: three missions and eight unique business-tool probes reached 8/8 validated outcomes with zero retries, zero replay, and zero writes, while preserving explicit boundaries that the result supports governed recovery and continuation rather than uninterrupted execution or autonomous self-healing.

**Keywords:** Model Context Protocol, MCP, mission control runtime, enterprise agents, capability admission, authorization, temporal authority, deterministic binding, outcome evidence, SAP, agent identity, MCP Gateway, adversarial robustness

---

## 1. Introduction

Large-language-model agents increasingly operate through external tools: enterprise application APIs, documentation systems, development environments, data services, and domain-specific capability providers. A companion paper in this program, *From Tools to Missions* [F1], studied a first-order version of this problem: how should a runtime decide *which* capabilities to expose to a model at a given mission stage, and does bounding that exposure (a Minimum Capability Working Set, MCWS) improve mission outcomes relative to exposing everything (Broad) or hard-coding a fixed path (Static)? That study found MCWS materially outperformed Broad and, on dynamic mission families, outperformed Static as well, while carefully declining to claim that dynamic composition is universally superior.

*From Tools to Missions* treated capability exposure as largely a planning-efficiency and mission-success problem: a model that sees fewer, better-chosen tools plans better. It did not treat capability exposure as a security or authorization problem: nothing in that architecture prevents a model from proposing a plausible-looking capability that the runtime should not actually be permitted to execute -- because the caller lacks authority, the target tenant does not match, a policy gate is closed, the caller's trust score has been downgraded, the requested transaction type is wrong, or the underlying provider is unavailable in a way that forbids substitution.

This paper studies that second, narrower problem directly and extends it in R1.8 from admission into temporal and outcome control. The central research question is:

> **Given that an LLM can discover and semantically propose a capability, what deterministic mission-control mechanism should decide whether that capability is authorized to execute now, under current authority/provider state and a bounded transaction budget, and what evidence is required before the mission may be considered complete?**

We model the relationship as a three-role pipeline:

**Proposer (LLM) -> Qualifier (deterministic runtime) -> Executor**

rather than treating capability exposure and capability execution as the same decision. A capability being *visible* to the model, or *describable* by the model, is not evidence that it is *authorized*. R1.8's contribution is a deterministic mission-control runtime whose evidence escalates from controlled and adversarial admission tests to cross-model replication, live SAP read-only execution, temporal/fault/federation/outcome experiments, and one tightly bounded live SAP write-path POC.

### 1.1 Relationship to the companion MCWS study

We are explicit about the boundary between the two papers in this program, to avoid conflating two empirically distinct studies:

- *From Tools to Missions* [F1] tested three **orchestration architectures** (Broad, Static, MCWS) on **mission success and efficiency** across four enterprise-flavored mission families, using a single frozen local model, and reported H1-H5 as its own hypothesis set (e.g., MCWS vs Broad: `SUPPORTED_WITH_BOUNDARY`, p=0.000977, Holm-adjusted p=0.00293). Those results are that paper's findings, not this paper's.
- This paper (R2-E/MCR) tests a **mission-control mechanism** spanning qualification, binding, receipts, temporal authority, provider/delegation constraints, outcome state, and one bounded write extension. R1.8 preserves R2-H17/H18/H20/H21 and adds the completed R2-H25 through R2-H30 evidence without importing the companion paper's H1-H5 results.

Where the two studies share conceptual ancestry (mission -> capability -> provider -> tool; a host/runtime layer above MCP; the view that dynamic behavior should be a deliberate control decision, not a default virtue) we say so explicitly. Where they diverge -- efficiency/exposure versus authorization/admission -- we do not import one paper's results into the other's claim set.

### 1.2 Contributions

1. **MCR as a mission-control runtime layer** above MCP-connected capability providers, separating semantic proposal from deterministic admission, temporal authority, execution budgeting, and outcome-authoritative completion.
2. **A deterministic qualification and receipt model (P2)** that adjudicates capability proposals against explicit authority/tenant/policy/trust/transaction/provider constraints and produces replayable discovery, binding, and outcome evidence records.
3. **Sealed controlled and adversarial evidence (P3, P4)** showing mission-qualified admission materially improves capability-selection correctness relative to the frozen primary comparators within the tested benchmark.
4. **Cross-model replication (P5)** showing the P4 adversarial advantage direction across three frozen model strata.
5. **A bounded live enterprise read-only POC (P6)** showing the same mechanism operates correctly against a real SAP executor under a narrow read-only allowlist, with zero writes and a transparently documented client/mandant identity-exposure gap.
6. **Temporal/fault, federated-authority, provider-equivalence, and outcome-authority evidence (P7)** including a retained negative result: automatic ADT MCP process resurrection was not observed after actual process termination; explicit host recovery was required.
7. **A tightly bounded live SAP write-path mechanism check (P6-D1)** showing exactly 2/2 pre-authorized mutations, no mutation replay after observer timeout, and completion only after independent ATC outcome observation.
8. **A SAP-aligned research positioning** that distinguishes MCR from MCP servers and gateways: standard SAP controls remain authoritative for identity, authorization, API governance, and backend enforcement; MCR's proposed role is mission-scoped runtime admission and outcome control across those surfaces.

---

## 2. Motivation / Problem formulation

An MCP-connected agent typically receives, at some point in its planning loop, a catalog of capabilities it could invoke. The catalog answers "what can I call." It does not answer "what am I currently allowed to call, given who I am, which tenant I am bound to, what policy state currently holds, how much the runtime currently trusts me, what transaction type is in force, and whether the underlying provider is actually available."

Naive designs collapse these two questions. If a capability is discoverable, or if the model can produce a plausible natural-language description of why it should be allowed, some architectures execute it. This is exactly the failure mode adversarial testing needs to probe: a model does not need to be malicious to propose an unauthorized capability -- it only needs to be plausible. Descriptor poisoning (a capability description engineered to look authorized), candidate crowding (many similar-looking options where only one is actually valid), tenant boundary collisions, and stale trust scores are all realistic, non-adversarial-intent failure modes that a purely discovery-based or purely descriptive-trust-based architecture will not reliably reject.

We therefore separate two properties that are easy to conflate:

- **Discoverability**: the capability appears in a catalog the model can see.
- **Descriptive plausibility**: the model can produce a coherent-sounding justification for invoking the capability.

Neither implies **authorization**: a deterministic, independently verifiable decision, made by a runtime component the LLM does not control, that this specific capability call, for this specific mission, tenant, policy state, trust level, and transaction type, against this specific (available) provider, is currently permitted.

R2-E's problem formulation is therefore: design a qualifier that sits strictly between proposal and execution, that never treats discoverability or descriptive plausibility as sufficient for authorization, that fails closed (denies or abstains rather than silently falling back) when any constraint is unmet or unresolved, and that produces a replayable evidentiary record of every decision -- and then test whether that qualifier actually behaves this way under increasingly demanding conditions: controlled (P3), adversarial (P4), cross-model (P5), live-enterprise read-only (P6), temporal/fault/federated/outcome conformance (P7), and one tightly bounded live write-path mechanism check (P6-D1).

---

## 3. Related work and protocol context

### 3.1 Protocol facts: MCP as the interoperability substrate

MCP specifies a protocol boundary for exposing and invoking capabilities. The 2026-07-28 release makes requests self-describing, adds optional `server/discover`, exposes routing metadata through headers, allows deterministic/cacheable list responses, and formalizes extensions such as Tasks [1]. This paper does not claim that MCP lacks discovery, routing, or task-lifecycle primitives. R2-E is a host/runtime admission layer that sits above MCP, using MCP-connected providers (in P6, the official `sap-adt-mcp` server) as interoperable execution endpoints. MCP's contribution is that capabilities can be discovered and invoked consistently; R2-E's contribution is that discovery and invocation are gated by a separate, deterministic authorization decision.

### 3.2 Prior tool-selection, retrieval, and agent-runtime work

A substantial literature already addresses large tool catalogs and dynamic selection. ToolLLM combines a neural API retriever with multi-tool solution-path reasoning over more than 16,000 APIs [2]. Gorilla combines LLM API use with retrieval to improve adaptation to changing API documentation [3]. AutoTool studies dynamic selection across evolving tool inventories [4]. More recent work directly targets minimal or dynamic exposure: Causal Minimal Tool Filtering (CMTF) uses precondition/effect contracts to expose a minimal next-step tool frontier [5]; Instruction-Tool Retrieval dynamically retrieves a small per-step subset of tools and instructions [6]; HYSET treats the tool set itself as the retrieval unit [7]; AgenTRIM enforces per-step least-privilege tool access as a security control [8]. Orchestration has also shifted from isolated calls toward long-horizon policies with state, execution feedback, cost, and verification constraints [9], and Utility-Guided Agent Orchestration explicitly compares fixed and dynamic orchestration policies without assuming either is universally optimal [10].

These works, and our companion paper's MCWS architecture [F1], are about *what is exposed and when*. AgenTRIM [8] is the closest in spirit to R2-E's concern, since it treats tool access itself as a security control; R2-E differs in scope by defining and empirically testing a full qualification/binding/receipt/replay pipeline against controlled, adversarial, cross-model, and live-enterprise conditions, rather than a per-step access-control policy alone. **R2-E is not presented as the invention of tool filtering, minimal exposure, or per-step access control** -- its contribution is the admission/binding/receipt layer and its escalating empirical validation, not progressive disclosure as such.

### 3.3 Deeper ancestry: service composition and orchestration policy

The conceptual ancestry of a mission -> capability -> provider -> tool decomposition predates LLM agents. OWL-S supports automated service discovery, invocation, composition, and monitoring using machine-interpretable service descriptions [11]. WSMO formalizes goals, service capabilities, interfaces/orchestration, and mediators [12]. SHOP2-based Semantic Web Service composition demonstrated that AI planning could automatically compose semantically described services [13]. Later surveys frame dynamic service composition as a lifecycle of runtime discovery, selection, binding, and adaptation [14, 15]. This lineage establishes that goal/mission -> abstract capability -> provider/service -> dynamic binding is not a novel general software-architecture pattern; our companion paper [F1] already adapted it to contemporary MCP-based LLM runtimes for the exposure/composition problem. R2-E's residual contribution relative to this lineage is narrower still: a deterministic authorization gate placed between an LLM's capability proposal and binding, with an empirically tested fail-closed denial/abstention policy and a receipt-based audit trail, validated against a real external enterprise system.

### 3.4 SAP MCP and agent-runtime context

SAP's 2026 MCP landscape now spans several distinct roles rather than one monolithic server. The ADT MCP Server exposes ABAP development capabilities such as object creation, activation, transport management, RAP generation, ATC, and unit testing [16]. SAP Integration Suite realizes MCP through an MCP Gateway that exposes APIs, tools, and backend services while applying security, traffic management, routing, and observability [17]. SAP's remote BTP Administration MCP Server executes under the signed-in user's principal and exposes account, security, service, and connectivity administration across regions [18]. SAP's architecture guidance further positions MCP for tool access, A2A for agent-to-agent interoperability, and identity/governance as platform concerns [19-21]. In the development layer, SAP Fiori, UI5, and CAP MCP servers provide app-generation, project knowledge, validation, documentation, and CAP-model assistance [22-24].

These capabilities materially change the practical boundary of this research. MCR therefore **does not claim that MCP lacks authentication, authorization, governance, tool filtering, or observability**, and it does not propose a parallel SAP security model. Instead, MCR asks a different runtime question: once a capability is discoverable through a valid, governed surface and backend authorization exists, what deterministic mission-level evidence should additionally bind *this* proposal to *this* execution at *this* time, with *this* delegation chain, provider, mutation budget, and completion condition? Public SAP architecture guidance itself increasingly separates probabilistic reasoning from deterministic control, treats agents as first-class principals with scoped authorization, and describes harness engineering and deterministic supervision as core enterprise-agent concerns [20,21]. MCR is positioned as an experimentally testable realization of that mission-level control problem, not as a substitute for SAP's gateway or IAM layers.

### 3.5 This paper's contribution, restated

Relative to the protocol, service-composition, tool-selection, and SAP platform work above, R1.8 claims a narrower mechanism and evidence body: **mission-qualified admission + temporal authority + explicit mutation budgeting + directional provider substitution + proof-carrying receipts + outcome-authoritative completion**, evaluated through P3-P7 and one bounded P6-D1 write case. It does not claim novelty for MCP, IAM, API gateways, progressive disclosure, tool catalogs, service composition, or agent identity in the abstract.

### 3.6 Remaining speculative architecture

Gateway-integrated multi-MCP admission, live agent-identity delegation, generalized business-transaction write safety, distributed compensation, independent external replication, and production cross-provider failover remain future research. Section 19 separates these prospective hypotheses from the supported findings.

---

## 4. R2-E architecture / reference design

The reference design separates three roles:

- **Proposer (LLM)**: observes mission context and a capability catalog, proposes a candidate capability and arguments. The proposer's output is semantic and non-authoritative -- it carries no execution authority by virtue of being well-formed or plausible.
- **Qualifier (deterministic runtime, P2)**: evaluates the proposal against frozen constraints before any binding occurs:
  - **Authority**: does the caller/mission have authority for this capability class?
  - **Tenant/client match**: does the requested tenant match the bound target?
  - **Policy state**: is the current policy state open for this capability?
  - **Trust**: does the caller's trust score meet the required floor?
  - **Transaction type**: does the requested transaction type (e.g., read-only vs. write) match what is supported?
  - **Provider availability**: is the underlying provider currently available, and if not, is substitution permitted and actually resolvable live (as opposed to assumed)?

  A proposal that fails any gate is denied with a specific reason code, or the qualifier abstains when no valid capability exists or a required input cannot be deterministically resolved. The qualifier never silently falls back to an unqualified alternative.
- **Executor**: only receives a capability call after the qualifier binds it. P3-P5 use a synthetic/simulated executor with frozen adjudication. P6 and the live portions of P7 use the official ADT MCP Server against authenticated destination `TRL_EN` under bounded read-only scope. P6-D1 uses the same execution surface under a separately frozen, explicitly human-authorized two-mutation contract for one disposable development object. In all cases, the enterprise execution surface remains authoritative for its own authentication, authorization, validation, and operation semantics.

Central design invariants, preserved through the original R1.7 stages and extended in R1.8:

- **DISCOVERABLE != AUTHORIZED_TO_EXECUTE**
- **TRUSTED_TO_DESCRIBE != AUTHORIZED_TO_EXECUTE**
- **The LLM proposes semantics; the deterministic runtime binds authority.**

These invariants are not slogans decorating the architecture; they are linked to the falsifiable claims tested across P3-P7 and the bounded P6-D1 write extension. If mission-qualified admission performed no better than broad exposure or generic progressive disclosure, or if it failed to deny/abstain correctly under adversarial pressure, or if it failed to replay deterministically, the invariants would be empirically unsupported. Within the frozen test boundaries, the corresponding gates were not falsified; the actual MCP process-loss experiment is retained as a negative boundary against any self-healing claim.

### 4.1 MCR four-plane model

R1.8 sharpens the architecture into four logically separate planes:

1. **Exposure / composition plane** -- determines which mission-relevant capabilities are visible at a stage. The companion MCWS work [F1] belongs primarily here.
2. **Admission / authority plane** -- MCR evaluates whether a proposed capability is permitted *now*, including point-of-use authority, policy, trust, transaction, target, provider state, delegation attenuation, idempotency, and mutation-budget constraints.
3. **Execution plane** -- the authoritative MCP server, gateway, API, workflow, or enterprise system performs the action under its native identity and authorization model. In SAP-aligned deployments, MCR must not bypass SAP Cloud Identity Services, backend authorizations, ADT safeguards, or Integration Suite MCP Gateway controls.
4. **Outcome plane** -- mission state advances only when required readback/observation evidence validates the intended enterprise outcome. An execution receipt is necessary evidence of an attempted action, but not sufficient evidence of mission completion.

The four-plane split gives MCR its specific architectural flavor: it is a **mission-control plane around heterogeneous MCP execution surfaces**, not a replacement MCP implementation. R1.8's new evidence primarily tests the admission and outcome planes under time, failure, federation, substitution, and bounded mutation.

New R1.8 invariants extend the original three:

- **AUTHORITY(child) ⊆ AUTHORITY(parent)**
- **A -> B substitution does not imply B -> A substitution**
- **observer failure != mutation replay authority**
- **EXECUTED != COMPLETE**

### 4.2 A worked qualification trace

To make the qualifier's behavior concrete, consider a P6-style case in which a capability proposal requests `abap_creation-get_all_creatable_objects` against destination `TRL_EN`. The qualifier evaluates, in order: (i) is `abap_creation-get_all_creatable_objects` a real, catalogued capability (yes -- it is not one of the synthetic `enterprise.nonexistent.capability.*` names used to test abstention); (ii) `authority_ok` (true for this case); (iii) does the requested tenant/client reference match the frozen target-tenant constant (true); (iv) `policy_ok` (true); (v) `trust_score >= required_trust` (100 >= 80, true); (vi) does `transaction_required` match `transaction_supported` (`READ_ONLY` == `READ_ONLY`, true); (vii) is the provider available (true); and, specific to the P6 live-execution phase, (viii) is the capability on the narrow 3-tool live-read allowlist (true). All eight gates pass, so the qualifier emits `BIND` and the executor performs the live read. Changing any single upstream condition -- for example, `authority_ok=false`, or `tenant_or_client=200` instead of the bound value, or `trust_score=40` against a `required_trust=80` floor, or `transaction_required=WRITE` against a `transaction_supported=READ_ONLY` provider -- flips the decision to a specific, named denial code (`DENY_AUTHORITY`, `DENY_TENANT`, `DENY_TRUST`, `DENY_TRANSACTION` respectively) without executing anything. This one-gate-at-a-time sensitivity is exactly what the P4 adversarial families (Section 9) and the P6 denial families (Section 11) exercise systematically, one family per gate.

---

## 5. Deterministic qualification and receipt model

Every qualification decision -- whether it results in execution, denial, or abstention -- produces three linked artifacts:

1. **Discovery Receipt**: records what was proposed (capability, target, requesting context) and when, independent of the outcome.
2. **Runtime Binding Record**: records the full set of gate evaluations (authority_ok, tenant match, policy_ok, trust_score vs. required_trust, transaction_required vs. transaction_supported, provider_available, capability-allowlist membership for live stages) and the resulting decision code (e.g., `BIND`, `DENY_AUTHORITY`, `DENY_TENANT`, `DENY_POLICY`, `DENY_TRUST`, `DENY_TRANSACTION`, `DENY_PROVIDER_UNAVAILABLE`, `DENY_NO_LIVE_SUBSTITUTE`, `ABSTAIN_NO_VALID_CAPABILITY`, `ABSTAIN_CAPABILITY_NOT_ALLOWLISTED`, `ABSTAIN_REQUIRED_INPUT_UNRESOLVED`).
3. **Outcome Evidence Receipt**: records the actual execution outcome when the qualifier binds the call (execution status, response hash and byte size -- never the raw response body or any credential material -- and error class if applicable), or records the non-execution outcome when denied/abstained.

Because every decision is a deterministic function of frozen, recorded inputs, the entire receipt chain can be **replayed offline** -- recomputing every decision from the stored Runtime Binding Record fields without re-contacting any executor -- and compared against the original decision. This is the mechanism behind the "deterministic replay" completeness metrics reported in Sections 10-13: a 60/60 replay match (as in P6) means every one of 60 cases' decisions was independently recomputed offline and matched the original, not merely that 60 receipts exist.

No stage in this program persists bearer tokens, Authorization headers, passwords, cookies, or raw provider response bodies in evidence; only cryptographic hashes and byte sizes of responses are retained.

R1.8 adds two receipt semantics. First, temporal and federated decisions carry the authority/provider state used at point of use so stale bindings, revoked authority, broken delegation chains, and unauthorized substitutions can be replayed as non-execution decisions. Second, write-path completion is explicitly outcome-authoritative: the mission may enter an executed/intermediate state after a mutation, but `COMPLETE` is unavailable until the required observation/readback evidence matches the frozen target and freshness conditions. This is the operational meaning of `EXECUTED != COMPLETE`.

For bounded write missions, the binding record also freezes an **exact mutation budget** and idempotency behavior. Exhausting the authorized budget does not create authority for retry, cleanup, compensation, or replay; any such action requires its own frozen authority. P6-D1 exercises this distinction directly when the first ATC observer call times out after both authorized mutations have already completed.

### 5.1 Decision codes

| Code | Meaning | Executor reached |
|---|---|---|
| `BIND` | All gates pass; capability is bound and executed | Yes |
| `DENY_AUTHORITY` | `authority_ok=false` | No |
| `DENY_TENANT` | requested tenant/client does not match the bound target | No |
| `DENY_POLICY` | `policy_ok=false` | No |
| `DENY_TRUST` | `trust_score < required_trust` | No |
| `DENY_TRANSACTION` | `transaction_required != transaction_supported` | No |
| `DENY_PROVIDER_UNAVAILABLE` | provider unavailable, substitution not permitted | No |
| `DENY_NO_LIVE_SUBSTITUTE` | provider unavailable, substitution permitted only in a synthetic/dry-run sense -- not converted into a live claim | No |
| `ABSTAIN_NO_VALID_CAPABILITY` | proposed capability does not correspond to any real, catalogued capability | No |
| `ABSTAIN_CAPABILITY_NOT_ALLOWLISTED` | all frozen gates pass, but the capability is outside a stage-specific live-execution allowlist (P6 only) | No |
| `ABSTAIN_REQUIRED_INPUT_UNRESOLVED` | a required argument cannot be deterministically derived without inventing a value | No |

`DENY_NO_LIVE_SUBSTITUTE` and `ABSTAIN_CAPABILITY_NOT_ALLOWLISTED` are P6-specific tightenings of the general policy: P6 explicitly declines to convert P4/P5's synthetic provider-substitution evidence into a live-execution claim, and explicitly narrows live execution to a 3-tool allowlist even for otherwise-eligible cases. Both are treated as correct, intentional non-execution outcomes, not as failures of the qualifier.

---

## 6. Research questions / hypotheses

R1.8 preserves the previously frozen R2-H17/H18/H20/H21 findings and adds the completed P7 and P6-D1 hypotheses. The numbering follows the wider R2 program and is intentionally non-contiguous.

- **R2-H17 (P3)**: Under controlled conditions, does mission-qualified progressive capability disclosure improve correct capability selection relative to the frozen primary comparators on a single model? **SUPPORTED.**
- **R2-H18 (P4)**: Under ten adversarial failure families, does the mission-qualified path outperform the frozen semantic-retrieval and generic-progressive comparators? **SUPPORTED.**
- **R2-H20 (P5)**: Does the P4 adversarial advantage replicate across three frozen model strata? **SUPPORTED.**
- **R2-H21 (P6)**: Does the admission/binding/receipt/replay mechanism remain correct and fail-closed against a real authenticated SAP executor under a narrow read-only allowlist, with zero writes and a truthfully documented identity-exposure boundary? **SUPPORTED as bounded mechanism integrity, not baseline superiority.**
- **R2-H25 (P7-B/P7-C)**: Under stale binding, revocation, contract drift, duplicate delivery, provider interruption, and delayed execution conditions, does point-of-use qualification prevent invalid executor reach and replay deterministically? **SUPPORTED within the frozen temporal/fault corpus.**
- **R2-H26 (P7-C/P7-C2)**: Under bounded live availability discontinuities, does the runtime fail closed and recover only after the MCP execution surface is verifiably restored? **SUPPORTED with an explicit negative boundary: automatic ADT MCP process resurrection was not observed after actual process termination.**
- **R2-H27 (P7-D)**: In federated authority chains, does delegated authority remain attenuated such that child authority cannot exceed parent authority and remote descriptions cannot create execution authority? **SUPPORTED in the frozen federation corpus.**
- **R2-H28 (P7-D)**: Is provider equivalence directional rather than symmetric, with unauthorized substitution and silent fallback prevented? **SUPPORTED in the frozen provider-equivalence corpus.**
- **R2-H29 (P7-E)**: Can mission state remain outcome-authoritative such that stale, missing, target-mismatched, failed-readback, or duplicate evidence cannot produce `COMPLETE`? **SUPPORTED in the frozen offline and bounded live read-only outcome corpus.**
- **R2-H30 (P6-D1)**: In one tightly bounded live SAP write-path POC with an exact two-mutation budget, can the runtime consume exactly the authorized create+activate pair, avoid mutation replay after observer timeout, and advance to validated completion only after independent ATC outcome evidence? **SUPPORTED as a single bounded mechanism-integrity POC only.**

No R2-H30 result is interpreted as general write safety, transaction atomicity, rollback correctness, or production readiness.

---

## 7. Experimental methodology

P3-P5 remain **sealed confirmatory empirical stages** with frozen corpora, decision policy, primary comparisons, and statistical procedure. P6 remains a **frozen bounded enterprise read-only proof of concept** using deterministic pass/fail gates rather than inferential statistics.

P7 consists of three additional bounded evidence classes: (i) deterministic temporal/fault conformance, (ii) bounded live read-only fault/recovery validation including an actual local MCP process-loss experiment, and (iii) deterministic federation/provider-equivalence plus outcome-authoritative mission-state experiments. P7 deliberately preserves negative evidence. Transport interruption/reconnect is distinguishable from actual server-process loss; the latter did not automatically self-heal within the frozen timeout.

P6-D1 is a **single bounded live write-path mechanism-integrity experiment**, not a statistical study. It was preceded by zero-write preparation, live schema inspection, transport preflight, exact object validation, readback-surface discovery, a frozen mutation contract, and new explicit human authorization. The frozen budget permitted exactly two mutations: `abap_creation-create_object` followed by `abap_activate_objects`, against one disposable class. After both mutations, observation used ATC. The first ATC result read timed out after 30 seconds; this did not create retry authority for either mutation. A separate signed read-only continuation later observed the exact object identity/package and completed the outcome receipt.

Across all stages, supported claims are tied to the evidence class that produced them. P3-P5 significance does not transfer to P6/P7/P6-D1; P6/P7/P6-D1 mechanism-integrity checks do not become broad enterprise-safety claims.

### 7.1 Freeze and sealing protocol

For P3-P5, the corpus, decision policy, comparator arms, primary comparisons, and statistical procedure (Holm correction across primary pairwise comparisons) are locked -- method-frozen -- before any sealed execution begins, and the freeze artifact is hashed. Sealed test reads (the number of times the sealed/encrypted ground truth is actually decrypted and consulted) are separately counted and audited to catch any accidental or repeated consultation of the answer key. Post-hoc method changes are tracked explicitly. P3-P5 report zero post-hoc changes to their sealed confirmatory methods. P6 is not a sealed confirmatory stage: after repeated pre-execution checks showed that the available ADT interface did not expose client/mandant identity, the identity requirement was transparently amended before the 60-case live mission began; the amendment is retained as part of the P6 evidence rather than being treated as a post-hoc result change.

### 7.2 P6-specific safeguards

P6 additionally freezes, before any live call: the exact tool allowlist (3 of the 20 available ADT MCP tools), the exact denial-code mapping for every family, and the exact target destination (TRL_EN) and its independent live confirmation via `abap_list_destinations`. A pre-execution gate is re-checked immediately before every live call: target match, authority, policy, trust, transaction type, provider availability, allowlist membership, and non-mutation of the capability. If any gate cannot be positively resolved, the case is marked `ABSTAIN_REQUIRED_INPUT_UNRESOLVED` rather than executed with a guessed value. No SAP write capability (create, activate, generate, transport-create, or quick-fix) is ever included in the live allowlist, so no code path in P6 can reach a mutating call regardless of qualifier outcome.

### 7.3 Comparator arms (P3-P5)

Six arms are compared across P3-P5, not all present in every stage: **A0** (broad exposure -- full catalog visible), **A1** (random-k -- a random subset exposed), **A2** (semantic retrieval -- similarity-based subset), **A3** (generic progressive -- stage-scoped disclosure without mission qualification), **A4** (mission-qualified progressive -- the R2-E qualifier under test), and **A5** (oracle -- an upper-bound reference arm with privileged knowledge of the correct capability). A4 vs. A3 and A4 vs. A2 are the primary comparisons in P4 and P5; P3 additionally reports A4 vs. A0 and against the A1 random-k floor.

---

## 8. P3 controlled empirical results (R2-H17, SUPPORTED)

Source: sealed confirmatory result `R2_H17_CONFIRMATORY_RESULT_R1.json`, 48 sealed cases, 864 raw observations, single frozen local model (qwen3:8b).

A4 (mission-qualified progressive disclosure) significantly outperformed the three frozen P3 primary comparators -- broad exposure, semantic retrieval, and generic progressive -- and also exceeded the frozen random-k control descriptively: 83.3% correct capability selection vs. 60.4% (generic progressive, A3), 60.4% (semantic retrieval, A2), 54.2% (broad exposure, A0), and 10.4% (random-k, A1). The frozen Holm-corrected significance family contains A4-vs-A3, A4-vs-A2, and A4-vs-A0; no separate A4-vs-A1 Holm p-value is claimed here.

- A4 vs A3: risk difference +22.9 pp, Holm-adjusted p = 0.00325.
- A4 vs A2: risk difference +22.9 pp, Holm-adjusted p = 0.0018.
- A4 vs A0: risk difference +29.2 pp, Holm-adjusted p = 0.0009.

| Arm | Correct capability selection | n (raw observations) |
|---|---:|---:|
| A0 (broad) | 54.2% | 144 |
| A1 (random-k) | 10.4% | 144 |
| A2 (semantic retrieval) | 60.4% | 144 |
| A3 (generic progressive) | 60.4% | 144 |
| **A4 (mission-qualified)** | **83.3%** | 144 |
| A5 (oracle) | 87.5% | 144 |

Parse validity was 100% across all six arms (every arm's proposal was syntactically parseable), which isolates the observed differences to *what* was proposed rather than *whether* a proposal could be extracted at all. Note that A4 (83.3%) sits well above both progressive-style baselines (A2, A3, both 60.4%) and approaches the oracle upper bound (A5, 87.5%), while the random-k floor (A1, 10.4%) confirms the benchmark is not trivially solvable by chance. `r2_h17_result: SUPPORTED`. The frozen evidence's own generalization boundary: "Single frozen local open-weight model / one DS-12 synthetic benchmark setting; not a general MCP claim."

---

## 9. P4 adversarial results (R2-H18, SUPPORTED)

Source: sealed confirmatory result `R2_H18_CONFIRMATORY_RESULT_R1.json`, 120 sealed cases, 1440 raw observations, 10 adversarial families, same frozen model as P3.

A4 significantly outperformed the frozen A2 (semantic-retrieval) and A3 (generic-progressive) primary comparators under the adversarial benchmark: A4 achieved 90% mission success and 10% invalid-capability proposal rate, versus 58.1%/41.9% (A3) and 52.5%/47.5% (A2). A4 also achieved 100% correct abstention on the no-valid-capability family.

- A4 vs A3: mission-success risk difference +31.9 pp, Holm-adjusted p ~ 4.0x10^-5.
- A4 vs A2: mission-success risk difference +37.5 pp, Holm-adjusted p ~ 4.0x10^-5.

| Adversarial family | A2 mission success | A3 mission success | A4 mission success | A5 mission success |
|---|---:|---:|---:|---:|
| F01 near-miss semantic decoy | 100.0% | 94.4% | 100.0% | 100.0% |
| F02 authority conflict | 16.7% | 16.7% | **100.0%** | 2.8% |
| F03 tenant boundary collision | 58.3% | 27.8% | **100.0%** | 30.6% |
| F04 policy state conflict | 33.3% | 16.7% | **100.0%** | 33.3% |
| F05 trust downgrade | 58.3% | 41.7% | **100.0%** | 50.0% |
| F06 transaction mismatch | 16.7% | 16.7% | **100.0%** | 0.0% |
| F07 descriptor poisoning | 58.3% | 66.7% | 58.3% | 94.4% |
| F08 candidate crowding | 58.3% | 100.0% | 58.3% | 91.7% |
| F09 unavailable-provider substitution | 66.7% | 100.0% | 83.3% | 91.7% |
| F10 no-valid-capability abstention | 58.3% | 100.0% | **100.0%** | 58.3% |

`r2_h18_result: SUPPORTED`. The table makes the pattern precise rather than impressionistic: A4 reaches 100% mission success on five of the ten families -- exactly the five families that test authority, tenant, policy, trust, and transaction gates directly (F02-F06), plus the no-valid-capability abstention family (F10) -- while on the two families that stress semantic plausibility rather than gate logic (F07 descriptor poisoning, F08 candidate crowding), A4 is comparably positioned to A2 and below the oracle (A5) and, on F08, below A3. This is reported as-is: mission-qualified admission is strongest exactly where its deterministic gates apply directly, and is not claimed to solve semantic-plausibility attacks that no gate in this design targets. The frozen evidence's own generalization boundary: "Synthetic adversarial capability-selection benchmark, one frozen qwen3:8b local runtime; not downstream enterprise execution or model-independent generalization."

---

## 10. P5 cross-model replication (R2-H20, SUPPORTED)

Source: sealed confirmatory result `R2_H20_CONFIRMATORY_RESULT_R1_HF02.json`, 120 sealed cases x 3 model strata (M0 qwen3 anchor, M1 llama replication, M2 gemma replication) x 3 repetitions = 4320 raw observations.

The A4 advantage over A2 and A3 replicated across the three frozen model strata and pooled analysis: all 3 strata are directionally positive for both primary comparisons and meet the pre-registered 5-percentage-point confidence-interval gate (minimum required: 2 of 3 strata); no material model-specific reversal was detected.

- Pooled A4 vs A3: risk difference +35.6 pp, Holm-adjusted p ~ 4.0x10^-5.
- Pooled A4 vs A2: risk difference +39.4 pp, Holm-adjusted p ~ 4.0x10^-5.

| Model stratum | A2 mission success | A3 mission success | A4 mission success | A4 vs A3 (pp) | A4 vs A2 (pp) |
|---|---:|---:|---:|---:|---:|
| M0 -- qwen3 (anchor) | 49.4% | 53.9% | 89.2% | +35.3 | +39.7 |
| M1 -- llama (replication) | 40.3% | 40.8% | 79.7% | +38.9 | +39.4 |
| M2 -- gemma (replication) | 24.2% | 30.8% | 63.3% | +32.5 | +39.2 |

Every stratum shows A4 more than 30 percentage points above both comparators, and the direction is identical across all three independently trained models despite substantially different absolute performance levels (M2/gemma's baselines are markedly lower than M0/qwen3's, yet the A4 advantage over A2 is nearly identical across strata at 39.2-39.7 pp). `r2_h20_result: SUPPORTED`. The frozen evidence's own generalization boundary: "Cross-model replication of synthetic adversarial capability-selection behavior only."

---

## 11. P6 bounded enterprise read-only POC (R2-H21, SUPPORTED)

Source: `MCR_R2E_P6_SCIENTIFIC_CLOSURE_R1.zip`, independently re-verified in this assembly at SHA-256 `23847b129bcb775f44a7278c7ae8d41d4a3ed1b54268683f1f0823795e7f427b`.

**No comparative-baseline superiority claim is made for P6.** There is no A0/A2/A3 baseline arm in the P6 corpus; P6 establishes bounded live read-only mechanism integrity, not a significance result against baselines.

- 60-case / 10-family corpus, purpose-built for enterprise read-only qualification, evaluated against the live, authenticated `TRL_EN` SAP destination via the official 20-tool `sap-adt-mcp` server (tool contract independently confirmed to match the frozen P6-A tool inventory exactly).
- `TARGET_BINDING=TRL_EN`, `TARGET_BINDING_VERIFIED=TRUE`.
- 6 of the 60 cases were eligible under a deliberately narrow 3-tool live-read allowlist. **6/6 P6-C-qualified live read executions succeeded** as real, non-mutating reads against the live system.
- The remaining 54 cases were correctly denied or abstained: 48 by frozen policy families (authority/tenant/policy/trust/transaction/provider-unavailable/no-valid-capability), and 6 by allowlist-scope restriction specific to P6-C (these are `ALLOWLIST_SCOPE_ABSTENTION`, not execution failures -- they were never eligible for live execution under the narrower P6-C tool allowlist).
- Binding-record completeness, receipt-chain completeness, and deterministic offline replay: 60/60 (100%) each.
- SAP writes: 0. Unauthorized executor reach: 0.
- `CLIENT_IDENTITY=NOT_EXPOSED`, `CLIENT_100_CLAIM=NOT_MADE`, `IDENTITY_GAP_DOCUMENTED=TRUE`. The live ADT MCP tool surface exposes no capability that reports client/mandant identity; two bounded identity-only probes were executed live and confirmed this. The value "100" used as the tenant/client comparator in the F03 (tenant-mismatch) corpus family is a frozen synthetic policy-simulation constant, used only to test deny-on-mismatch logic -- it is not, and has never been claimed to be, evidence of the live SAP mandant.

| Family | Cases | Decision | Executor reached |
|---|---:|---|---|
| F01 authorized_read | 6 | 3x `BIND` (executed), 3x `ABSTAIN_CAPABILITY_NOT_ALLOWLISTED` | 3 of 6 |
| F02 authority_denial | 6 | `DENY_AUTHORITY` | 0 of 6 |
| F03 tenant_mismatch | 6 | `DENY_TENANT` | 0 of 6 |
| F04 policy_denial | 6 | `DENY_POLICY` | 0 of 6 |
| F05 trust_floor_failure | 6 | `DENY_TRUST` | 0 of 6 |
| F06 transaction_mismatch | 6 | `DENY_TRANSACTION` | 0 of 6 |
| F07 provider_unavailable_permitted_substitution | 6 | `DENY_NO_LIVE_SUBSTITUTE` | 0 of 6 |
| F08 provider_unavailable_forbidden_substitution | 6 | `DENY_PROVIDER_UNAVAILABLE` | 0 of 6 |
| F09 no_valid_capability_abstention | 6 | `ABSTAIN_NO_VALID_CAPABILITY` | 0 of 6 |
| F10 receipt_replay_integrity | 6 | 3x `BIND` (executed), 3x `ABSTAIN_CAPABILITY_NOT_ALLOWLISTED` | 3 of 6 |

Two rows warrant explicit comment. F07's frozen P4/P5-style corpus label is "permitted substitution," and a P4/P5-style dry-run engine would emit `BIND_SUBSTITUTE`; P6 deliberately overrides this to `DENY_NO_LIVE_SUBSTITUTE`, per the program rule that P4/P5's synthetic substitution evidence is never converted into a live-execution claim. F01 and F10 each contain six otherwise-identical authorized-read cases that differ only in which of six real ADT MCP tools they request; three of those six tools (`abap_creation-get_all_creatable_objects`, `abap_generators-list_generators`, `abap_creation-get_object_type_details`) are on the narrow P6-C live allowlist and executed; the other three (`abap_transport-get`, `abap_business_services-fetch_services`, `abap_generators-get_schema`) are not, and are correctly abstained on allowlist grounds rather than executed or silently substituted. This yields the reported `6/6 P6-C-qualified live read executions succeeded`, out of 12 cases that would satisfy the underlying authority/tenant/policy/trust/transaction/provider gates but only 6 of which are also within the deliberately narrower live-execution scope.

`r2_h21_result: SUPPORTED`. P6 is a frozen bounded enterprise read-only proof of concept, not a sealed test.

---

## 12. P7 temporal, fault, federation, provider-equivalence, and outcome evidence (R2-H25-H29)

P7 extends R2-E beyond single-pass qualification into time, failure, delegation, provider substitution, and post-execution mission state. The P7 scientific closure recorded `P7_PROGRAM=PASS` and `R2_H25_RESULT` through `R2_H29_RESULT=SUPPORTED`, with 37 bounded live SAP reads and zero SAP writes across P7. The closure archive is recorded in the authoritative handover at SHA-256 `082CC73D151597B0FAF28EA2BFA55171316DC522AC016C3BDB28A544B6682F52`; the archive itself was not re-opened during this V1.8 assembly, so this manuscript distinguishes **handover-verified state** from independently rehashed local evidence.

### 12.1 Deterministic temporal/fault conformance (P7-B)

P7-B evaluated 144 cases across 12 families. Decision conformance and deterministic replay were 144/144. The frozen invariants held with zero stale-binding executor reach, zero revoked-authority executor reach, zero incompatible-contract-drift executor reach, zero duplicate executor reach, zero unauthorized provider substitution, zero federated authority amplification, zero silent fallback, and zero completion without valid outcome evidence. No SAP, MCP, model, or write calls were made in P7-B.

### 12.2 Bounded live read-only fault/recovery (P7-C)

P7-C evaluated 24 live cases across 12 families. Decision conformance was 24/24; 20 live mission executions produced 20/20 successful reads; receipt-chain completeness and deterministic replay were 24/24; SAP writes remained zero. The test observed an MCP availability discontinuity and successful reconnect/rebinding for the bounded transport-interruption condition.

### 12.3 Actual MCP process loss: retained negative result (P7-C2)

P7-C2 terminated the actual local `adt-lsc` process after a successful MCP/tool/read check. **Automatic MCP process recovery within the frozen timeout was not observed.** The system therefore cannot support an autonomous MCP self-healing claim. Importantly, execution failed closed. After explicit VS Code/SAP ADT host recovery, the PID changed, MCP initialization passed, the 20-tool surface returned, target `TRL_EN` was re-established, and a live read succeeded; SAP writes remained zero.

This negative result is scientifically important because it separates two failure classes that would otherwise be easy to conflate: transport/session interruption can recover through reconnect/rebind, whereas actual server-process loss required explicit host restoration in the tested runtime.

### 12.4 Federated authority and directional provider equivalence (P7-D)

P7-D evaluated 144 deterministic cases: 72 federation cases and 72 provider-equivalence cases. Decision conformance and deterministic replay were 144/144. No federated authority amplification, description-created authority, broken-delegation-chain executor reach, unauthorized provider substitution, reverse-equivalence assumption, or silent fallback was observed. The tested invariants were:

- `TRUSTED_TO_DESCRIBE != AUTHORIZED_TO_EXECUTE`
- `Authority(child) ⊆ Authority(parent)`
- explicit `A -> B` substitution does not imply `B -> A` substitution.

### 12.5 Outcome-authoritative mission state (P7-E)

P7-E evaluated 96 offline cases across eight families plus 16 bounded live cases. Offline decision conformance and deterministic replay were 96/96; live case conformance and receipt-chain completeness were 16/16; 15/15 eligible live executions succeeded; SAP writes were zero. No stale, missing, target-mismatched, failed-readback, or duplicate completion evidence produced a completed mission.

The central rule is therefore not merely an architectural preference but a tested state-machine property within the frozen corpus:

> **EXECUTED != COMPLETE**

Execution is an event; completion is a validated state transition requiring appropriate outcome evidence.

---

## 13. P6-D1 tightly bounded live SAP write-path POC (R2-H30, SUPPORTED WITH BOUNDARY)

Source: `MCR_R2E_P6_D1_SCIENTIFIC_CLOSURE_R1.zip`, independently re-verified for this assembly at SHA-256 `D6ECA3A411DC1E224DCE677C404575A530C04BFB625852734802D61848AE953C`.

P6-D1 is deliberately narrow. It tests whether the admission/outcome machinery can govern one live development write without broadening authority after execution or observer failure. It does **not** test arbitrary SAP writes, production business transactions, rollback, distributed atomicity, or cross-system compensation.

Frozen execution contract:

- Target: `TRL_EN`
- Package: `ZCLINE`
- Disposable object: `ZCL_MCR_P6D_DFC3F677` (`CLAS/OC`)
- Transport recording: not required for this object/package path; empty transport request number frozen after live `abap_transport-get` preflight
- Exact object-content SHA-256: `5F1779E4B86FA34350E6D3B9AA51B4EFF57E937CE9731851A76522D2928E45AC`
- Frozen mutation contract SHA-256: `6A0EAF7765566E5AD02557070CBAA6E1EA7DE18EFC1E951A5D4480628AB66FA7`
- Maximum SAP mutations: **2**
- Authorized mutations only: `abap_creation-create_object`, then `abap_activate_objects`
- Idempotency key: `P6D-DFC3F677B3AF4CF7BFCCC753`

Execution result:

| Gate / event | Result |
|---|---|
| Point-of-use 20-tool surface recheck | PASS |
| Target binding recheck | PASS (`TRL_EN`) |
| Transport requirement recheck | PASS; empty request |
| Exact object validation | PASS |
| Mutation 1: class creation | PASS |
| Mutation 2: activation | PASS |
| Authorized mutation budget | 2/2 consumed |
| Unauthorized mutations | 0 |
| Duplicate create | 0 |
| Silent fallback | 0 |

After both writes completed, `abap_atc_run` returned worklist `FA53C505DD7B1FD1AAA4BE25CE513D42`. The first `abap_atc_get_result` call exceeded the configured 30-second HTTP timeout. That timeout **did not authorize replay** of create or activate. The write runner was not rerun. A separate signed read-only continuation called the existing worklist and observed exactly:

`ZCL_MCR_P6D_DFC3F677 | CLAS | ZCLINE | findings=[]`

The outcome state then advanced to `VALIDATED_COMPLETE`. `COMPLETE_WITHOUT_VALID_OUTCOME_EVIDENCE=0`.

R2-H30 is therefore **SUPPORTED WITH BOUNDARY**: one live SAP development-object write path obeyed an exact frozen mutation budget and outcome-authoritative completion rule, including fail-closed behavior across a post-write observer timeout. The evidence is insufficient for any general claim about SAP write safety, business-transaction correctness, rollback, compensation, or production security.

---

## 14. Cross-stage synthesis

R1.8 now spans three distinct evidence questions rather than a single "agent safety" claim. P3-P5 ask whether mission-qualified admission improves selection/admission correctness under controlled, adversarial, and cross-model conditions. P6 asks whether the mechanism remains coherent against a real external enterprise executor under bounded read-only scope. P7 asks whether authority and mission state remain correct under time, failure, delegation, substitution, and observation uncertainty. P6-D1 asks whether a single explicitly authorized live write path can remain bounded to its mutation budget and still refuse to equate execution with completion.

The strongest cross-stage pattern is therefore **separation of concerns**:

- semantic proposal is not execution authority;
- tool visibility is not mission authority;
- authenticated/backend-authorized access is necessary but not identical to mission-scoped admission;
- provider similarity is not symmetric substitution authority;
- a successful mutation is not validated enterprise outcome;
- observer failure does not create mutation replay authority.

This framing is also more compatible with SAP's current AI-native architecture than a claim that MCR is a competing security layer. SAP increasingly treats applications as capability providers, MCP as a tool-integration protocol, A2A as agent interoperability, agents as first-class principals, and deterministic supervision/harness controls as the mechanism that bounds probabilistic reasoning [19-21]. MCR's research contribution is to make a subset of those runtime-boundary ideas explicit, falsifiable, and replayable at mission level.

---

## 15. Limitations

- P3/P4 remain single-model studies; P5 extends to only three model strata.
- P3-P5 use a synthetic purpose-built benchmark rather than naturally occurring production traffic.
- P6/P7/P6-D1 use one SAP destination (`TRL_EN`) and the ADT MCP surface available in that environment.
- P6 client/mandant identity remains unexposed by the tested ADT MCP surface and is not independently verified.
- P7's actual MCP process-loss experiment does **not** support autonomous process self-healing; explicit host recovery was required.
- P7 federation and provider equivalence are controlled deterministic experiments, not live multi-organization federation or production failover.
- P6-D1 is one disposable ABAP class creation/activation case. It does not test arbitrary code edits, transport release, deletion/cleanup, business-object writes, workflow approvals, distributed transactions, rollback, or compensation.
- ATC observation establishes the tested object identity/package after activation; it is not a universal enterprise outcome oracle. Different business capabilities require capability-specific outcome evidence.
- SAP's MCP/agent platform is evolving rapidly. Section 18 is a point-in-time architecture comparison based on public SAP material reviewed on 5 September 2026; absence of a feature from those sources is not proof that SAP lacks it elsewhere.
- Independent external replication (P8) remains open.

---

## 16. Threats to validity

- **Construct validity**: mission success, correct admission, valid outcome evidence, and provider equivalence are defined by frozen program policies. They are internally testable but not yet validated by independent external adjudicators.
- **Internal validity**: P3-P5 retain sealed/pre-registered methodology; P6/P7/P6-D1 use deterministic bounded gates. The P6-D1 write POC was manually authorized and executed in one environment, so operator/environment effects cannot be excluded.
- **External validity**: no evidence establishes that the observed behavior generalizes across SAP products, MCP hosts, production tenants, enterprise roles, or non-SAP systems.
- **Statistical conclusion validity**: only P3-P5 support inferential significance claims. P6, P7 live portions, and P6-D1 are mechanism-integrity experiments and must not be folded into a pooled significance narrative.
- **Observation validity**: the P6-D1 outcome observer was ATC; business transactions will need stronger domain-specific evidence such as status/readback, process-event, accounting, workflow, or side-effect reconciliation.
- **Platform-comparison validity**: the SAP gap analysis compares MCR research properties with properties documented in the public source set, not with SAP internal product roadmaps or undocumented controls.

---

## 17. Discussion: MCR as a mission-control plane

The most useful interpretation of R1.8 is not "MCR secures MCP." MCP servers and SAP gateways already participate in authentication, authorization, API governance, tool exposure, and observability. The narrower thesis is that **mission state is a separate control problem**. A user or agent can be validly authenticated and backend-authorized while a particular mission call is still stale, outside the current transaction type, delegated beyond the parent authority, an unauthorized provider substitution, beyond the frozen mutation budget, or not yet outcome-complete.

MCR therefore sits at the intersection of **harness engineering** and **specification engineering**: the mission defines authority, budget, substitution, evidence, and completion criteria precisely enough that a deterministic runtime can enforce and replay them. This is especially relevant in heterogeneous SAP development and administration landscapes where an AI host may simultaneously see ADT, Fiori, UI5, CAP, BTP Administration, Integration Suite, and third-party tools. The more capable the tool surface becomes, the more valuable explicit mission boundaries become.

MCR should remain deliberately subordinate to native enterprise authority. If SAP Cloud Identity Services, backend authorization, ADT validation, transport governance, or MCP Gateway policy denies an action, MCR cannot create permission. Its authority function is attenuating and contextual: it can further constrain a valid enterprise principal for a mission; it must not elevate that principal.

---

## 18. SAP standard MCP landscape and the MCR research gap

This section is an **architectural analysis, not an empirical SAP product comparison**. It summarizes public SAP sources reviewed on 5 September 2026 and identifies research questions those sources make especially relevant.

| SAP surface | Publicly documented role | Controls/capabilities already present | MCR research opportunity (not a claim of SAP deficiency) |
|---|---|---|---|
| ADT MCP Server | Agentic ABAP development | destination discovery, object validation/creation, activation, transport, RAP generation, ATC, unit tests [16] | mission-level point-of-use admission; mutation budgets; write/observer state separation; replayable receipts |
| Fiori MCP | Create/modify Fiori apps | application generation/modification and project-aware Fiori development [22] | multi-server mission binding with CAP/UI5/ADT; authority continuity across generated artifacts |
| UI5 MCP | UI5 developer assistance | scaffolding, API reference, guidelines, manifest validation, linting [23] | low-risk knowledge/validation tools as separate trust class inside MCWS/MCR exposure |
| CAP MCP Server | CAP development knowledge/model search | compiled model search and CAP documentation search [24] | semantic grounding as admission input without converting semantic confidence into authority |
| BTP Administration MCP | Remote BTP administration | user-principal propagation, account/security/services/connectivity operations, cross-region access [18] | explicit mission budgets for infrastructure mutation, delayed approval/revocation, outcome evidence for provisioning |
| Integration Suite MCP Gateway | Governed enterprise API/tool exposure | authN/authZ, rate limiting, payload protection, routing, monitoring/traceability, API-to-MCP exposure [17,19] | test layered `Gateway + MCR` vs gateway-only for temporal/federated mission constraints; no parallel IAM |
| SAP agent identity / AI-native architecture | First-class agent principals and deterministic supervision | scoped agent authorizations, trust boundaries, deterministic control agents, harness engineering [20,21] | bind user+agent+mission authority as an attenuating delegation chain and replay it across MCP/A2A boundaries |

The gap MCR should pursue is therefore **between valid platform access and valid mission execution**, especially where multiple governed surfaces participate in one long-running goal. The research target is not "more authorization" in the abstract; it is **authorization with mission semantics, time, delegation, provider identity, transaction budget, and outcome evidence**.

---

## 19. Future work and prioritized research program

### Priority 1 — P8 independent external replication

Highest scientific priority. An independent team/environment should reproduce at least the P4/P5 adversarial admission study and a bounded P7 outcome-state subset using frozen artifacts. This is the strongest next step for publication credibility because it attacks researcher/environment dependence directly.

### Priority 2 — P9 SAP multi-MCP federation

Compose at least ADT + Fiori + UI5 + CAP, with BTP Administration added only after a read-only baseline. Test whether MCWS exposure plus MCR admission can reduce simultaneous tool exposure while preserving valid mission paths. Freeze server identity, tool contract/version, target binding, and cross-server delegation receipts.

Prospective **R2-H31 (NOT TESTED)**: mission-scoped multi-MCP composition reduces invalid/irrelevant capability exposure and preserves correct execution relative to host-wide unrestricted tool exposure under the same backend permissions.

### Priority 3 — P10 SAP MCP Gateway + MCR layered control

Integrate a controlled SAP Integration Suite MCP Gateway surface and compare: gateway-native controls alone vs the same gateway plus MCR temporal/mission constraints. The goal is not to prove the gateway insufficient; it is to test whether mission-scoped constraints add a distinct measurable property while leaving SAP identity/RBAC authoritative.

Prospective **R2-H32 (NOT TESTED)**: under equal authenticated principal and gateway policy, an additional frozen MCR mission contract reduces stale/revoked/duplicate executor reach without increasing false denial of valid calls beyond a predefined tolerance.

### Priority 4 — P11 agent identity and delegation attenuation

Use SAP's agent-identity direction when available in the test environment. Represent `human principal -> agent identity -> mission authority -> capability binding` as an attenuating chain. Include revocation between plan and execution and A2A-to-MCP delegation boundaries.

Prospective **R2-H33 (NOT TESTED)**: delegated mission authority remains a strict subset of both agent and user authority across cross-agent/cross-tool transitions, with zero authority amplification after revocation or delegation-chain break.

### Priority 5 — P12 business-semantic outcome tools

Move beyond development-object creation to a reversible/non-production business process with a clear domain outcome lifecycle. Compare atomic CRUD-style tools with outcome-oriented tools designed around business semantics, as SAP's MCP Gateway guidance itself recommends.

Prospective **R2-H34 (NOT TESTED)**: outcome-oriented tools improve correct mission completion and reduce unnecessary tool calls relative to semantically thin atomic API tools under equal backend permissions.

### Priority 6 — P13 consequential-write state, compensation, and replay

Test partial completion, observer outage, duplicate delivery, idempotency keys, compensation authorization, and long-running approval windows. Compensation must be a separately authorized mutation class, never an implicit cleanup right.

Prospective **R2-H35 (NOT TESTED)**: exact mutation budgets plus separately authorized compensation prevent retry-driven authority expansion under timeout, duplicate delivery, and partial failure.

### Priority 7 — P14 protocol/tool-contract drift CI

Treat tool schema, server version, and outcome semantics as versioned contracts. Run replay/conformance automatically across MCP server upgrades to detect incompatible changes before a mission reaches execution.

Prospective **R2-H36 (NOT TESTED)**: frozen capability-contract fingerprints detect behaviorally relevant schema/tool drift before execution with zero silent fallback.

These priorities give MCR a distinctive long-term research identity: **mission authority across time and heterogeneous governed capability surfaces**, rather than generic tool selection or generic MCP security.

---

## 20. Conclusion

R1.8 extends MCR from capability admission into a broader, but still bounded, enterprise-agent runtime thesis. P3-P5 support mission-qualified admission over the tested comparators. P6 shows bounded live read-only mechanism integrity against SAP. P7 shows that the same control model can be extended to temporal authority, fault conditions, federated attenuation, directional provider equivalence, and outcome-authoritative mission state while preserving a critical negative result: actual ADT MCP process loss did not automatically self-heal. P6-D1 then shows one tightly bounded live write path consuming exactly 2/2 authorized mutations, refusing to replay after observer timeout, and reaching `VALIDATED_COMPLETE` only after independent ATC observation.

The architectural contribution is best summarized as a mission-control plane above heterogeneous MCP execution surfaces: **the model proposes; the enterprise platform authenticates and authorizes; MCR further binds mission authority; the executor acts; evidence determines completion.** This positioning complements SAP's current direction toward governed MCP Gateway access, first-class agent identity, deterministic supervision, and harness engineering rather than competing with those controls.

The remaining scientific burden is substantial: independent replication, live multi-MCP federation, agent-identity delegation, gateway-integrated evaluation, business-semantic outcome validation, compensation, and production-relevant external validity are all open. R1.8 therefore strengthens the mechanism and sharpens the research identity without converting a bounded research program into an enterprise-safety certification.

---


<!-- MCR-R1.8-P8C1-BEGIN -->

## R1.8 P8-C1 Empirical Extension — Mission-Scoped Multi-MCP Execution

### Experimental scope

P8-C1 extends the mission-control evaluation into one bounded live mission across four heterogeneous MCP providers:

- SAP ADT MCP
- SAP Fiori MCP
- SAP UI5 MCP
- SAP CAP MCP

SAP BTP Administration MCP remained deferred.

### Live capability surface

The four active providers exposed **41 contract-requalified live tools**:

- ADT: 20
- Fiori: 9
- UI5: 10
- CAP: 2

Provider-aware authority classification produced:

- READ: **23**
- ANALYSIS: **7**
- local-mutation-capable: **5**
- enterprise-mutation-capable: **6**
- zero-write candidates: **30**

The distinction between discovery and authority remained explicit: provider visibility did not itself grant execution authority.

### Bounded mission contract

Exactly four READ-authority tools were frozen, one from each active provider.

The execution contract authorized:

- exactly 4 business-tool calls,
- zero retries,
- zero SAP writes,
- zero provider workspace mutations,
- zero BTP calls,
- zero model calls.

All four provider contract fingerprints were revalidated at point of use before the first business-tool execution.

### Live execution results

The bounded mission executed exactly four business-tool calls.

Results:

- executed: **4**
- successful: **4**
- failed: **0**
- independently validated outcomes: **4/4**
- retries: **0**
- SAP-read-capable tool calls: **1**
- SAP low-level request count: **NOT INSTRUMENTED**
- SAP writes: **0**
- provider scratch mutations: **0**
- BTP calls: **0**
- model calls: **0**

The low-level SAP request count beneath the SAP-read-capable MCP call was not instrumented and is therefore not inferred from the MCP tool-call count.

### Outcome-authoritative validation

P8-C1 retained the invariant:

**EXECUTED != COMPLETE**

Execution receipts were not accepted as mission completion.

Post-execution conformance independently checked:

1. the frozen READ-only mission contract,
2. captured result SHA-256 values,
3. MCP/JSON-RPC non-error outcome structure,
4. point-of-use provider contract fingerprints,
5. exact tool-call accounting,
6. zero-retry and zero-write accounting.

All four captured outcomes passed validation.

### Hypothesis update

**R2-H31 — Multi-MCP mission-scoped composition**

Status: **LIVE_BOUNDED_SUPPORT_OBSERVED**

One bounded live mission successfully composed four heterogeneous MCP providers under one mission-frozen READ-only authority set.

**R2-H33 — User → Agent → Mission delegation attenuation**

Status remains: **SYNTHETIC_CONFORMANCE_SUPPORT**

P8-C1 did not independently execute a new live delegation-chain experiment; therefore this hypothesis is not promoted to live support by P8-C1.

**R2-H36 — Contract fingerprinting**

Status: **LIVE_POINT_OF_USE_SUPPORT_OBSERVED**

All four provider contracts were fingerprint-revalidated immediately before bounded live execution.

R2-H32, R2-H34, and R2-H35 remain prospective and receive no empirical promotion from P8-C1.

### Limitations

The evidence remains intentionally bounded.

SAP BTP Administration MCP remained deferred.

Only one bounded four-provider mission was executed.

Only one business-tool call was classified as SAP-read-capable.

The low-level SAP request count was not instrumented.

No consequential SAP writes were authorized or tested.

No distributed transaction atomicity or compensation guarantee was tested.

Autonomous SAP ADT MCP self-healing remains unsupported.

Universal MCP provider equivalence is not established.

Production cross-provider failover is not established.

Enterprise-wide effectiveness is not established.

External independent replication remains outstanding.

### Follow-on experiments

The next experimental progression is:

1. P8-C2 — multi-mission live replication using distinct mission working sets.
2. P8-C3 — live temporal-expiry and contract-drift negative conformance.
3. Later BTP Administration MCP inclusion when client interoperability permits.
4. Consequential-write testing only under a separately frozen mutation and authorization contract.

<!-- MCR-R1.8-P8C1-END -->

## References

[F1] P. Deshpande. **From Tools to Missions: Reframing MCP for Agentic Orchestration -- A Mission-Capability Architecture for Enterprise AI Across Heterogeneous MCP Services.** Unpublished companion manuscript, 2026. Public citation form / preprint location not yet resolved at this freeze.

[1] Model Context Protocol. **Specification, revision 2026-07-28.** 28 July 2026. https://modelcontextprotocol.io/specification/2026-07-28

[2] Y. Qin, S. Liang, Y. Ye, K. Zhu, L. Yan, Y. Lu, Y. Lin, X. Cong, X. Tang, B. Qian, S. Zhao, L. Hong, R. Tian, R. Xie, J. Zhou, M. Gerstein, D. Li, Z. Liu, and M. Sun. **ToolLLM: Facilitating Large Language Models to Master 16000+ Real-world APIs.** International Conference on Learning Representations (ICLR), 2024; arXiv:2307.16789. https://proceedings.iclr.cc/paper_files/paper/2024/hash/28e50ee5b72e90b50e7196fde8ea260e-Abstract-Conference.html

[3] S. G. Patil, T. Zhang, X. Wang, and J. E. Gonzalez. **Gorilla: Large Language Model Connected with Massive APIs.** Advances in Neural Information Processing Systems 37 (NeurIPS 2024), Main Conference Track; arXiv:2305.15334. DOI: 10.52202/079017-4020. https://proceedings.neurips.cc/paper_files/paper/2024/hash/e4c61f578ff07830f5c37378dd3ecb0d-Abstract-Conference.html

[4] J. Zou, L. Yang, Y. Qi, S. Chen, M. Ai, K. Shen, J. He, and M. Wang. **AutoTool: Dynamic Tool Selection and Integration for Agentic Reasoning.** arXiv:2512.13278, 2025 (v1 submitted 15 Dec 2025; later revised in 2026). https://arxiv.org/abs/2512.13278

[5] R. Suresh Babu and L. G. Iyer. **ToolChoiceConfusion: Causal Minimal Tool Filtering for Reliable LLM Agents.** arXiv:2606.06284, 2026. https://arxiv.org/abs/2606.06284

[6] U. Franko. **Dynamic System Instructions and Tool Exposure for Efficient Agentic LLMs.** arXiv:2602.17046, 2025. The official arXiv record reports v1 submitted 1 Dec 2025 despite the `2602` identifier. https://arxiv.org/abs/2602.17046

[7] X. Hong, P. Dong, X. Yu, and B. Jiang. **Tools Are Not Islands: Set-Level Tool Retrieval for LLM Agents via Query-Conditioned Hyperedge Prediction.** arXiv:2607.25718, 2026. https://arxiv.org/abs/2607.25718

[8] R. Betser, A. Giloni, S. Bose, S. Padakandla, C. Picardi, L. Erez, and R. Vainshtein. **AgenTRIM: Tool Risk Mitigation for Agentic AI.** arXiv:2601.12449, 2026. https://arxiv.org/abs/2601.12449

[9] H. Xu, C. Li, X. Ma, X. Ou, Z. Zhang, T. He, X. Liu, Z. Wang, J. Liang, Z. Chu, R. Liu, R. Mu, D. Tu, M. Liu, and B. Qin. **The Evolution of Tool Use in LLM Agents: From Single-Tool Call to Multi-Tool Orchestration.** arXiv:2603.22862, 2026. https://arxiv.org/abs/2603.22862

[10] B. Liu, G. Zhao, and H. Xu. **Utility-Guided Agent Orchestration for Efficient LLM Tool Use.** arXiv:2603.19896, 2026. https://arxiv.org/abs/2603.19896

[11] D. Martin et al. **OWL-S: Semantic Markup for Web Services.** W3C Member Submission, 22 November 2004. https://www.w3.org/submissions/OWL-S/

[12] H. Lausen, A. Polleres, and D. Roman (eds.). **Web Service Modeling Ontology (WSMO).** W3C Member Submission, 3 June 2005. https://www.w3.org/submissions/WSMO/

[13] D. Wu, B. Parsia, E. Sirin, J. Hendler, and D. Nau. **Automating DAML-S Web Services Composition Using SHOP2.** In *The Semantic Web -- ISWC 2003*, Lecture Notes in Computer Science 2870, pp. 195-210, Springer, 2003. DOI: 10.1007/978-3-540-39718-2_13.

[14] P. Bartalos and M. Bielikova. **Automatic Dynamic Web Service Composition: A Survey and Problem Formalization.** *Computing and Informatics*, 30(4):793-827, 2011. https://www.cai.sk/ojs/index.php/cai/article/view/198

[15] A. Immonen and D. Pakkala. **A Survey of Methods and Approaches for Reliable Dynamic Service Compositions.** *Service Oriented Computing and Applications*, 8:129-158, 2014. DOI: 10.1007/s11761-013-0153-3.

*External references [1]-[24] were reviewed on 5 September 2026. References [1]-[15] preserve the R1.7 independent bibliographic verification; [16]-[24] are current SAP/SAP-associated primary documentation or project sources used for the R1.8 platform-positioning analysis. [F1] remains an unpublished companion manuscript and is the only unresolved citation-form/public-availability item; see `06_MCR_R1_8_REFERENCE_VERIFICATION_LIST_R1.md`.*

[16] SAP. **Model Context Protocol Tools — AI in ABAP Cloud / ADT MCP Server.** SAP Help Portal, accessed 5 September 2026. https://help.sap.com/docs/abap-ai/generative-ai-in-abap-cloud/mcp-tools

[17] SAP. **Model Context Protocol (MCP) — SAP Integration Suite.** SAP Help Portal, accessed 5 September 2026. https://help.sap.com/docs/integration-suite/isuite-integrations-and-apis/model-context-protocol-mcp

[18] SAP. **Public Release of the MCP Server for SAP BTP Administration.** SAP Community, 27 August 2026. https://community.sap.com/t5/technology-blog-posts-by-sap/public-release-of-the-mcp-server-for-sap-btp-administration/ba-p/14471692

[19] SAP Architecture Center. **Microsoft Copilot Studio and the MCP Gateway in SAP Integration Suite.** Updated 18 June 2026. https://architecture.learning.sap.com/docs/ref-arch/d2e34e

[20] SAP Architecture Center. **Build AI Agents on SAP BTP.** Updated 23 April 2026. https://architecture.learning.sap.com/docs/golden-path/ai-golden-path/build-and-deliver/build-ai-agents

[21] SAP Architecture Center. **Integration, Security, Ethics & Governance — AI-Native North Star Architecture.** Updated 13 May 2026. https://architecture.learning.sap.com/docs/ai-native-north-star-architecture/integration-security-ethics-governance

[22] SAP. **@sap-ux/fiori-mcp-server.** SAP Open UX Tools, GitHub, accessed 5 September 2026. https://github.com/SAP/open-ux-tools/blob/main/packages/fiori-mcp-server/README.md

[23] UI5 / SAP. **UI5 MCP Server.** GitHub, accessed 5 September 2026. https://github.com/UI5/mcp-server

[24] SAP Cloud Application Programming Model. **@cap-js/mcp-server — MCP server for AI-assisted development of CAP applications.** GitHub, accessed 5 September 2026. https://github.com/cap-js/mcp-server


---

## Data and evidence availability (not a bibliography)

Internal, program-generated evidence artifacts underlying Sections 8-13 (not literature citations): `MCR_R2E_P3_DS12_SEALED_TEST_AUTHORIZATION_AND_EXECUTION_R1.zip`; `MCR_R2E_P4_ADVERSARIAL_SEALED_CONFIRMATORY_EXECUTION_R1.zip`; `MCR_R2E_P5_CROSS_MODEL_SEALED_FINALIZATION_HF02.zip`; `MCR_R2E_P6_SCIENTIFIC_CLOSURE_R1.zip` (sha256 `23847b129bcb775f44a7278c7ae8d41d4a3ed1b54268683f1f0823795e7f427b`); `MCR_R1_7_PUBLICATION_FINAL_FREEZE_R1.zip` (sha256 `48fa1c707002314752245434f5bdc09f96c5deab6cc27bc05f0483908457f1f3`); P7 scientific-closure state recorded in the authoritative handover with closure sha256 `082cc73d151597b0faf28ea2bfa55171316dc522ac016c3bdb28a544b6682f52` (archive not independently re-opened in this assembly); `MCR_R2E_P6_D1_SCIENTIFIC_CLOSURE_R1.zip` (independently re-verified sha256 `d6eca3a411dc1e224dce677c404575a530c04bfb625852734802d61848ae953c`). Full provenance in `08_MCR_R1_8_SOURCE_MAP_R1.json`.

## Multi-Mission Live Execution Under Contract Drift and Governed Continuation

P8-C2 extends the P8-C1 governed empirical result with a bounded three-mission live execution sequence. The experiment planned eight business-tool calls across ABAP quality readiness, UX/CAP readiness, and fullstack readiness. The final scientific closure verified three validated missions, eight unique executed business calls, eight valid outcomes, zero failed business outcomes, zero retries, zero replayed business calls, zero SAP writes, zero local provider mutations, and zero BTP business calls.

The first design correction was capability identity. Provider-local tool names were insufficient as global capability identities because FIORI::search_docs and CAP::search_docs were distinct capabilities with the same tool name. Provider-qualified identity restored the mission working-set cardinalities to ABAP quality readiness 14, UX/CAP readiness 16, and fullstack readiness 30. This supports the bounded conclusion that heterogeneous MCP composition must include provider identity when same-named tools can occur across provider surfaces; it does not claim a universal MCP naming scheme.

The second observation was contract drift under version equality. The Fiori provider's previously frozen normalized contract fingerprint was 6065D8D76C231945BF318AA13D58ADB844B42EFDBC920ABF87E51DFF51B12443, while the independently requalified current fingerprint was E269792AAA025B050FFA9C833BCE68D6F9A931C9207B7DF2F2268F6EFA7A3EE3. Package version, server version, protocol version, and tool count remained equal, so version equality did not imply contract equality in this observed case. The historical C2B mismatch is preserved as a point-of-use mismatch; because the historical raw Fiori 	ools/list response was not captured, the subsequently observed five semantic differences are not asserted as the independently proven byte-for-byte cause of that earlier mismatch.

Point-of-use contract validation prevented progression into Mission 2 when the observed Fiori capability contract differed from the frozen admission state. Mission 1 had completed, the runtime failed closed before Mission 2 business execution, no blind retry occurred, and no completed business call was replayed. The current Fiori contract was then independently requalified across three fresh protocol sessions, the selected FIORI::list_sap_systems probe remained compatible, and an explicit Fiori-only rebase enabled Mission 2 continuation without replaying Mission 1.

Mission 3 exposed two local runtime implementation defects rather than provider or SAP failures. The first defect assumed $.dpapi_blob_base64 instead of the proven $.protected_token_b64 auth-context field. The second defect passed SSE framing directly into JSON parsing rather than extracting the data: JSON-RPC payload first. Both defects failed before Mission 3 business execution and were repaired through explicit governed intervention.

The supported H31 result is R2_H31_MULTI_MISSION_LIVE_EXECUTION_WITH_GOVERNED_RECOVERY_AND_CONTINUATION_SUPPORT=OBSERVED. The uninterrupted variant remains R2_H31_UNINTERRUPTED_MULTI_MISSION_LIVE_REPLICATION=NOT_OBSERVED_IN_C2. H36 is strengthened by observed repeated point-of-use validation, fail-closed contract mismatch detection, and requalification/continuation support. H33 remains SYNTHETIC_CONFORMANCE_ONLY. The publication language should therefore use governed requalification and continuation, not autonomous recovery or self-healing.
