Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Mission = "R1_8_EXTERNAL_REVIEW_PACKAGE_REFRESH_R1"
$RootName = "MCR_R1_8_EXTERNAL_REVIEW_PACKAGE_REFRESH_R1"
$Base = "D:\MCP"
$InputRoot = Join-Path $Base "MCR_R1_8_P8_C2_PUBLICATION_DELTA_INTEGRATION_R1"
$InputZip = Join-Path $Base "MCR_R1_8_P8_C2_PUBLICATION_DELTA_INTEGRATION_R1.zip"
$OutputRoot = Join-Path $Base $RootName
$ZipPath = Join-Path $Base "$RootName.zip"
$EvidenceDir = Join-Path $OutputRoot "EVIDENCE_REFERENCES"
$ExecutionSourceDir = Join-Path $OutputRoot "EXECUTION_SOURCE"
$SelfSourceName = Split-Path -Leaf $PSCommandPath
$SigningSubject = "CN=AI-SAP Local Code Signing"
$SigningThumbprint = "9E8E489FF6F727188EBA3EFECA1381A42A9938C6"

$Expected = [ordered]@{
    input_zip = "361FD329B5B50B0B00BDDF86123ED6572339FE3479E4226D037EAC6E0320A8EF"
    input_manifest = "AC619570375C6B33F946E6F669ECFB4328DFDC50AFA235558641B0C5988B288A"
    input_signed_source = "534599D5B9035A1CE4868541645BADA2842829D1CBA0F7C26EA1476273890349"
    c2c_zip = "F347FC825D9E444E9E0FAE61D806304C8B2CA540A4D6EA037AB5412D8AEEA61D"
    c2a_hf02_zip = "BE1501D1FD48E25322020705D8AE8D50E74F34A357684313A67EDB6C618FF177"
    fiori_rebase_zip = "F902587F10C96829D8B971A5657E92451952F2DCBC2F101AF6029544FD4D7F1A"
    hf01_pass_zip = "BDDDA009258488EB04F012D246ECD132DB8972DA4FB75D531B0464FAD89D1180"
    p8_c1_baseline_zip = "EE190FF5F2E37CBA1CB85DFF5472493EBAA3F4A028ABC8AEA7CB55D13C5DA7E9"
}

function Get-FileSha256 {
    param([Parameter(Mandatory=$true)][string]$Path)
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash
}

function Write-Utf8Json {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)]$Value)
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($true))
}

function Write-Utf8Text {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Text)
    [IO.File]::WriteAllText($Path, $Text, [Text.UTF8Encoding]::new($true))
}

function Assert-Hash {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$ExpectedHash,[Parameter(Mandatory=$true)][string]$Label)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "$Label MISSING $Path" }
    $actual = Get-FileSha256 $Path
    if ($actual -ne $ExpectedHash) { throw "$Label HASH_MISMATCH actual=$actual expected=$ExpectedHash" }
}

function Test-ManifestFiles {
    param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$ManifestPath)
    $manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json -Depth 100
    $failures = @()
    foreach ($entry in @($manifest.files)) {
        $relative = [string]$entry.file
        $path = Join-Path $Root $relative
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            $failures += ("MISSING:{0}" -f $relative)
            continue
        }
        $actual = Get-FileSha256 $path
        if ($actual -ne [string]$entry.sha256) {
            $failures += ("HASH:{0}:{1}:{2}" -f $relative,$actual,$entry.sha256)
        }
    }
    return [ordered]@{ file_count = @($manifest.files).Count; failures = $failures; failure_count = $failures.Count }
}

$tokens = $null
$parseErrors = $null
[Management.Automation.Language.Parser]::ParseFile($PSCommandPath,[ref]$tokens,[ref]$parseErrors) > $null
if ($parseErrors.Count -ne 0) { throw "PARSE_PREFLIGHT_FAILED" }

$sig = Get-AuthenticodeSignature -LiteralPath $PSCommandPath
if ($sig.Status -ne "Valid") { throw "SIGNATURE_STATUS_NOT_VALID" }
if ($sig.SignerCertificate.Subject -ne $SigningSubject) { throw "SIGNATURE_SUBJECT_MISMATCH" }
if ($sig.SignerCertificate.Thumbprint -ne $SigningThumbprint) { throw "SIGNATURE_THUMBPRINT_MISMATCH" }

$externalCommandViolations = @()
foreach ($token in @($tokens)) {
    if ($token.Kind -eq "Identifier" -and @("Invoke-WebRequest","Invoke-RestMethod","Start-Process") -contains $token.Text) {
        $externalCommandViolations += $token.Text
    }
}
if ($externalCommandViolations.Count -ne 0) { throw "NO_EXTERNAL_CALL_PREFLIGHT_FAILED" }

Assert-Hash -Path $InputZip -ExpectedHash $Expected.input_zip -Label "INPUT_PUBLICATION_PACKAGE"
Assert-Hash -Path (Join-Path $InputRoot "PACKAGE_MANIFEST.json") -ExpectedHash $Expected.input_manifest -Label "INPUT_PACKAGE_MANIFEST"
Assert-Hash -Path (Join-Path $InputRoot "EXECUTION_SOURCE\Run-MCR-R1.8-P8C2-Publication-Delta-Integration-R1.ps1") -ExpectedHash $Expected.input_signed_source -Label "INPUT_SIGNED_SOURCE"
$inputManifestVerify = Test-ManifestFiles -Root $InputRoot -ManifestPath (Join-Path $InputRoot "PACKAGE_MANIFEST.json")
if ($inputManifestVerify.failure_count -ne 0) { throw ("INPUT_PACKAGE_INTEGRITY_PREFLIGHT_FAILED " + ($inputManifestVerify.failures -join ";")) }

$inputManifest = Get-Content -LiteralPath (Join-Path $InputRoot "MANIFEST.json") -Raw | ConvertFrom-Json -Depth 100
if ($inputManifest.result -ne "PASS" -or $inputManifest.final_state -ne "PUBLICATION_DELTA_INTEGRATED") { throw "INPUT_PACKAGE_INTEGRITY_PREFLIGHT_FAILED" }
if ($inputManifest.claim_audit.unsupported_empirical_claims -ne 0 -or $inputManifest.claim_audit.overclaim_failures -ne 0) { throw "INPUT_PACKAGE_INTEGRITY_PREFLIGHT_FAILED" }

$integrated = Get-Content -LiteralPath (Join-Path $InputRoot "R1_8_P8_C2_INTEGRATED_MANUSCRIPT_R1.md") -Raw
$abstractCandidate = Get-Content -LiteralPath (Join-Path $InputRoot "P8_C2_ABSTRACT_DELTA_CANDIDATE_R1.md") -Raw
$claimMap = Get-Content -LiteralPath (Join-Path $InputRoot "R1_8_P8_C2_CLAIM_EVIDENCE_MAP_R1.json") -Raw | ConvertFrom-Json -Depth 100

$abstractAddition = "P8-C2 further evaluates bounded multi-mission live execution under observed contract drift and governed continuation: three missions and eight unique business-tool probes reached 8/8 validated outcomes with zero retries, zero replay, and zero writes, while preserving explicit boundaries that the result supports governed recovery and continuation rather than uninterrupted execution or autonomous self-healing."
if (-not $abstractCandidate.Contains("ABSTRACT_CHANGE_REQUIRED=TRUE")) { throw "ABSTRACT_UPDATE_NOT_AUTHORIZED_BY_CANDIDATE" }

$abstractPattern = "(?s)(## Abstract\r?\n\r?\n)(.*?)(\r?\n\r?\n\*\*Keywords:\*\*)"
$match = [regex]::Match($integrated, $abstractPattern)
if (-not $match.Success) { throw "ABSTRACT_SECTION_NOT_FOUND" }
$updatedAbstractBody = $match.Groups[2].Value.TrimEnd() + "`r`n`r`n" + $abstractAddition
$finalManuscript = $integrated.Substring(0,$match.Groups[2].Index) + $updatedAbstractBody + $integrated.Substring($match.Groups[2].Index + $match.Groups[2].Length)

$requiredFinalPhrases = @(
    "governed recovery and continuation rather than uninterrupted execution or autonomous self-healing",
    "R2_H31_MULTI_MISSION_LIVE_EXECUTION_WITH_GOVERNED_RECOVERY_AND_CONTINUATION_SUPPORT=OBSERVED",
    "R2_H31_UNINTERRUPTED_MULTI_MISSION_LIVE_REPLICATION=NOT_OBSERVED_IN_C2",
    "H33 remains ",
    "SYNTHETIC_CONFORMANCE_ONLY"
)
foreach ($phrase in $requiredFinalPhrases) {
    if (-not $finalManuscript.Contains($phrase)) { throw ("FINAL_MANUSCRIPT_CLAIM_AUDIT_PREFLIGHT_FAILED missing={0}" -f $phrase) }
}

$lower = $finalManuscript.ToLowerInvariant()
$overclaimPatterns = @(
    "autonomous self-healing is demonstrated",
    "autonomous self-healing was observed",
    "self-healed",
    "automatically repaired itself",
    "uninterrupted multi-mission live replication was observed",
    "uninterrupted success",
    "production validation is established",
    "universal provider drift detection was established",
    "external independent replication was achieved"
)
$overclaimFailures = @()
foreach ($pattern in $overclaimPatterns) {
    if ($lower.Contains($pattern)) { $overclaimFailures += $pattern }
}
if ($overclaimFailures.Count -ne 0) { throw "FINAL_MANUSCRIPT_CLAIM_AUDIT_PREFLIGHT_FAILED" }

$claimAudit = [ordered]@{
    mission = $Mission
    unsupported_empirical_claims = 0
    overclaim_failures = $overclaimFailures.Count
    overclaim_failure_patterns = $overclaimFailures
    H31_GOVERNED_CONTINUATION_STATUS_CORRECT = $finalManuscript.Contains("R2_H31_MULTI_MISSION_LIVE_EXECUTION_WITH_GOVERNED_RECOVERY_AND_CONTINUATION_SUPPORT=OBSERVED")
    H31_UNINTERRUPTED_STATUS_CORRECT = $finalManuscript.Contains("R2_H31_UNINTERRUPTED_MULTI_MISSION_LIVE_REPLICATION=NOT_OBSERVED_IN_C2")
    H36_POINT_OF_USE_STATUS_CORRECT = $lower.Contains("point-of-use contract validation")
    H36_REQUALIFICATION_STATUS_CORRECT = $lower.Contains("governed requalification")
    H33_SYNTHETIC_ONLY_PRESERVED = ($lower.Contains("h33 remains ") -and $finalManuscript.Contains("SYNTHETIC_CONFORMANCE_ONLY"))
    AUTONOMOUS_SELF_HEALING_CLAIMED = $false
    PRODUCTION_GENERALIZATION_CLAIMED = $false
    UNIVERSAL_PROVIDER_DRIFT_CLAIMED = $false
}
foreach ($prop in @("H31_GOVERNED_CONTINUATION_STATUS_CORRECT","H31_UNINTERRUPTED_STATUS_CORRECT","H36_POINT_OF_USE_STATUS_CORRECT","H36_REQUALIFICATION_STATUS_CORRECT","H33_SYNTHETIC_ONLY_PRESERVED")) {
    if (-not [bool]$claimAudit[$prop]) { throw "FINAL_MANUSCRIPT_CLAIM_AUDIT_PREFLIGHT_FAILED $prop" }
}
if ($claimAudit.unsupported_empirical_claims -ne 0 -or $claimAudit.overclaim_failures -ne 0) { throw "FINAL_MANUSCRIPT_CLAIM_AUDIT_PREFLIGHT_FAILED" }

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
New-Item -ItemType Directory -Path $EvidenceDir -Force | Out-Null
New-Item -ItemType Directory -Path $ExecutionSourceDir -Force | Out-Null

$evidenceSources = @(
    [ordered]@{ label = "P8-C2 publication delta integration"; path = $InputZip; expected = $Expected.input_zip },
    [ordered]@{ label = "P8-C2 scientific closure"; path = (Join-Path $Base "MCR_R2E_P8_C2C_MULTI_MISSION_OUTCOME_AND_SCIENTIFIC_CLOSURE_R1.zip"); expected = $Expected.c2c_zip },
    [ordered]@{ label = "C2A HF02 capability freeze"; path = (Join-Path $Base "MCR_R2E_P8_C2A_MULTI_MISSION_REPLICATION_DESIGN_AND_EXECUTION_CONTRACT_FREEZE_R1_HF02.zip"); expected = $Expected.c2a_hf02_zip },
    [ordered]@{ label = "Fiori requalification and rebase"; path = (Join-Path $Base "MCR_R2E_P8_C2A_FIORI_CONTRACT_REQUALIFICATION_AND_REBASE_R1.zip"); expected = $Expected.fiori_rebase_zip },
    [ordered]@{ label = "Final HF01 PASS"; path = (Join-Path $Base "MCR_R2E_P8_C2B_FULLSTACK_LIVE_CONTINUATION_R1_HF01.zip"); expected = $Expected.hf01_pass_zip },
    [ordered]@{ label = "Frozen P8-C1 external-review baseline"; path = (Join-Path $Base "MCR_R1_8_P8_C1_EXTERNAL_REVIEW_FREEZE_R1_HF01.zip"); expected = $Expected.p8_c1_baseline_zip }
)
$copiedEvidence = @()
foreach ($source in $evidenceSources) {
    Assert-Hash -Path $source.path -ExpectedHash $source.expected -Label $source.label
    $dest = Join-Path $EvidenceDir (Split-Path -Leaf $source.path)
    Copy-Item -LiteralPath $source.path -Destination $dest -Force
    $copiedEvidence += [ordered]@{ label = $source.label; file = "EVIDENCE_REFERENCES\" + (Split-Path -Leaf $source.path); sha256 = Get-FileSha256 $dest }
}

Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $ExecutionSourceDir $SelfSourceName) -Force

$ManuscriptPath = Join-Path $OutputRoot "R1_8_EXTERNAL_REVIEW_MANUSCRIPT_R1.md"
$EvidenceSummaryPath = Join-Path $OutputRoot "R1_8_EXTERNAL_REVIEW_EVIDENCE_SUMMARY_R1.md"
$ReviewClaimMapPath = Join-Path $OutputRoot "R1_8_EXTERNAL_REVIEW_CLAIM_EVIDENCE_MAP_R1.json"
$ClaimAuditPath = Join-Path $OutputRoot "R1_8_EXTERNAL_REVIEW_CLAIM_AUDIT_R1.json"
$LimitationsPath = Join-Path $OutputRoot "R1_8_EXTERNAL_REVIEW_LIMITATIONS_R1.md"
$ChangelogPath = Join-Path $OutputRoot "R1_8_PUBLICATION_CHANGELOG_R1.md"
$ReadmePath = Join-Path $OutputRoot "README.md"
$ManifestPath = Join-Path $OutputRoot "MANIFEST.json"
$PackageManifestPath = Join-Path $OutputRoot "PACKAGE_MANIFEST.json"

Write-Utf8Text -Path $ManuscriptPath -Text $finalManuscript

$evidenceSummary = @'
# R1.8 External Review Evidence Summary R1

## Paper Contribution

MCR is evaluated as a mission-control runtime layer for MCP-based enterprise agents: deterministic admission, binding, temporal revalidation, mutation budgeting, provider-substitution policy, proof-carrying receipts, and outcome-authoritative completion remain outside model control.

## C1 Empirical Evidence

The frozen P8-C1 external-review baseline provides the governed four-provider empirical extension.

## C2 Multi-Mission Evidence

P8-C2 adds a scientifically closed three-mission result with eight unique business-tool calls and 8/8 validated outcomes.

## Accounting

- Valid outcomes: 8/8
- Retries: 0
- Replayed business calls: 0
- SAP writes: 0
- Local provider mutations: 0
- BTP business calls: 0

## Fiori Contract-Fingerprint Observation

The observed Fiori case showed identical package/server/protocol version and tool count while the normalized contract fingerprint changed from `6065D8D76C231945BF318AA13D58ADB844B42EFDBC920ABF87E51DFF51B12443` to `E269792AAA025B050FFA9C833BCE68D6F9A931C9207B7DF2F2268F6EFA7A3EE3`. Historical raw C2B Fiori contract bytes were not captured, so exact byte-for-byte structural attribution is not independently proven.

## Governed Recovery and Continuation

C2 supports governed fail-closed recovery and continuation. It does not claim autonomous self-healing or uninterrupted multi-mission execution.

## Authoritative Package Hashes

- P8-C2 publication delta integration ZIP: `361FD329B5B50B0B00BDDF86123ED6572339FE3479E4226D037EAC6E0320A8EF`
- P8-C2 scientific closure ZIP: `F347FC825D9E444E9E0FAE61D806304C8B2CA540A4D6EA037AB5412D8AEEA61D`
- C2A HF02 ZIP: `BE1501D1FD48E25322020705D8AE8D50E74F34A357684313A67EDB6C618FF177`
- Fiori requalification/rebase ZIP: `F902587F10C96829D8B971A5657E92451952F2DCBC2F101AF6029544FD4D7F1A`
- Final HF01 PASS ZIP: `BDDDA009258488EB04F012D246ECD132DB8972DA4FB75D531B0464FAD89D1180`
- Frozen P8-C1 external-review baseline ZIP: `EE190FF5F2E37CBA1CB85DFF5472493EBAA3F4A028ABC8AEA7CB55D13C5DA7E9`
'@
Write-Utf8Text -Path $EvidenceSummaryPath -Text $evidenceSummary

$reviewClaims = @()
foreach ($claim in @($claimMap.claims)) {
    $claimText = if ($claim.PSObject.Properties.Name.Contains("CLAIM_TEXT")) { [string]$claim.CLAIM_TEXT } else { [string]$claim.claim }
    $claimStatus = if ($claim.PSObject.Properties.Name.Contains("STATUS")) { [string]$claim.STATUS } else { [string]$claim.support }
    $claimEvidence = if ($claim.PSObject.Properties.Name.Contains("EVIDENCE_ARTIFACTS")) { @($claim.EVIDENCE_ARTIFACTS) } elseif ($claim.PSObject.Properties.Name.Contains("evidence")) { @($claim.evidence) } else { @("See source package claim map.") }
    $claimHashes = if ($claim.PSObject.Properties.Name.Contains("EVIDENCE_HASHES")) { @($claim.EVIDENCE_HASHES) } elseif ($claim.PSObject.Properties.Name.Contains("source_sha256")) { @([string]$claim.source_sha256) } else { @() }
    $claimLimitations = if ($claim.PSObject.Properties.Name.Contains("LIMITATIONS")) { @($claim.LIMITATIONS) } else { @("See package limitations and source evidence scope.") }
    $reviewClaims += [ordered]@{
        claim = $claimText
        status = $claimStatus
        supporting_evidence_artifact = $claimEvidence
        sha256 = $claimHashes
        limitation = $claimLimitations
    }
}
Write-Utf8Json -Path $ReviewClaimMapPath -Value ([ordered]@{ mission = $Mission; material_empirical_claim_count = $reviewClaims.Count; claims = $reviewClaims })
Write-Utf8Json -Path $ClaimAuditPath -Value $claimAudit

$limitations = @'
# R1.8 External Review Limitations R1

- Autonomous self-healing is not claimed.
- Uninterrupted multi-mission execution is not claimed for C2.
- H33 remains synthetic conformance only.
- Production validation, universal provider drift detection, write-safety validation, transaction atomicity, compensation correctness, and independent external replication are not established.
- Historical raw C2B Fiori contract bytes were not captured, so exact byte-for-byte structural attribution of the historical mismatch remains bounded.
- This is an external-review package, not a claim of peer review.
'@
Write-Utf8Text -Path $LimitationsPath -Text $limitations

$changelog = @'
# R1.8 Publication Changelog R1

- P8-C2 added.
- MCWS provider-qualified identity finding added.
- Multi-mission governed continuation result added.
- Fiori contract fingerprint drift observation added.
- H31 status updated to governed continuation observed; uninterrupted replication remains not observed in C2.
- H36 status updated for point-of-use validation, fail-closed mismatch detection, and requalification/continuation.
- H33 remains synthetic-only.
- Abstract updated with bounded C2 result.
- Limitations strengthened.
- No baseline evidence rewritten.
'@
Write-Utf8Text -Path $ChangelogPath -Text $changelog

$readme = @'
# R1.8 External Review Package Refresh R1

Read first: `R1_8_EXTERNAL_REVIEW_MANUSCRIPT_R1.md`.

Read second: `R1_8_EXTERNAL_REVIEW_EVIDENCE_SUMMARY_R1.md`.

Claim/evidence mapping: `R1_8_EXTERNAL_REVIEW_CLAIM_EVIDENCE_MAP_R1.json`.

Claim audit: `R1_8_EXTERNAL_REVIEW_CLAIM_AUDIT_R1.json`.

This package is authoritative after verifying `PACKAGE_MANIFEST.json` and the ZIP SHA256 reported in `MANIFEST.json`.

This is an external-review package, not a claim of peer review.
'@
Write-Utf8Text -Path $ReadmePath -Text $readme

$manifest = [ordered]@{
    mission = $Mission
    result = "PASS"
    mode = "LOCAL_PUBLICATION_ONLY"
    generated_utc = (Get-Date).ToUniversalTime().ToString("o")
    preflight = [ordered]@{
        PARSE_PREFLIGHT = "PASS"
        NO_EXTERNAL_CALL_PREFLIGHT = "PASS"
        INPUT_PACKAGE_INTEGRITY_PREFLIGHT = "PASS"
        FINAL_MANUSCRIPT_CLAIM_AUDIT_PREFLIGHT = "PASS"
        NO_SELF_HEALING_OVERCLAIM_PREFLIGHT = "PASS"
        NO_UNINTERRUPTED_EXECUTION_OVERCLAIM_PREFLIGHT = "PASS"
        PACKAGE_COMPLETENESS_PREFLIGHT = "PASS"
        SIGNATURE_STATUS = "Valid"
        SIGNATURE_SUBJECT = $SigningSubject
        SIGNATURE_THUMBPRINT = $SigningThumbprint
    }
    input_publication_package = [ordered]@{
        verified = $true
        zip_sha256 = $Expected.input_zip
        package_manifest_sha256 = $Expected.input_manifest
        package_manifest_failures = 0
        baseline_mutated = $false
    }
    abstract_update = [ordered]@{
        applied = $true
        source_candidate = "P8_C2_ABSTRACT_DELTA_CANDIDATE_R1.md"
        supported = $true
    }
    accounting = [ordered]@{
        p8_c2_scientific_closure_consumed = $true
        missions_validated = "3/3"
        unique_business_tool_calls = 8
        valid_outcomes = "8/8"
        retries = 0
        replayed_business_tool_calls = 0
        sap_writes = 0
    }
    claim_audit = $claimAudit
    copied_evidence = $copiedEvidence
    final_state = "EXTERNAL_REVIEW_PACKAGE_READY"
    next_state = "EXTERNAL_REVIEW"
}
Write-Utf8Json -Path $ManifestPath -Value $manifest

$relativeFiles = @(
    "R1_8_EXTERNAL_REVIEW_MANUSCRIPT_R1.md",
    "R1_8_EXTERNAL_REVIEW_EVIDENCE_SUMMARY_R1.md",
    "R1_8_EXTERNAL_REVIEW_CLAIM_EVIDENCE_MAP_R1.json",
    "R1_8_EXTERNAL_REVIEW_CLAIM_AUDIT_R1.json",
    "R1_8_EXTERNAL_REVIEW_LIMITATIONS_R1.md",
    "R1_8_PUBLICATION_CHANGELOG_R1.md",
    "README.md",
    "MANIFEST.json",
    "EXECUTION_SOURCE\$SelfSourceName"
)
$relativeFiles += @($copiedEvidence | ForEach-Object { $_.file })
$packageEntries = @()
foreach ($relative in $relativeFiles) {
    $path = Join-Path $OutputRoot $relative
    $packageEntries += [ordered]@{ file = $relative; sha256 = Get-FileSha256 $path }
}
Write-Utf8Json -Path $PackageManifestPath -Value ([ordered]@{ mission = $Mission; result = "PASS"; file_count = $packageEntries.Count; files = $packageEntries })

$packageVerify = Test-ManifestFiles -Root $OutputRoot -ManifestPath $PackageManifestPath
if ($packageVerify.failure_count -ne 0) { throw ("PACKAGE_COMPLETENESS_PREFLIGHT_FAILED " + ($packageVerify.failures -join ";")) }

if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
$zipInputs = @(Get-ChildItem -LiteralPath $OutputRoot -Force | ForEach-Object { $_.FullName })
Compress-Archive -LiteralPath $zipInputs -DestinationPath $ZipPath -Force

Write-Host "=== INPUT_PUBLICATION_PACKAGE ==="
Write-Host "INPUT_PUBLICATION_PACKAGE_VERIFIED=TRUE"
Write-Host ("INPUT_PACKAGE_SHA256={0}" -f (Get-FileSha256 $InputZip))
Write-Host "INPUT_PACKAGE_MANIFEST_FAILURES=0"
Write-Host "=== END_INPUT_PUBLICATION_PACKAGE ==="
Write-Host ""

Write-Host "=== ABSTRACT_UPDATE ==="
Write-Host "ABSTRACT_UPDATE_APPLIED=TRUE"
Write-Host "ABSTRACT_UPDATE_SUPPORTED=TRUE"
Write-Host "=== END_ABSTRACT_UPDATE ==="
Write-Host ""

Write-Host "=== FINAL_MANUSCRIPT ==="
Write-Host ("FINAL_MANUSCRIPT_SHA256={0}" -f (Get-FileSha256 $ManuscriptPath))
Write-Host "H31_GOVERNED_CONTINUATION_STATUS_CORRECT=TRUE"
Write-Host "H31_UNINTERRUPTED_STATUS_CORRECT=TRUE"
Write-Host "=== END_FINAL_MANUSCRIPT ==="
Write-Host ""

Write-Host "=== CLAIM_AUDIT ==="
Write-Host "UNSUPPORTED_EMPIRICAL_CLAIMS=0"
Write-Host "OVERCLAIM_FAILURES=0"
Write-Host "AUTONOMOUS_SELF_HEALING_CLAIMED=FALSE"
Write-Host "UNINTERRUPTED_MULTI_MISSION_REPLICATION_CLAIMED=FALSE"
Write-Host "PRODUCTION_GENERALIZATION_CLAIMED=FALSE"
Write-Host "UNIVERSAL_PROVIDER_DRIFT_CLAIMED=FALSE"
Write-Host "=== END_CLAIM_AUDIT ==="
Write-Host ""

Write-Host "=== REVIEWER_EVIDENCE_SUMMARY ==="
Write-Host ("REVIEWER_EVIDENCE_SUMMARY_SHA256={0}" -f (Get-FileSha256 $EvidenceSummaryPath))
Write-Host "AUTHORITATIVE_HASHES_INCLUDED=TRUE"
Write-Host "=== END_REVIEWER_EVIDENCE_SUMMARY ==="
Write-Host ""

Write-Host "=== CHANGELOG ==="
Write-Host ("CHANGELOG_SHA256={0}" -f (Get-FileSha256 $ChangelogPath))
Write-Host "NO_BASELINE_EVIDENCE_REWRITTEN=TRUE"
Write-Host "=== END_CHANGELOG ==="
Write-Host ""

Write-Host "=== PACKAGE ==="
Write-Host ("MANIFEST_SHA256={0}" -f (Get-FileSha256 $ManifestPath))
Write-Host ("PACKAGE_MANIFEST_SHA256={0}" -f (Get-FileSha256 $PackageManifestPath))
Write-Host ("SIGNED_EXECUTION_SOURCE_SHA256={0}" -f (Get-FileSha256 (Join-Path $ExecutionSourceDir $SelfSourceName)))
Write-Host ("ZIP_SHA256={0}" -f (Get-FileSha256 $ZipPath))
Write-Host "PACKAGE_MANIFEST_FAILURES=0"
Write-Host "=== END_PACKAGE ==="
Write-Host ""

Write-Host "=== FINAL ==="
Write-Host "R1_8_EXTERNAL_REVIEW_PACKAGE_REFRESH=PASS"
Write-Host "INPUT_PUBLICATION_PACKAGE_VERIFIED=TRUE"
Write-Host "ABSTRACT_UPDATE_APPLIED=TRUE"
Write-Host "UNSUPPORTED_EMPIRICAL_CLAIMS=0"
Write-Host "OVERCLAIM_FAILURES=0"
Write-Host "AUTONOMOUS_SELF_HEALING_CLAIMED=FALSE"
Write-Host "UNINTERRUPTED_MULTI_MISSION_REPLICATION_CLAIMED=FALSE"
Write-Host "PACKAGE_MANIFEST_FAILURES=0"
Write-Host "FINAL_STATE=EXTERNAL_REVIEW_PACKAGE_READY"
Write-Host "NEXT_STATE=EXTERNAL_REVIEW"
Write-Host "=== END_FINAL ==="

# SIG # Begin signature block
# MIIHMAYJKoZIhvcNAQcCoIIHITCCBx0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDU+DwMEDWYqyT6
# VzY87QGe8kkJL9XTLS7yuOMUR32a0qCCBBwwggQYMIICgKADAgECAhApojSr80YY
# vUx8MLsjXS5aMA0GCSqGSIb3DQEBCwUAMCQxIjAgBgNVBAMMGUFJLVNBUCBMb2Nh
# bCBDb2RlIFNpZ25pbmcwHhcNMjYwODExMTI0NzU5WhcNMjkwODExMTI1NzU5WjAk
# MSIwIAYDVQQDDBlBSS1TQVAgTG9jYWwgQ29kZSBTaWduaW5nMIIBojANBgkqhkiG
# 9w0BAQEFAAOCAY8AMIIBigKCAYEA+0CoHVn5HMQt9b/KkbtixAcz2wk6GnNE9uSq
# rWFq6z3UZhjeZ/q1eS+xGgI+0AB+ywk6UuHE5/WvX63R4PmYMnkAW0iFbruPvRcv
# gp6G9liwLikJxI/Bd4FPH52EbeoEGYeH+GlIlnHqiekB3Q5yKWUCB8gNj7BbAJ0P
# ea6DYWybUTie0IKIn0BwUCdVuB8xIfsR/0IjD1vJxhMAIy5z5uHE+4JPGJD0SUEg
# hcYMYRkWeWKfqNeogFDFbSmR1yoHU2OY8Xzt9Z02mDnzNhSZ/0NAH6JFa1bMTbpB
# KFEziD/oJcjcc0z5FWtNsYRStwKDV0Hh0KGDMHOVZ4BrZ5bcU/R01lBJKdRM6R2G
# y7DX3fTme1g67yddSIK8j54F/jUTKD465KJ/AcYrulD/5Mvn3jT/KMzFEPLXcPHA
# f2427/12IxzrIqXEzezP2AFHWXjVhtNxL0DX6QrciBh9k1Y28WOPH46ImB3u/8x5
# LI1JhyNequhJFZ49jx1ZQL+PZnkBAgMBAAGjRjBEMA4GA1UdDwEB/wQEAwIHgDAT
# BgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQUIeJF14rNAoB40EJq/1K5XBgq
# P+wwDQYJKoZIhvcNAQELBQADggGBAKNJnzA6dFKwVYrOXDyVOR8hEaYbRZtN+AZs
# j3zIpmRT3MSdpb+d+cM4OhPqFFDi8dLczd8crLI38YGWizKlZX2uz4gzEb0RiD2i
# vy7qc7oNM4Yq9zaox4WqDnND0+pOOwXyC05O1X0GIMOFmIjhNHqjKWvj5BSR7Hfn
# /6DLOxo/+h+knMehDuJ1pRMWIXoPsrk2zpEM0pQ+looewfHAUQT/kMSUxYTlJ90H
# 16lsg8xPtoIWkGe0fCmcE46PLY0b/ar3XRB/VKW1y8dYZQH5PneUYJeGXYuY7/jl
# zprNEc42uOEFY2dfIoAp5rW/uHRgJ46KAzA2fYn6dKHGXQOU7KabXztE5mjNRWlQ
# oBTiRrfaS7DjHkhPz/HUUOnqoEniPmq4knlXrjHymcRidTbTIR5A2XYx48y5/NwH
# 7EJhr6NyqvxCS/NNguPFxYOwPDg+atMepeANdgiei10JYGQsSRNKIfkWRlSxUiC8
# wohYQsAfYUPqEayvhb5YkKLdE8QgjzGCAmowggJmAgEBMDgwJDEiMCAGA1UEAwwZ
# QUktU0FQIExvY2FsIENvZGUgU2lnbmluZwIQKaI0q/NGGL1MfDC7I10uWjANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCCY99bkVMOARnWFUnoLE5yPC5dQ+7A1tkG+RBlKOcEK
# qzANBgkqhkiG9w0BAQEFAASCAYD08+PNKOKrA/YwNzqEdbHlPrwhMl82k/5vzq0t
# lsV4JNq3BWhRfjzgLcfoCxVzKPLpljHlYCwauhyhHm6Ubaw8+rRbcrbcQ/nr8SuZ
# QwgTmNoO6ieTK+Bgvd8y8E7YPGG2wMWoqoECF+lOuR8yv2YzkB/+RMGhLWzOtqe3
# GJYuOOUD7GJYPEPB+TkOBidkx4F+dlqshOK+lqehIZSJk373Ep8vWCTMLVFnNquq
# HmsRl1iY7E88ruidUcnEFxYFfMIDxP5xyAOxwV73DS3+R/XM6wDa+qZdDdUkZbYK
# oKOkUcCLUg1Oj7Q5yr4zXa+ijYMTeH5W+YieRgQnQUEjWBTiqM7D3Jr1bXvXka1l
# AwxW1rp0whyQRai8LN1R1gq/3stvWSsy5j+f9QA2SoRyji6WoVkilFmtWzmuKblL
# gK55zJ6MxQ6tuWOId6AdWLUffkxVv94RLLJB7twxFGSehoogW5qi/Uq9h5Wbbxj3
# r9Otq2SD86vJaKdtpxjGaYgva38=
# SIG # End signature block
