﻿# V1.9A Fast-Path Runtime Spec R1

EvaluateExecutionAdmission consumes PrincipalContext, DelegationEnvelope, MissionExecutionEnvelope, MutationBudget, ContractLease, requested provider/capability/operation/target, transaction state, idempotency key, and current time.

Return values are deterministic: ALLOW or a DENY reason.

Required DENY reasons:

- PRINCIPAL_INVALID
- AUTHORITY_NOT_GRANTED
- AUTHORITY_AMPLIFICATION_ATTEMPT
- PROVIDER_NOT_ALLOWED
- CAPABILITY_NOT_ALLOWED
- OPERATION_NOT_ALLOWED
- TARGET_NOT_ALLOWED
- MUTATION_BUDGET_EXHAUSTED
- AUTHORITY_EXPIRED
- CONTRACT_LEASE_INVALID
- CONTRACT_BREAKING_CHANGE
- TRANSACTION_INVALID
- IDEMPOTENCY_VIOLATION
- CHECKPOINT_INVALID

No network access and no LLM call occur in the authorization fast path.