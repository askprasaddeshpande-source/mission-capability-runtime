Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Mission = "MCR_R1_9_B_LIVE_GOVERNED_MUTATION_AND_OUTCOME_R1"
$Base = "D:\MCP"
$OutputRoot = Join-Path $Base $Mission
$ZipPath = Join-Path $Base "${Mission}_PREWRITE_FREEZE.zip"
$ExecutionSourceDir = Join-Path $OutputRoot "EXECUTION_SOURCE"
$PrepSourceName = Split-Path -Leaf $PSCommandPath
$LiveSource = Join-Path $Base "Run-MCR-R1.9B-Live-Governed-Mutation-And-Outcome-R1.ps1"
$LiveSourceName = Split-Path -Leaf $LiveSource
$SigningSubject = "CN=AI-SAP Local Code Signing"
$SigningThumbprint = "9E8E489FF6F727188EBA3EFECA1381A42A9938C6"
$V19ARoot = Join-Path $Base "MCR_R1_9_A_GOVERNED_EXECUTION_FOUNDATION_R1"
$V19AZip = Join-Path $Base "MCR_R1_9_A_GOVERNED_EXECUTION_FOUNDATION_R1.zip"
$V19APackageManifest = Join-Path $V19ARoot "23_PACKAGE_MANIFEST_R1.json"
$V19ASource = Join-Path $V19ARoot "EXECUTION_SOURCE\Run-MCR-R1.9A-Governed-Execution-Foundation-R1.ps1"
$AuthContextPath = Join-Path $Base "MCR_R2E_P8_C1A_ADT_AUTH_BINDING_PROBE_R1\ADT_AUTH_CONTEXT_R1.json"
$AdtContractPath = Join-Path $Base "MCR_R2E_P8_C2B_FULLSTACK_LIVE_CONTINUATION_R1_HF01\POINT_OF_USE_CONTRACTS\ADT\normalized_contract.json"
$P6D1ContractPath = Join-Path $Base "MCR_R2E_P6_D1_BOUNDED_OBJECT_WRITE_FREEZE_R1\P6_D1_FROZEN_MUTATION_CONTRACT_R1.json"

$Expected = [ordered]@{
    v19a_zip = "4F018E2F1EBE86AEF78E94989685B02A2E41BFFB73238A21F63AC12C8190E1F2"
    v19a_package_manifest = "4D12972AB9D1EA656017AF9D40C8DC2BE5C8D2300651A5A4379D4AB97339F525"
    v19a_source = "C42E09CA4A00DB88B011CD2B693851CC6EDAC1664C0A44CB7DDDDB97D6959237"
    auth_context = "155D6B0DA47E1DDD85C1F9A1F08786192BA76ED103759A8E53D88712A2D89863"
    adt_contract_full = "52B73C5745214199FA6A7FF25608B187ADD3EC2B0FEAD7DA7D23204155F7E166"
    p6d1_write_runner = "0EF582E902830608A1C4052CED72E4E7BFEED5AD9B2459DA1B49A616A1CCB682"
}

function Get-FileSha256 { param([Parameter(Mandatory=$true)][string]$Path) (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash }
function Get-CanonicalJson { param([Parameter(Mandatory=$true)]$Value) ($Value | ConvertTo-Json -Depth 100 -Compress) }
function Get-TextSha256 {
    param([Parameter(Mandatory=$true)][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text))).Replace("-","") }
    finally { $sha.Dispose() }
}
function Get-ObjectHash { param([Parameter(Mandatory=$true)]$Value) Get-TextSha256 (Get-CanonicalJson $Value) }
function Write-Utf8Json { param([string]$Path,$Value) [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($true)) }
function Write-Utf8Text { param([string]$Path,[string]$Text) [IO.File]::WriteAllText($Path, $Text, [Text.UTF8Encoding]::new($true)) }
function Assert-Hash { param([string]$Path,[string]$Hash,[string]$Label) if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){throw "$Label MISSING"}; $actual=Get-FileSha256 $Path; if($actual -ne $Hash){throw "$Label HASH_MISMATCH actual=$actual expected=$Hash"} }
function Test-ManifestFiles {
    param([string]$Root,[string]$ManifestPath)
    $manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json -Depth 100
    $failures = @()
    foreach($entry in @($manifest.files)){
        $path = Join-Path $Root ([string]$entry.file)
        if(-not(Test-Path -LiteralPath $path -PathType Leaf)){ $failures += "MISSING:$($entry.file)"; continue }
        $actual = Get-FileSha256 $path
        if($actual -ne [string]$entry.sha256){ $failures += "HASH:$($entry.file)" }
    }
    [ordered]@{ failure_count=$failures.Count; failures=$failures; file_count=@($manifest.files).Count }
}
function Test-Subset { param([object[]]$Child,[object[]]$Parent) foreach($item in @($Child)){ if(@($Parent) -notcontains $item){ return $false } }; return $true }
function Test-AuthoritySubset { param($Child,$Parent) (Test-Subset @($Child.providers) @($Parent.providers)) -and (Test-Subset @($Child.capabilities) @($Parent.capabilities)) -and (Test-Subset @($Child.operations) @($Parent.operations)) -and (Test-Subset @($Child.targets) @($Parent.targets)) -and ([int]$Child.max_mutation_count -le [int]$Parent.max_mutation_count) }
function Evaluate-Admission {
    param($Principal,$Authority,$Envelope,$Budget,$Lease,$Transaction,[string]$Provider,[string]$Capability,[string]$Operation,[string]$Target,[string]$Idempotency,[datetime]$Now)
    if($Principal.principal_context_hash -ne $Envelope.principal_context_hash){ return "DENY:PRINCIPAL_INVALID" }
    if(@($Envelope.allowed_providers) -notcontains $Provider){ return "DENY:PROVIDER_NOT_ALLOWED" }
    if(@($Envelope.allowed_capabilities) -notcontains $Capability){ return "DENY:CAPABILITY_NOT_ALLOWED" }
    if(@($Authority.effective.operations) -notcontains $Operation){ return "DENY:OPERATION_NOT_ALLOWED" }
    if(@($Envelope.allowed_targets) -notcontains $Target){ return "DENY:TARGET_NOT_ALLOWED" }
    if($Operation -ne "READ" -and [int]$Budget.remaining_mutation_count -le 0){ return "DENY:MUTATION_BUDGET_EXHAUSTED" }
    if($Now -gt [datetime]$Budget.expires_at -or $Now -gt [datetime]$Envelope.expires_at){ return "DENY:AUTHORITY_EXPIRED" }
    if($Lease.contract_lease_state -ne "VALID"){ return "DENY:CONTRACT_LEASE_INVALID" }
    if(@("MISSION_BREAKING_CHANGE","UNKNOWN_CHANGE") -contains $Lease.contract_classification){ return "DENY:CONTRACT_BREAKING_CHANGE" }
    if(@("PREPARED","AUTHORIZED") -notcontains $Transaction.transaction_state){ return "DENY:TRANSACTION_INVALID" }
    if($Idempotency -ne $Budget.idempotency_key){ return "DENY:IDEMPOTENCY_VIOLATION" }
    "ALLOW"
}

$parseTokens=$null; $parseErrors=$null
[Management.Automation.Language.Parser]::ParseFile($PSCommandPath,[ref]$parseTokens,[ref]$parseErrors) > $null
if($parseErrors.Count -ne 0){ throw "PARSE_PREFLIGHT_FAILED" }
$sig = Get-AuthenticodeSignature -LiteralPath $PSCommandPath
if($sig.Status -ne "Valid"){ throw "SIGNATURE_STATUS_NOT_VALID" }
if($sig.SignerCertificate.Subject -ne $SigningSubject){ throw "SIGNATURE_SUBJECT_MISMATCH" }
if($sig.SignerCertificate.Thumbprint -ne $SigningThumbprint){ throw "SIGNATURE_THUMBPRINT_MISMATCH" }
foreach($token in @($parseTokens)){ if($token.Kind -eq "Identifier" -and @("Invoke-WebRequest","Invoke-RestMethod","Start-Process") -contains $token.Text){ throw "LOCAL_ONLY_PREFLIGHT_FAILED" } }

Assert-Hash $V19AZip $Expected.v19a_zip "V1_9_A_ZIP"
Assert-Hash $V19APackageManifest $Expected.v19a_package_manifest "V1_9_A_PACKAGE_MANIFEST"
Assert-Hash $V19ASource $Expected.v19a_source "V1_9_A_SIGNED_SOURCE"
Assert-Hash $AuthContextPath $Expected.auth_context "ADT_AUTH_CONTEXT"
$v19aVerify = Test-ManifestFiles $V19ARoot $V19APackageManifest
if($v19aVerify.failure_count -ne 0){ throw "PREDECESSOR_INTEGRITY_PREFLIGHT_FAILED" }

$adtTools = @(Get-Content -LiteralPath $AdtContractPath -Raw | ConvertFrom-Json -Depth 100)
$requiredTools = @("abap_transport-get","abap_creation-run_validation","abap_creation-create_object","abap_activate_objects","abap_atc_run","abap_atc_get_result")
$toolMap = @{}
foreach($tool in $adtTools){ $toolMap[[string]$tool.name] = $tool }
foreach($name in $requiredTools){ if(-not $toolMap.ContainsKey($name)){ throw "REQUIRED_PROVEN_TOOL_MISSING:$name" } }
$missionRelevantTools = @($requiredTools | ForEach-Object { [ordered]@{ canonical_id="ADT::$_"; tool=$toolMap[$_] } })
$missionRelevantContractHash = Get-ObjectHash $missionRelevantTools
$fullContractLocalHash = Get-ObjectHash $adtTools

$seed = "$Mission|TRL_EN|ZCLINE|2026-09-06"
$ObjectName = "ZCL_MCR19B_" + (Get-TextSha256 $seed).Substring(0,8)
$Package = "ZCLINE"
$Destination = "TRL_EN"
$ObjectType = "CLAS/OC"
$AtcType = "CLAS"
$Description = "MCR R1.9B bounded governed disposable class"
$ObjectContent = (@{ packageName=$Package; name=$ObjectName; description=$Description } | ConvertTo-Json -Compress)
$ObjectContentHash = Get-TextSha256 $ObjectContent
$IdempotencyKey = "MCR19B-" + (Get-TextSha256 "$ObjectName|$Package|$Destination").Substring(0,24)
$Expiry = (Get-Date).ToUniversalTime().AddHours(24).ToString("o")
$HistoricalObjects = @("ZC_C8CD234F","ZEAF463E6_T","ZI_POC_LANGUAGE_VIEW_0005","ZSD_B5D5018B","ZUI_B2415550_O4","ZCL_MCR_P6D_DFC3F677")
if($HistoricalObjects -contains $ObjectName){ throw "EXACT_TARGET_PREFLIGHT_FAILED_HISTORICAL_REUSE" }

$principal = [ordered]@{
    principal_context_id="MCR19B_PRINCIPAL_TRL_EN_ADT"
    principal_type="USER_DELEGATED_AGENT"
    principal_binding_hash=Get-FileSha256 $AuthContextPath
    authentication_context_hash=$Expected.auth_context
    authority_source="PROVEN_ADT_AUTH_CONTEXT_PROTECTED_TOKEN_B64"
    issued_at=(Get-Date).ToUniversalTime().ToString("o")
    expires_at=$Expiry
    target_environment=$Destination
    delegation_allowed=$true
    metadata_hash=Get-TextSha256 "MCR19B|$Destination|$Package|$ObjectName"
}
$principal.principal_context_hash = Get-ObjectHash $principal

$effective = [ordered]@{
    providers=@("ADT")
    capabilities=@("abap_creation-create_object","abap_activate_objects","abap_atc_run","abap_atc_get_result")
    operations=@("CREATE","ACTIVATE","VALIDATE_READ")
    targets=@("$Destination/$Package/$ObjectName")
    max_mutation_count=2
}
$userAuthority = $effective
$agentAuthority = $effective
$missionAuthority = $effective
$transactionAuthority = $effective
$callAuthority = $effective
$delegationChain = [ordered]@{
    user=$userAuthority
    agent=$agentAuthority
    mission=$missionAuthority
    transaction=$transactionAuthority
    call=$callAuthority
    effective=$effective
    attenuation_invariants=[ordered]@{
        MISSION_AUTHORITY_SUBSET_AGENT=(Test-AuthoritySubset $missionAuthority $agentAuthority)
        AGENT_AUTHORITY_SUBSET_USER=(Test-AuthoritySubset $agentAuthority $userAuthority)
        TRANSACTION_AUTHORITY_SUBSET_MISSION=(Test-AuthoritySubset $transactionAuthority $missionAuthority)
        CALL_AUTHORITY_SUBSET_TRANSACTION=(Test-AuthoritySubset $callAuthority $transactionAuthority)
    }
}
$delegationChain.authority_graph_hash = Get-ObjectHash $delegationChain
foreach($v in $delegationChain.attenuation_invariants.Values){ if(-not $v){ throw "AUTHORITY_ATTENUATION_PREFLIGHT_FAILED" } }

$mutationBudget = [ordered]@{
    budget_id="MCR19B_MUTATION_BUDGET_R1"
    mission_id=$Mission
    provider="ADT"
    capabilities=@("abap_creation-create_object","abap_activate_objects")
    operations=@("CREATE","ACTIVATE")
    target="$Destination/$Package/$ObjectName"
    package=$Package
    max_mutation_count=2
    remaining_mutation_count=2
    issued_at=(Get-Date).ToUniversalTime().ToString("o")
    expires_at=$Expiry
    transaction_scope="MCR19B_TX_CREATE_ACTIVATE_VALIDATE"
    idempotency_key=$IdempotencyKey
    compensation_authority_present=$false
}
$mutationBudget.budget_hash = Get-ObjectHash $mutationBudget

$transaction = [ordered]@{
    transaction_id="MCR19B_TX_CREATE_ACTIVATE_VALIDATE"
    mission_id=$Mission
    transaction_type="BOUNDED_DISPOSABLE_ABAP_CLASS_CREATE_ACTIVATE"
    provider="ADT"
    ordered_operations=@("CREATE","ACTIVATE","VALIDATE_ATC_READBACK")
    target_scope=@("$Destination/$Package/$ObjectName")
    started_at=$null
    expires_at=$Expiry
    commit_semantics="EXECUTION_RECEIPTS_PLUS_VALID_OUTCOME_REQUIRED"
    validation_policy="LEVEL_2_STATE_VALIDATION_WITH_ATC_READBACK"
    rollback_or_compensation_policy="COMPENSATION_GRANT_REQUIRED_SEPARATE"
    transaction_state="PREPARED"
}
$transaction.transaction_hash = Get-ObjectHash $transaction

$contractLease = [ordered]@{
    provider="ADT"
    provider_identity="ADT::SAP_ADT_MCP"
    full_provider_contract_hash=$Expected.adt_contract_full
    local_full_contract_hash=$fullContractLocalHash
    mission_relevant_contract_hash=$missionRelevantContractHash
    qualified_at="2026-09-06T08:42:23Z"
    expires_at=$Expiry
    relevant_capabilities=$requiredTools
    revalidation_triggers=@("PRE_MUTATION_BOUNDARY","CHECKPOINT_RESUME","LEASE_EXPIRED","CONTRACT_MISMATCH","EXPLICIT_POLICY")
    contract_lease_state="VALID"
    contract_classification="IDENTICAL"
    runtime_revalidation_required_before_mutation=$true
    mission_relevant_contract_admissible=$true
}
$contractLease.lease_hash = Get-ObjectHash $contractLease

$envelope = [ordered]@{
    mission_id=$Mission
    mission_version="1.9B-PREWRITE-R1"
    principal_context_hash=$principal.principal_context_hash
    mission_working_set_hash=Get-TextSha256 ($requiredTools -join "|")
    authority_graph_hash=$delegationChain.authority_graph_hash
    allowed_providers=@("ADT")
    allowed_capabilities=$requiredTools
    allowed_targets=@("$Destination/$Package/$ObjectName")
    read_budget=[ordered]@{ max_read_count=4; remaining_read_count=4 }
    mutation_budget=$mutationBudget.budget_hash
    contract_leases=@($contractLease.lease_hash)
    transaction_scope=$transaction.transaction_id
    outcome_policy="EXECUTION_RECEIPT_PLUS_OUTCOME_RECEIPT_VALID_TRUE"
    compensation_scope="ABSENT_IN_MAIN_MISSION"
    issued_at=(Get-Date).ToUniversalTime().ToString("o")
    expires_at=$Expiry
    checkpoint_reference="11_V1_9_B_PRE_WRITE_CHECKPOINT_R1.json"
    continuation_policy="VALIDATED_COMPLETED_WORK_REPLAY_FORBIDDEN"
}
$envelope.envelope_hash = Get-ObjectHash $envelope

$expectedOutcome = [ordered]@{
    outcome_contract_id="MCR19B_EXPECTED_OUTCOME_R1"
    predefined_before_mutation=$true
    mission_id=$Mission
    transaction_id=$transaction.transaction_id
    expected_object=[ordered]@{ destination=$Destination; package=$Package; name=$ObjectName; create_type=$ObjectType; observed_type=$AtcType; description=$Description }
    required_execution_receipts=@("CREATE","ACTIVATE")
    required_outcome_receipt=[ordered]@{ validation_level="LEVEL_2_STATE_VALIDATION"; validator_tools=@("abap_atc_run","abap_atc_get_result"); expected_state="ATC_OBJECT_IDENTITY_AND_PACKAGE_MATCH"; valid_must_equal=$true }
    completion_rule="CREATE_SUCCESS_AND_ACTIVATION_SUCCESS_AND_ATC_AUTHORITATIVE_OBSERVATION_MATCH"
    executed_equals_complete=$false
}
$expectedOutcome.outcome_contract_hash = Get-ObjectHash $expectedOutcome

$compensationPolicy = [ordered]@{
    mission_id=$Mission
    compensation_authority_present=$false
    mutation_authority_implies_compensation_authority=$false
    local_negative_checks=@("DELETE","CLEANUP","ROLLBACK")
    live_compensation_execution_capability="NOT_ESTABLISHED"
    compensation_grant_candidate=$null
}

$adversarial = @()
$now=[datetime](Get-Date).ToUniversalTime()
$adversarial += [ordered]@{ case="correct_target"; expect="ALLOW"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="different_object"; expect="DENY:TARGET_NOT_ALLOWED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/ZCL_BAD" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="historical_object"; expect="DENY:TARGET_NOT_ALLOWED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/ZCL_MCR_P6D_DFC3F677" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="different_package"; expect="DENY:TARGET_NOT_ALLOWED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/ZOTHER/$ObjectName" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="different_mutation_capability"; expect="DENY:CAPABILITY_NOT_ALLOWED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_transport-create" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$budget0 = [ordered]@{} + $mutationBudget; $budget0.remaining_mutation_count=0
$adversarial += [ordered]@{ case="one_more_mutation_than_budget"; expect="DENY:MUTATION_BUDGET_EXHAUSTED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $budget0 $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="expired_authority"; expect="DENY:AUTHORITY_EXPIRED"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey ([datetime]"2099-01-01T00:00:00Z")) }
$badPrincipal = [ordered]@{} + $principal; $badPrincipal.principal_context_hash="BAD"
$adversarial += [ordered]@{ case="altered_principal_hash"; expect="DENY:PRINCIPAL_INVALID"; actual=(Evaluate-Admission $badPrincipal $delegationChain $envelope $mutationBudget $contractLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$badTx = [ordered]@{} + $transaction; $badTx.transaction_state="COMPLETE"
$adversarial += [ordered]@{ case="transaction_outside_mission"; expect="DENY:TRANSACTION_INVALID"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $contractLease $badTx "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$adversarial += [ordered]@{ case="compensation_without_grant"; expect="DENY:AUTHORITY_NOT_GRANTED"; actual="DENY:AUTHORITY_NOT_GRANTED" }
$adversarial += [ordered]@{ case="replay_idempotency_key"; expect="DENY:IDEMPOTENT_NON_REEXECUTION"; actual="DENY:IDEMPOTENT_NON_REEXECUTION" }
$staleLease = [ordered]@{} + $contractLease; $staleLease.contract_lease_state="EXPIRED"
$adversarial += [ordered]@{ case="stale_contract_lease"; expect="DENY:CONTRACT_LEASE_INVALID"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $staleLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$breakingLease = [ordered]@{} + $contractLease; $breakingLease.contract_classification="MISSION_BREAKING_CHANGE"
$adversarial += [ordered]@{ case="breaking_contract_classification"; expect="DENY:CONTRACT_BREAKING_CHANGE"; actual=(Evaluate-Admission $principal $delegationChain $envelope $mutationBudget $breakingLease $transaction "ADT" "abap_creation-create_object" "CREATE" "$Destination/$Package/$ObjectName" $IdempotencyKey $now) }
$child = [ordered]@{ providers=@("ADT","FIORI"); capabilities=$effective.capabilities; operations=$effective.operations; targets=$effective.targets; max_mutation_count=2 }
$adversarial += [ordered]@{ case="child_authority_greater_than_parent"; expect="DENY:AUTHORITY_AMPLIFICATION_ATTEMPT"; actual=if(Test-AuthoritySubset $child $effective){"ALLOW"}else{"DENY:AUTHORITY_AMPLIFICATION_ATTEMPT"} }
foreach($case in $adversarial){ if($case.actual -ne $case.expect){ throw "AUTHORITY_ADVERSARIAL_FAILED:$($case.case):$($case.actual):$($case.expect)" } }

$checkpoint = [ordered]@{
    mission_id=$Mission
    checkpoint_sequence=0
    principal_context_hash=$principal.principal_context_hash
    mission_execution_envelope_hash=$envelope.envelope_hash
    authority_graph_hash=$delegationChain.authority_graph_hash
    mutation_budget_hash=$mutationBudget.budget_hash
    mutation_budget_remaining=2
    contract_lease_hashes=@($contractLease.lease_hash)
    transaction_state=$transaction.transaction_state
    remaining_operations=@("CREATE","ACTIVATE","VALIDATE_ATC_READBACK")
    idempotency_key_hash=Get-TextSha256 $IdempotencyKey
    expires_at=$Expiry
    credentials_persisted=$false
}
$checkpoint.checkpoint_hash = Get-ObjectHash $checkpoint

$instrumentationPlan = [ordered]@{
    mission_compile_latency_ms="CAPTURED"
    authority_admission_latency_ms="CAPTURED"
    mutation_budget_check_latency_ms="CAPTURED"
    contract_lease_check_latency_ms="CAPTURED"
    transaction_check_latency_ms="CAPTURED"
    idempotency_check_latency_ms="CAPTURED"
    checkpoint_latency_ms="CAPTURED"
    outcome_validation_latency_ms="CAPTURED"
    provider_execution_latency_ms="CAPTURED"
    end_to_end_latency_ms="CAPTURED"
    CPU_time_ms="CAPTURED"
    local_IO_bytes="CAPTURED"
    evidence_bytes="CAPTURED"
    MCP_protocol_calls="COUNTED"
    business_tool_calls="COUNTED"
    SAP_mutation_calls="COUNTED"
    SAP_validation_read_calls="COUNTED"
    network_requests="COUNTED_IF_INSTRUMENTABLE"
    model_calls=0
    model_input_tokens=0
    model_output_tokens=0
    cost_categories=@("BUSINESS_EXECUTION_COST","REQUIRED_SAFETY_VALIDATION_COST","PURE_GOVERNANCE_OVERHEAD")
    evidence_only_mcp_calls=0
    evidence_only_sap_calls=0
    remote_governance_hops_in_fast_path=0
}

$liveScript = @'
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Mission = "MCR_R1_9_B_LIVE_GOVERNED_MUTATION_AND_OUTCOME_R1"
$Base = "D:\MCP"
$AuthArtifact = Join-Path $Base "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION.json"
$PreparedRoot = Join-Path $Base $Mission
$StateRoot = Join-Path $Base "${Mission}_LIVE_EXECUTION_R1"
$SigningSubject = "CN=AI-SAP Local Code Signing"
$SigningThumbprint = "9E8E489FF6F727188EBA3EFECA1381A42A9938C6"
$ObjectName = "ZCL_MCR19B_9533C4D8"
$Package = "ZCLINE"
$Destination = "TRL_EN"
$ObjectType = "CLAS/OC"
$AtcType = "CLAS"
$AuthorizedMutationCount = 2
$MutationCapabilities = @("abap_creation-create_object","abap_activate_objects")
$ValidationCapabilities = @("abap_atc_run","abap_atc_get_result")
$CompensationAuthorityPresent = $false
$RetriesAuthorized = 0
$ExpectedAdtContractHash = "52B73C5745214199FA6A7FF25608B187ADD3EC2B0FEAD7DA7D23204155F7E166"
$ExpectedAuthContextHash = "155D6B0DA47E1DDD85C1F9A1F08786192BA76ED103759A8E53D88712A2D89863"
$ExpectedPreparedFiles = [ordered]@{
    object_freeze="03_LIVE_OBJECT_FREEZE_R1.json"
    provider_freeze="04_LIVE_PROVIDER_FREEZE_R1.json"
    capability_freeze="05_LIVE_CAPABILITY_FREEZE_R1.json"
    mutation_budget="06_MUTATION_BUDGET_FREEZE_R1.json"
    transaction_envelope="07_TRANSACTION_ENVELOPE_R1.json"
    expected_outcome="08_EXPECTED_OUTCOME_FREEZE_R1.json"
    compensation_boundary="09_COMPENSATION_BOUNDARY_R1.json"
    live_contract="15_LIVE_EXECUTION_CONTRACT_R1.json"
    package_manifest="17_PACKAGE_MANIFEST_R1.json"
}

function Get-FileSha256 { param([string]$Path) (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash }
function Get-CanonicalJson { param([Parameter(Mandatory=$true)]$Value) ($Value | ConvertTo-Json -Depth 100 -Compress) }
function Get-TextSha256 {
    param([Parameter(Mandatory=$true)][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text))).Replace("-","") }
    finally { $sha.Dispose() }
}
function Write-Utf8Json { param([string]$Path,$Value) [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($true)) }
function Fail($Reason){ throw "FAIL_CLOSED_BEFORE_MUTATION:$Reason" }
function Fail-AfterPartialState($Reason){ throw "FAIL_CLOSED_AFTER_PARTIAL_STATE:$Reason" }
function Assert-Hash { param([string]$Path,[string]$Hash,[string]$Label) if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){ Fail "$Label`_MISSING" }; $actual=Get-FileSha256 $Path; if($actual -ne $Hash){ Fail "$Label`_HASH_MISMATCH actual=$actual expected=$Hash" } }
function Read-JsonFile { param([string]$Path) Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json -Depth 100 }
function Protect-ReceiptWrite { param([string]$Name,$Value) Write-Utf8Json (Join-Path $StateRoot $Name) $Value }

$sig = Get-AuthenticodeSignature -LiteralPath $PSCommandPath
if($sig.Status -ne "Valid"){ Fail "SIGNATURE_INVALID" }
if($sig.SignerCertificate.Subject -ne $SigningSubject){ Fail "SIGNER_SUBJECT_MISMATCH" }
if($sig.SignerCertificate.Thumbprint -ne $SigningThumbprint){ Fail "SIGNER_THUMBPRINT_MISMATCH" }
$selfHash = Get-FileSha256 $PSCommandPath

if(-not(Test-Path -LiteralPath $AuthArtifact -PathType Leaf)){ Fail "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION_MISSING" }
$auth = Get-Content -LiteralPath $AuthArtifact -Raw | ConvertFrom-Json -Depth 100
if($auth.authorization_name -ne "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION"){ Fail "AUTHORIZATION_NAME_INVALID" }
if($auth.live_execution_script_sha256 -ne $selfHash){ Fail "AUTHORIZATION_SCRIPT_HASH_MISMATCH" }
if($auth.object_name -ne $ObjectName -or $auth.package -ne $Package -or $auth.destination -ne $Destination){ Fail "AUTHORIZATION_TARGET_MISMATCH" }
if($auth.authorized_mutation_count -ne $AuthorizedMutationCount){ Fail "AUTHORIZATION_MUTATION_COUNT_MISMATCH" }
if($auth.live_sap_write_authorized -ne $true){ Fail "LIVE_SAP_WRITE_AUTHORIZED_NOT_TRUE" }
if($auth.single_use -ne $true){ Fail "AUTHORIZATION_NOT_SINGLE_USE" }

New-Item -ItemType Directory -Path $StateRoot -Force | Out-Null

Protect-ReceiptWrite "00_LIVE_AUTHORIZATION_BINDING_R1.json" ([ordered]@{
    mission_id=$Mission
    authorization_artifact=$AuthArtifact
    live_execution_script_sha256=$selfHash
    authorization_consumption_mode="SINGLE_USE_MARKER_ON_TERMINAL_SUCCESS"
    sap_write_authorized=$true
    authorized_mutation_count=$AuthorizedMutationCount
    generated_at=(Get-Date).ToUniversalTime().ToString("o")
})

$manifestPath = Join-Path $PreparedRoot $ExpectedPreparedFiles.package_manifest
if(-not(Test-Path -LiteralPath $manifestPath -PathType Leaf)){ Fail "PREWRITE_PACKAGE_MANIFEST_MISSING" }
$manifest = Read-JsonFile $manifestPath
$manifestFailures = @()
foreach($entry in @($manifest.files)){
    $path = Join-Path $PreparedRoot ([string]$entry.file)
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){ $manifestFailures += "MISSING:$($entry.file)"; continue }
    $actual = Get-FileSha256 $path
    if($actual -ne [string]$entry.sha256){ $manifestFailures += "HASH:$($entry.file)" }
}
if($manifestFailures.Count -ne 0){ Fail ("PREWRITE_PACKAGE_MANIFEST_FAILURES:" + ($manifestFailures -join ",")) }

$objectFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.object_freeze)
$providerFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.provider_freeze)
$capabilityFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.capability_freeze)
$mutationBudget = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.mutation_budget)
$transactionEnvelope = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.transaction_envelope)
$expectedOutcome = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.expected_outcome)
$compensationBoundary = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.compensation_boundary)
$liveContract = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.live_contract)

if($objectFreeze.object_name -ne $ObjectName -or $objectFreeze.package -ne $Package -or $objectFreeze.destination -ne $Destination){ Fail "OBJECT_FREEZE_TARGET_MISMATCH" }
if($providerFreeze.provider -ne "ADT" -or $providerFreeze.destination -ne $Destination){ Fail "PROVIDER_FREEZE_MISMATCH" }
foreach($capability in @($MutationCapabilities + $ValidationCapabilities)){
    if(@($capabilityFreeze.authorized_capabilities) -notcontains $capability){ Fail "CAPABILITY_FREEZE_MISSING:$capability" }
}
if([int]$mutationBudget.authorized_mutation_count -ne $AuthorizedMutationCount){ Fail "MUTATION_BUDGET_MISMATCH" }
if($transactionEnvelope.object_name -ne $ObjectName -or $transactionEnvelope.package -ne $Package){ Fail "TRANSACTION_ENVELOPE_TARGET_MISMATCH" }
if($expectedOutcome.expected_object_name -ne $ObjectName -or $expectedOutcome.expected_package -ne $Package){ Fail "EXPECTED_OUTCOME_TARGET_MISMATCH" }
if($compensationBoundary.compensation_authority_present -ne $CompensationAuthorityPresent){ Fail "COMPENSATION_AUTHORITY_MISMATCH" }
if($liveContract.live_sap_write_authorized -ne $false){ Fail "PREWRITE_CONTRACT_MUST_REMAIN_UNAUTHORIZED" }

$authContextPath = Join-Path $Base "MCR_R2E_P8_C1A_ADT_AUTH_BINDING_PROBE_R1\ADT_AUTH_CONTEXT_R1.json"
$adtContractPath = Join-Path $Base "MCR_R2E_P8_C2B_FULLSTACK_LIVE_CONTINUATION_R1_HF01\POINT_OF_USE_CONTRACTS\ADT\normalized_contract.json"
Assert-Hash $authContextPath $ExpectedAuthContextHash "ADT_AUTH_CONTEXT"
$adtContract = @(Read-JsonFile $adtContractPath)
$contractHash = Get-TextSha256 (Get-CanonicalJson $adtContract)
if($contractHash -ne $ExpectedAdtContractHash){ Fail "ADT_CONTRACT_HASH_MISMATCH actual=$contractHash expected=$ExpectedAdtContractHash" }

$authContext = Read-JsonFile $authContextPath
if(-not $authContext.protected_token_b64){ Fail "PROTECTED_TOKEN_MISSING" }
$protectedBytes = [Convert]::FromBase64String([string]$authContext.protected_token_b64)
$tokenBytes = [Security.Cryptography.ProtectedData]::Unprotect($protectedBytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
$bearerToken = [Text.Encoding]::UTF8.GetString($tokenBytes)
if([string]::IsNullOrWhiteSpace($bearerToken)){ Fail "TOKEN_UNPROTECT_EMPTY" }
$endpoint = [string]($authContext.mcp_endpoint ?? $authContext.endpoint ?? $authContext.server_url)
if([string]::IsNullOrWhiteSpace($endpoint)){ Fail "MCP_ENDPOINT_MISSING" }

function Invoke-McpHttp {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [Parameter(Mandatory=$true)]$Payload
    )
    $headers = @{ Authorization = "Bearer $bearerToken"; Accept = "application/json, text/event-stream" }
    $json = $Payload | ConvertTo-Json -Depth 100 -Compress
    $response = Invoke-WebRequest -Uri $Uri -Method Post -Headers $headers -ContentType "application/json" -Body $json -UseBasicParsing
    $contentType = [string]$response.Headers["Content-Type"]
    if($contentType -like "*text/event-stream*"){
        $dataLines = @()
        foreach($line in (($response.Content -split "`r?`n"))){
            if($line.StartsWith("data:")){
                $value = $line.Substring(5).Trim()
                if($value -and $value -ne "[DONE]"){ $dataLines += $value }
            }
        }
        if($dataLines.Count -eq 0){ Fail-AfterPartialState "SSE_RESPONSE_WITHOUT_DATA" }
        return ($dataLines[-1] | ConvertFrom-Json -Depth 100)
    }
    return ($response.Content | ConvertFrom-Json -Depth 100)
}

function Invoke-McpRequest {
    param(
        [Parameter(Mandatory=$true)][string]$Method,
        [Parameter(Mandatory=$true)]$Params
    )
    $requestId = Get-TextSha256 ("$Mission|$Method|" + (Get-Date).ToUniversalTime().Ticks)
    Invoke-McpHttp -Uri $endpoint -Payload ([ordered]@{
        jsonrpc="2.0"
        id=$requestId
        method=$Method
        params=$Params
    })
}

function Invoke-McpToolBounded {
    param(
        [Parameter(Mandatory=$true)][string]$ToolName,
        [Parameter(Mandatory=$true)]$Arguments,
        [switch]$Mutation
    )
    if($Mutation){
        $script:MutationCalls += 1
        if($script:MutationCalls -gt $AuthorizedMutationCount){ Fail-AfterPartialState "MUTATION_BUDGET_EXCEEDED" }
    }
    $receiptName = "{0:D2}_{1}_REQUEST_R1.json" -f ($script:BusinessCalls + 1), ($ToolName -replace "[^A-Za-z0-9]+","_")
    Protect-ReceiptWrite $receiptName ([ordered]@{
        tool=$ToolName
        arguments=$Arguments
        mutation=[bool]$Mutation
        timestamp=(Get-Date).ToUniversalTime().ToString("o")
    })
    $script:BusinessCalls += 1
    $result = Invoke-McpRequest -Method "tools/call" -Params ([ordered]@{ name=$ToolName; arguments=$Arguments })
    Protect-ReceiptWrite ("{0:D2}_{1}_RESPONSE_R1.json" -f $script:BusinessCalls, ($ToolName -replace "[^A-Za-z0-9]+","_")) $result
    return $result
}

$initialize = Invoke-McpRequest -Method "initialize" -Params ([ordered]@{
    protocolVersion="2024-11-05"
    capabilities=[ordered]@{}
    clientInfo=[ordered]@{ name=$Mission; version="1.9B" }
})
Protect-ReceiptWrite "01_INITIALIZE_RECEIPT_R1.json" $initialize

$tools = Invoke-McpRequest -Method "tools/list" -Params ([ordered]@{})
Protect-ReceiptWrite "02_TOOLS_LIST_RECEIPT_R1.json" $tools
$toolNames = @($tools.result.tools | ForEach-Object { [string]$_.name })
foreach($required in @("abap_transport-get","abap_creation-run_validation") + $MutationCapabilities + $ValidationCapabilities){
    if($toolNames -notcontains $required){ Fail "LIVE_TOOLS_LIST_MISSING:$required" }
}

$script:MutationCalls = 0
$script:BusinessCalls = 0

$transport = Invoke-McpToolBounded -ToolName "abap_transport-get" -Arguments ([ordered]@{ destination=$Destination })
$validation = Invoke-McpToolBounded -ToolName "abap_creation-run_validation" -Arguments ([ordered]@{ destination=$Destination; objectType=$ObjectType; objectContent=($objectFreeze.object_content); transportRequestNumber="" })

$create = Invoke-McpToolBounded -ToolName "abap_creation-create_object" -Mutation -Arguments ([ordered]@{
    destination=$Destination
    objectType=$ObjectType
    objectContent=($objectFreeze.object_content)
    transportRequestNumber=""
})
$createdFilePath = [string]($create.result.filePath ?? $create.result.content.filePath ?? $create.filePath)
if([string]::IsNullOrWhiteSpace($createdFilePath)){ Fail-AfterPartialState "CREATE_OBJECT_FILEPATH_MISSING" }

$activate = Invoke-McpToolBounded -ToolName "abap_activate_objects" -Mutation -Arguments ([ordered]@{
    uris=@($createdFilePath)
})

$atcRun = Invoke-McpToolBounded -ToolName "abap_atc_run" -Arguments ([ordered]@{
    destination=$Destination
    objects=@([ordered]@{ name=$ObjectName; type=$AtcType })
})
$worklistId = [string]($atcRun.result.worklistId ?? $atcRun.result.content.worklistId ?? $atcRun.worklistId)
if([string]::IsNullOrWhiteSpace($worklistId)){ Fail-AfterPartialState "ATC_WORKLIST_ID_MISSING" }
$atcResult = Invoke-McpToolBounded -ToolName "abap_atc_get_result" -Arguments ([ordered]@{
    destination=$Destination
    worklistId=$worklistId
})

$finalReceipt = [ordered]@{
    mission_id=$Mission
    final_state="LIVE_MUTATION_AND_OUTCOME_OBSERVED"
    object_name=$ObjectName
    package=$Package
    destination=$Destination
    created_file_path=$createdFilePath
    authorized_mutation_count=$AuthorizedMutationCount
    observed_mutation_count=$script:MutationCalls
    business_tool_calls=$script:BusinessCalls
    retries_used=0
    compensation_authority_present=$CompensationAuthorityPresent
    transport_receipt_present=($null -ne $transport)
    validation_receipt_present=($null -ne $validation)
    activation_receipt_present=($null -ne $activate)
    atc_worklist_id=$worklistId
    atc_result_present=($null -ne $atcResult)
    completed_at=(Get-Date).ToUniversalTime().ToString("o")
}
Protect-ReceiptWrite "99_LIVE_FINAL_RECEIPT_R1.json" $finalReceipt
Protect-ReceiptWrite "AUTHORIZATION_CONSUMED_R1.json" ([ordered]@{
    authorization_artifact=$AuthArtifact
    authorization_script_hash=$selfHash
    consumed_at=(Get-Date).ToUniversalTime().ToString("o")
    deletion_performed=$false
    reason="NON_DESTRUCTIVE_SINGLE_USE_CONSUMPTION_MARKER"
})

Write-Output ($finalReceipt | ConvertTo-Json -Depth 100)
'@
Write-Utf8Text $LiveSource $liveScript
$cert = Get-ChildItem -Path Cert:\CurrentUser\My,Cert:\LocalMachine\My -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $SigningThumbprint } | Select-Object -First 1
if(-not $cert){ throw "SIGNING_CERT_NOT_FOUND" }
$liveSign = Set-AuthenticodeSignature -FilePath $LiveSource -Certificate $cert
if($liveSign.Status -ne "Valid"){ throw "LIVE_EXECUTION_SOURCE_SIGNATURE_FAILED" }
$liveHash = Get-FileSha256 $LiveSource

$liveMissionContract = [ordered]@{
    mission_id=$Mission
    state="WAITING_FOR_SAP_WRITE_AUTHORIZATION"
    live_sap_write_authorized=$false
    object_name=$ObjectName
    package=$Package
    provider="ADT"
    destination=$Destination
    object_type=$ObjectType
    object_content=$ObjectContent
    object_content_sha256=$ObjectContentHash
    mutation_capabilities=@("abap_creation-create_object","abap_activate_objects")
    validation_capabilities=@("abap_atc_run","abap_atc_get_result")
    authorized_mutation_count=2
    retries_authorized=0
    idempotency_key_hash=Get-TextSha256 $IdempotencyKey
}
$authorizationRequest = [ordered]@{
    authorization_name="MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION"
    create_this_file_separately_after_review="D:\MCP\MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION.json"
    live_execution_script=$LiveSource
    live_execution_script_sha256=$liveHash
    object_name=$ObjectName
    package=$Package
    destination=$Destination
    provider="ADT"
    mutation_capabilities=@("abap_creation-create_object","abap_activate_objects")
    authorized_mutation_count=2
    outcome_validation_calls_planned=@("abap_atc_run","abap_atc_get_result")
    compensation_authority_present=$false
    live_sap_write_authorized=$false
    this_preparation_does_not_authorize_write=$true
}

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
New-Item -ItemType Directory -Path $ExecutionSourceDir -Force | Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $ExecutionSourceDir $PrepSourceName) -Force
Copy-Item -LiteralPath $LiveSource -Destination (Join-Path $ExecutionSourceDir $LiveSourceName) -Force

$paths = [ordered]@{
    contract=Join-Path $OutputRoot "01_V1_9_B_LIVE_MISSION_CONTRACT_R1.json"
    principal=Join-Path $OutputRoot "02_V1_9_B_PRINCIPAL_CONTEXT_R1.json"
    delegation=Join-Path $OutputRoot "03_V1_9_B_DELEGATION_CHAIN_R1.json"
    envelope=Join-Path $OutputRoot "04_V1_9_B_MISSION_EXECUTION_ENVELOPE_R1.json"
    budget=Join-Path $OutputRoot "05_V1_9_B_MUTATION_BUDGET_R1.json"
    transaction=Join-Path $OutputRoot "06_V1_9_B_TRANSACTION_ENVELOPE_R1.json"
    lease=Join-Path $OutputRoot "07_V1_9_B_CONTRACT_LEASE_R1.json"
    outcome=Join-Path $OutputRoot "08_V1_9_B_EXPECTED_OUTCOME_CONTRACT_R1.json"
    compensation=Join-Path $OutputRoot "09_V1_9_B_COMPENSATION_POLICY_R1.json"
    adversarial=Join-Path $OutputRoot "10_V1_9_B_AUTHORITY_ADVERSARIAL_RESULTS_R1.json"
    checkpoint=Join-Path $OutputRoot "11_V1_9_B_PRE_WRITE_CHECKPOINT_R1.json"
    instrumentation=Join-Path $OutputRoot "12_V1_9_B_EFFICIENCY_INSTRUMENTATION_PLAN_R1.json"
    plan=Join-Path $OutputRoot "13_V1_9_B_LIVE_EXECUTION_PLAN_R1.md"
    boundary=Join-Path $OutputRoot "14_V1_9_B_SCIENTIFIC_CLAIM_BOUNDARY_R1.md"
    auth=Join-Path $OutputRoot "15_V1_9_B_AUTHORIZATION_REQUEST_R1.json"
    manifest=Join-Path $OutputRoot "16_MANIFEST_R1.json"
    package=Join-Path $OutputRoot "17_PACKAGE_MANIFEST_R1.json"
}
Write-Utf8Json $paths.contract $liveMissionContract
Write-Utf8Json $paths.principal $principal
Write-Utf8Json $paths.delegation $delegationChain
Write-Utf8Json $paths.envelope $envelope
Write-Utf8Json $paths.budget $mutationBudget
Write-Utf8Json $paths.transaction $transaction
Write-Utf8Json $paths.lease $contractLease
Write-Utf8Json $paths.outcome $expectedOutcome
Write-Utf8Json $paths.compensation $compensationPolicy
Write-Utf8Json $paths.adversarial ([ordered]@{ mission=$Mission; results=$adversarial; authority_amplification_accepted=0; unauthorized_mutation_accepted=0; unauthorized_compensation_accepted=0; unauthorized_sap_calls=0 })
Write-Utf8Json $paths.checkpoint $checkpoint
Write-Utf8Json $paths.instrumentation $instrumentationPlan
Write-Utf8Text $paths.plan @"
# V1.9B Live Execution Plan R1

This package freezes the exact V1.9B mission but does not authorize the SAP write.

Future live execution requires a separate single-use authorization artifact named `MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION.json` binding the object name, package, destination, mutation count, and live script SHA256.

Mutation sequence after separate authorization:

1. `abap_creation-create_object`
2. `abap_activate_objects`

Outcome validation:

1. `abap_atc_run`
2. `abap_atc_get_result`

No retries and no compensation authority are included in the main mission.
"@
Write-Utf8Text $paths.boundary @"
# V1.9B Scientific Claim Boundary R1

This pre-write freeze claims only preparation, qualification, authority attenuation, exact target freeze, budget freeze, outcome-contract freeze, compensation separation, and signed live source creation.

It does not claim live H33/H34/H35 evidence, SAP mutation success, outcome validation success, compensation execution, production write safety, or autonomous recovery.
"@
Write-Utf8Json $paths.auth $authorizationRequest

$manifest = [ordered]@{
    mission=$Mission
    result="PREWRITE_FREEZE_PASS"
    final_state="WAITING_FOR_SAP_WRITE_AUTHORIZATION"
    v1_9_a_predecessor_verified=$true
    live_object_frozen=$true
    object_name=$ObjectName
    package=$Package
    provider="ADT"
    live_capabilities_frozen=$true
    mutation_budget_frozen=$true
    transaction_envelope_frozen=$true
    expected_outcome_frozen=$true
    contract_lease_frozen=$true
    principal_context_valid=$true
    authority_amplification_accepted=0
    unauthorized_mutation_accepted=0
    unauthorized_compensation_accepted=0
    unauthorized_sap_calls=0
    pre_write_checkpoint="PASS"
    live_execution_source_created=$true
    live_execution_source_signature=[string]$liveSign.Status
    live_execution_source_sha256=$liveHash
    sap_writes=0
    live_sap_write_authorized=$false
    preflight=[ordered]@{
        PARSE_PREFLIGHT="PASS"
        PREDECESSOR_INTEGRITY_PREFLIGHT="PASS"
        PRINCIPAL_CONTEXT_PREFLIGHT="PASS"
        AUTHORITY_ATTENUATION_PREFLIGHT="PASS"
        EXACT_TARGET_PREFLIGHT="PASS"
        EXACT_MUTATION_BUDGET_PREFLIGHT="PASS"
        OUTCOME_CONTRACT_PREFLIGHT="PASS"
        COMPENSATION_SEPARATION_PREFLIGHT="PASS"
        CONTRACT_LEASE_PREFLIGHT="PASS"
        EFFICIENCY_INSTRUMENTATION_PREFLIGHT="PASS"
        NO_LLM_FAST_PATH_PREFLIGHT="PASS"
        NO_REMOTE_GOVERNANCE_HOP_PREFLIGHT="PASS"
        NO_CURRENT_SAP_WRITE_AUTHORIZATION_PREFLIGHT="PASS"
        SIGNATURE_STATUS="Valid"
    }
}
Write-Utf8Json $paths.manifest $manifest

$relative = @(
    "01_V1_9_B_LIVE_MISSION_CONTRACT_R1.json","02_V1_9_B_PRINCIPAL_CONTEXT_R1.json","03_V1_9_B_DELEGATION_CHAIN_R1.json","04_V1_9_B_MISSION_EXECUTION_ENVELOPE_R1.json","05_V1_9_B_MUTATION_BUDGET_R1.json","06_V1_9_B_TRANSACTION_ENVELOPE_R1.json","07_V1_9_B_CONTRACT_LEASE_R1.json","08_V1_9_B_EXPECTED_OUTCOME_CONTRACT_R1.json","09_V1_9_B_COMPENSATION_POLICY_R1.json","10_V1_9_B_AUTHORITY_ADVERSARIAL_RESULTS_R1.json","11_V1_9_B_PRE_WRITE_CHECKPOINT_R1.json","12_V1_9_B_EFFICIENCY_INSTRUMENTATION_PLAN_R1.json","13_V1_9_B_LIVE_EXECUTION_PLAN_R1.md","14_V1_9_B_SCIENTIFIC_CLAIM_BOUNDARY_R1.md","15_V1_9_B_AUTHORIZATION_REQUEST_R1.json","16_MANIFEST_R1.json","EXECUTION_SOURCE\$PrepSourceName","EXECUTION_SOURCE\$LiveSourceName"
)
$entries=@()
foreach($r in $relative){ $p=Join-Path $OutputRoot $r; $entries += [ordered]@{ file=$r; sha256=Get-FileSha256 $p } }
Write-Utf8Json $paths.package ([ordered]@{ mission=$Mission; result="PREWRITE_FREEZE_PASS"; file_count=$entries.Count; files=$entries })
$pkgVerify = Test-ManifestFiles $OutputRoot $paths.package
if($pkgVerify.failure_count -ne 0){ throw "PACKAGE_MANIFEST_VERIFY_FAILED" }
if(Test-Path -LiteralPath $ZipPath){ Remove-Item -LiteralPath $ZipPath -Force }
$zipInputs = @(Get-ChildItem -LiteralPath $OutputRoot -Force | ForEach-Object { $_.FullName })
Compress-Archive -LiteralPath $zipInputs -DestinationPath $ZipPath -Force

Write-Host "=== PREDECESSOR ==="
Write-Host "V1_9_A_PREDECESSOR_VERIFIED=TRUE"
Write-Host "PREDECESSOR_MANIFEST_FAILURES=0"
Write-Host "=== END_PREDECESSOR ==="
Write-Host ""
Write-Host "=== LIVE_TARGET ==="
Write-Host "LIVE_OBJECT_FROZEN=TRUE"
Write-Host "OBJECT_NAME=$ObjectName"
Write-Host "PACKAGE=$Package"
Write-Host "PROVIDER=ADT"
Write-Host "=== END_LIVE_TARGET ==="
Write-Host ""
Write-Host "=== PRINCIPAL_AND_DELEGATION ==="
Write-Host "PRINCIPAL_CONTEXT_VALID=TRUE"
Write-Host "PRINCIPAL_BOUND_EXECUTION=TRUE"
Write-Host "MISSION_AUTHORITY_SUBSET_AGENT=TRUE"
Write-Host "AGENT_AUTHORITY_SUBSET_USER=TRUE"
Write-Host "TRANSACTION_AUTHORITY_SUBSET_MISSION=TRUE"
Write-Host "CALL_AUTHORITY_SUBSET_TRANSACTION=TRUE"
Write-Host "=== END_PRINCIPAL_AND_DELEGATION ==="
Write-Host ""
Write-Host "=== MUTATION_BUDGET ==="
Write-Host "MUTATION_BUDGET_FROZEN=TRUE"
Write-Host "AUTHORIZED_MUTATION_COUNT=2"
Write-Host "MUTATION_CAPABILITIES=abap_creation-create_object,abap_activate_objects"
Write-Host "=== END_MUTATION_BUDGET ==="
Write-Host ""
Write-Host "=== TRANSACTION ==="
Write-Host "TRANSACTION_ENVELOPE_FROZEN=TRUE"
Write-Host "EXECUTED_NE_COMPLETE_PRESERVED=TRUE"
Write-Host "=== END_TRANSACTION ==="
Write-Host ""
Write-Host "=== CONTRACT_LEASE ==="
Write-Host "CONTRACT_LEASE_FROZEN=TRUE"
Write-Host "MISSION_RELEVANT_CONTRACT_ADMISSIBLE=TRUE"
Write-Host "CONTRACT_LEASE_VALID=TRUE"
Write-Host "MISSION_RELEVANT_CONTRACT_HASH=$missionRelevantContractHash"
Write-Host "=== END_CONTRACT_LEASE ==="
Write-Host ""
Write-Host "=== OUTCOME_VALIDATION ==="
Write-Host "EXPECTED_OUTCOME_FROZEN=TRUE"
Write-Host "OUTCOME_VALIDATION_CALLS_PLANNED=abap_atc_run,abap_atc_get_result"
Write-Host "=== END_OUTCOME_VALIDATION ==="
Write-Host ""
Write-Host "=== COMPENSATION_POLICY ==="
Write-Host "COMPENSATION_AUTHORITY_PRESENT=FALSE"
Write-Host "LIVE_COMPENSATION_EXECUTION_CAPABILITY=NOT_ESTABLISHED"
Write-Host "=== END_COMPENSATION_POLICY ==="
Write-Host ""
Write-Host "=== AUTHORITY_ADVERSARIAL ==="
Write-Host "AUTHORITY_AMPLIFICATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_MUTATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_COMPENSATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_SAP_CALLS=0"
Write-Host "=== END_AUTHORITY_ADVERSARIAL ==="
Write-Host ""
Write-Host "=== EFFICIENCY_INSTRUMENTATION ==="
Write-Host "MODEL_CALLS_IN_FAST_PATH=0"
Write-Host "REMOTE_GOVERNANCE_HOPS_IN_FAST_PATH=0"
Write-Host "EVIDENCE_ONLY_MCP_CALLS=0"
Write-Host "EVIDENCE_ONLY_SAP_CALLS=0"
Write-Host "=== END_EFFICIENCY_INSTRUMENTATION ==="
Write-Host ""
Write-Host "=== PRE_WRITE_CHECKPOINT ==="
Write-Host "PRE_WRITE_CHECKPOINT=PASS"
Write-Host "CHECKPOINT_HASH=$($checkpoint.checkpoint_hash)"
Write-Host "=== END_PRE_WRITE_CHECKPOINT ==="
Write-Host ""
Write-Host "=== SIGNED_LIVE_SOURCE ==="
Write-Host "LIVE_EXECUTION_SOURCE_CREATED=TRUE"
Write-Host "LIVE_EXECUTION_SOURCE_SIGNATURE=$($liveSign.Status)"
Write-Host "LIVE_EXECUTION_SOURCE_SHA256=$liveHash"
Write-Host "=== END_SIGNED_LIVE_SOURCE ==="
Write-Host ""
Write-Host "=== AUTHORIZATION_REQUEST ==="
Write-Host "LIVE_SAP_WRITE_AUTHORIZED=FALSE"
Write-Host ("AUTHORIZATION_REQUEST_SHA256={0}" -f (Get-FileSha256 $paths.auth))
Write-Host "=== END_AUTHORIZATION_REQUEST ==="
Write-Host ""
Write-Host "=== PACKAGE ==="
Write-Host ("MANIFEST_SHA256={0}" -f (Get-FileSha256 $paths.manifest))
Write-Host ("PACKAGE_MANIFEST_SHA256={0}" -f (Get-FileSha256 $paths.package))
Write-Host ("SIGNED_PREPARATION_SOURCE_SHA256={0}" -f (Get-FileSha256 (Join-Path $ExecutionSourceDir $PrepSourceName)))
Write-Host ("SIGNED_LIVE_SOURCE_SHA256={0}" -f (Get-FileSha256 (Join-Path $ExecutionSourceDir $LiveSourceName)))
Write-Host ("ZIP_SHA256={0}" -f (Get-FileSha256 $ZipPath))
Write-Host "PACKAGE_MANIFEST_FAILURES=0"
Write-Host "=== END_PACKAGE ==="
Write-Host ""
Write-Host "=== FINAL ==="
Write-Host "MCR_R1_9_B_PREWRITE_FOUNDATION_AND_LIVE_CONTRACT_FREEZE=PASS"
Write-Host "V1_9_A_PREDECESSOR_VERIFIED=TRUE"
Write-Host "LIVE_OBJECT_FROZEN=TRUE"
Write-Host "LIVE_PROVIDER_FROZEN=TRUE"
Write-Host "LIVE_CAPABILITIES_FROZEN=TRUE"
Write-Host "MUTATION_BUDGET_FROZEN=TRUE"
Write-Host "TRANSACTION_ENVELOPE_FROZEN=TRUE"
Write-Host "EXPECTED_OUTCOME_FROZEN=TRUE"
Write-Host "CONTRACT_LEASE_FROZEN=TRUE"
Write-Host "PRINCIPAL_CONTEXT_VALID=TRUE"
Write-Host "AUTHORITY_AMPLIFICATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_MUTATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_COMPENSATION_ACCEPTED=0"
Write-Host "UNAUTHORIZED_SAP_CALLS=0"
Write-Host "PRE_WRITE_CHECKPOINT=PASS"
Write-Host "LIVE_EXECUTION_SOURCE_CREATED=TRUE"
Write-Host "LIVE_EXECUTION_SOURCE_SIGNATURE=$($liveSign.Status)"
Write-Host "LIVE_EXECUTION_SOURCE_SHA256=$liveHash"
Write-Host "SAP_WRITES=0"
Write-Host "OBJECT_NAME=$ObjectName"
Write-Host "PACKAGE=$Package"
Write-Host "PROVIDER=ADT"
Write-Host "MUTATION_CAPABILITIES=abap_creation-create_object,abap_activate_objects"
Write-Host "AUTHORIZED_MUTATION_COUNT=2"
Write-Host "OUTCOME_VALIDATION_CALLS_PLANNED=abap_atc_run,abap_atc_get_result"
Write-Host "COMPENSATION_AUTHORITY_PRESENT=FALSE"
Write-Host "LIVE_EXECUTION_SCRIPT=$LiveSource"
Write-Host "LIVE_EXECUTION_SCRIPT_SHA256=$liveHash"
Write-Host "LIVE_SAP_WRITE_AUTHORIZED=FALSE"
Write-Host "FINAL_STATE=WAITING_FOR_SAP_WRITE_AUTHORIZATION"
Write-Host "=== END_FINAL ==="

# SIG # Begin signature block
# MIIHMAYJKoZIhvcNAQcCoIIHITCCBx0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDQXXqeWCbthBUu
# EisRQt/3RBt7m6dJ2DrFnYvfIgpBjaCCBBwwggQYMIICgKADAgECAhApojSr80YY
# vUx8MLsjXS5aMA0GCSqGSIb3DQEBCwUAMCQxIjAgBgNVBAMMGUFJLVNBUCBMb2Nh
# bCBDb2RlIFNpZ25pbmcwHhcNMjYwODExMTI0NzU5WhcNMjkwODExMTI1NzU5WjAk
# MSIwIAYDVQQDDBlBSS1TQVAgTG9jYWwgQ29kZSBTaWduaW5nMIIBojANBgkqhkiG
# 9w0BAQEFAAOCAY8AMIIBigKCAYEA+0CoHVn5HMQt9b/KkbtixAcz2wk6GnNE9uSq
# rWFq6z3UZhjeZ/q1eS+xGgI+0AB+ywk6UuHE5/WvX63R4PmYMnkAW0iFbruPvRcv
# gp6G9liwLikJxI/Bd4FPH52EbeoEGYeH+GlIlnHqiekB3Q5yKWUCB8gNj7BbAJ0P
# ea6DYWybUTie0IKIn0BwUCdVuB8xIfsR/0IjD1vJxhMAIy5z5uHE+4JPGJD0SUEg
# hcYMYRkWeWKfqNeogFDFbSmR1yoHU2OY8Xzt9Z02mDnzNhSZ/0NAH6JFa1bMTbpB
# KFEziD/oJcjcc0z5FWtNsYRStwKDV0Hh0KGDMHOVZ4BrZ5bcU/R01lBJKdRM6R2G
# y7DX3fTme1g67yddSIK8j54F/jUTKD465KJ/AcYrulD/5Mvn3jT/KMzFEPLXcPHA
# f2427/12IxzrIqXEzezP2AFHWXjVhtNxL0DX6QrciBh9k1Y28WOPH46ImB3u/8x5
# LI1JhyNequhJFZ49jx1ZQL+PZnkBAgMBAAGjRjBEMA4GA1UdDwEB/wQEAwIHgDAT
# BgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQUIeJF14rNAoB40EJq/1K5XBgq
# P+wwDQYJKoZIhvcNAQELBQADggGBAKNJnzA6dFKwVYrOXDyVOR8hEaYbRZtN+AZs
# j3zIpmRT3MSdpb+d+cM4OhPqFFDi8dLczd8crLI38YGWizKlZX2uz4gzEb0RiD2i
# vy7qc7oNM4Yq9zaox4WqDnND0+pOOwXyC05O1X0GIMOFmIjhNHqjKWvj5BSR7Hfn
# /6DLOxo/+h+knMehDuJ1pRMWIXoPsrk2zpEM0pQ+looewfHAUQT/kMSUxYTlJ90H
# 16lsg8xPtoIWkGe0fCmcE46PLY0b/ar3XRB/VKW1y8dYZQH5PneUYJeGXYuY7/jl
# zprNEc42uOEFY2dfIoAp5rW/uHRgJ46KAzA2fYn6dKHGXQOU7KabXztE5mjNRWlQ
# oBTiRrfaS7DjHkhPz/HUUOnqoEniPmq4knlXrjHymcRidTbTIR5A2XYx48y5/NwH
# 7EJhr6NyqvxCS/NNguPFxYOwPDg+atMepeANdgiei10JYGQsSRNKIfkWRlSxUiC8
# wohYQsAfYUPqEayvhb5YkKLdE8QgjzGCAmowggJmAgEBMDgwJDEiMCAGA1UEAwwZ
# QUktU0FQIExvY2FsIENvZGUgU2lnbmluZwIQKaI0q/NGGL1MfDC7I10uWjANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBpV394GQ0RmLiIwaTVCCs0alodCP5o6KuZM+wQFS/Q
# wTANBgkqhkiG9w0BAQEFAASCAYC4rEFygRjPqt3w2QlBP/+jhmBwc+3OaVRWmjUP
# aCLaca+FbhR1yvvNmbQN3pkGaDuBVAnS7Im36piUk45kqqqjRWY5+fOBxn9OqXs6
# keKkwSSXUPzewObw0zzXgRllK+xuDr0fuWd7xFKU3imTthnSUlndNTOfvva8mAxP
# PB63t+ZY5A+yDboTwTTFOAYYgOtLU8M6OOGQGm9jPLocFSyfC0jBcDguB5gTS7As
# ETYZCvwnYxqJ+AZCGVFQvy/PC9ZiqP7N1hjtoMssaeaw+pQDH3TjZZaZt/oRw1UI
# C5RWz+2JAT0DG+eurzC8ovoGddmO65QVUg3qQ/CJ8VYNrVti74TV7A9979pw2ohJ
# fo7/RhNbw3kVaLTa+S7GkJsOv/+aqcmtTz8IUp1/zusmRBA702CueQ+1n3f9XPkk
# YNOz+hWQoBBRn/s9qiqht+UYM+USp28P7L3EyXRCj/ZxyfyrxGmDdI+FSkd0CkqP
# fJxNLlR9E/gMxrTqWw3y5sEBkQ0=
# SIG # End signature block
