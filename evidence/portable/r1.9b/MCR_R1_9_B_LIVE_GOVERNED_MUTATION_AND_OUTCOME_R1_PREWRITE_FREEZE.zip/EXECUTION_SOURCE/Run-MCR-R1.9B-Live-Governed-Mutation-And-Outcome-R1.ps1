﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Mission = "MCR_R1_9_B_LIVE_GOVERNED_MUTATION_AND_OUTCOME_R1"
$Base = "D:\MCP"
$AuthArtifact = Join-Path $Base "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION.json"
$PreparedRoot = Join-Path $Base $Mission
$StateRoot = Join-Path $Base "${Mission}_LIVE_EXECUTION_R1"
$SigningSubject = "CN=AI-SAP Local Code Signing"
$SigningThumbprint = "9E8E489FF6F727188EBA3EFECA1381A42A9938C6"
$ObjectName = "ZCL_MCR19B_9533C4D8"
$Package = "ZCLINE"
$Destination = "TRL_EN"
$ObjectType = "CLAS/OC"
$AtcType = "CLAS"
$AuthorizedMutationCount = 2
$MutationCapabilities = @("abap_creation-create_object","abap_activate_objects")
$ValidationCapabilities = @("abap_atc_run","abap_atc_get_result")
$CompensationAuthorityPresent = $false
$RetriesAuthorized = 0
$ExpectedAdtContractHash = "52B73C5745214199FA6A7FF25608B187ADD3EC2B0FEAD7DA7D23204155F7E166"
$ExpectedAuthContextHash = "155D6B0DA47E1DDD85C1F9A1F08786192BA76ED103759A8E53D88712A2D89863"
$ExpectedPreparedFiles = [ordered]@{
    object_freeze="03_LIVE_OBJECT_FREEZE_R1.json"
    provider_freeze="04_LIVE_PROVIDER_FREEZE_R1.json"
    capability_freeze="05_LIVE_CAPABILITY_FREEZE_R1.json"
    mutation_budget="06_MUTATION_BUDGET_FREEZE_R1.json"
    transaction_envelope="07_TRANSACTION_ENVELOPE_R1.json"
    expected_outcome="08_EXPECTED_OUTCOME_FREEZE_R1.json"
    compensation_boundary="09_COMPENSATION_BOUNDARY_R1.json"
    live_contract="15_LIVE_EXECUTION_CONTRACT_R1.json"
    package_manifest="17_PACKAGE_MANIFEST_R1.json"
}

function Get-FileSha256 { param([string]$Path) (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash }
function Get-CanonicalJson { param([Parameter(Mandatory=$true)]$Value) ($Value | ConvertTo-Json -Depth 100 -Compress) }
function Get-TextSha256 {
    param([Parameter(Mandatory=$true)][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text))).Replace("-","") }
    finally { $sha.Dispose() }
}
function Write-Utf8Json { param([string]$Path,$Value) [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($true)) }
function Fail($Reason){ throw "FAIL_CLOSED_BEFORE_MUTATION:$Reason" }
function Fail-AfterPartialState($Reason){ throw "FAIL_CLOSED_AFTER_PARTIAL_STATE:$Reason" }
function Assert-Hash { param([string]$Path,[string]$Hash,[string]$Label) if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){ Fail "$Label`_MISSING" }; $actual=Get-FileSha256 $Path; if($actual -ne $Hash){ Fail "$Label`_HASH_MISMATCH actual=$actual expected=$Hash" } }
function Read-JsonFile { param([string]$Path) Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json -Depth 100 }
function Protect-ReceiptWrite { param([string]$Name,$Value) Write-Utf8Json (Join-Path $StateRoot $Name) $Value }

$sig = Get-AuthenticodeSignature -LiteralPath $PSCommandPath
if($sig.Status -ne "Valid"){ Fail "SIGNATURE_INVALID" }
if($sig.SignerCertificate.Subject -ne $SigningSubject){ Fail "SIGNER_SUBJECT_MISMATCH" }
if($sig.SignerCertificate.Thumbprint -ne $SigningThumbprint){ Fail "SIGNER_THUMBPRINT_MISMATCH" }
$selfHash = Get-FileSha256 $PSCommandPath

if(-not(Test-Path -LiteralPath $AuthArtifact -PathType Leaf)){ Fail "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION_MISSING" }
$auth = Get-Content -LiteralPath $AuthArtifact -Raw | ConvertFrom-Json -Depth 100
if($auth.authorization_name -ne "MCR_R1_9_B_LIVE_WRITE_AUTHORIZATION"){ Fail "AUTHORIZATION_NAME_INVALID" }
if($auth.live_execution_script_sha256 -ne $selfHash){ Fail "AUTHORIZATION_SCRIPT_HASH_MISMATCH" }
if($auth.object_name -ne $ObjectName -or $auth.package -ne $Package -or $auth.destination -ne $Destination){ Fail "AUTHORIZATION_TARGET_MISMATCH" }
if($auth.authorized_mutation_count -ne $AuthorizedMutationCount){ Fail "AUTHORIZATION_MUTATION_COUNT_MISMATCH" }
if($auth.live_sap_write_authorized -ne $true){ Fail "LIVE_SAP_WRITE_AUTHORIZED_NOT_TRUE" }
if($auth.single_use -ne $true){ Fail "AUTHORIZATION_NOT_SINGLE_USE" }

New-Item -ItemType Directory -Path $StateRoot -Force | Out-Null

Protect-ReceiptWrite "00_LIVE_AUTHORIZATION_BINDING_R1.json" ([ordered]@{
    mission_id=$Mission
    authorization_artifact=$AuthArtifact
    live_execution_script_sha256=$selfHash
    authorization_consumption_mode="SINGLE_USE_MARKER_ON_TERMINAL_SUCCESS"
    sap_write_authorized=$true
    authorized_mutation_count=$AuthorizedMutationCount
    generated_at=(Get-Date).ToUniversalTime().ToString("o")
})

$manifestPath = Join-Path $PreparedRoot $ExpectedPreparedFiles.package_manifest
if(-not(Test-Path -LiteralPath $manifestPath -PathType Leaf)){ Fail "PREWRITE_PACKAGE_MANIFEST_MISSING" }
$manifest = Read-JsonFile $manifestPath
$manifestFailures = @()
foreach($entry in @($manifest.files)){
    $path = Join-Path $PreparedRoot ([string]$entry.file)
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){ $manifestFailures += "MISSING:$($entry.file)"; continue }
    $actual = Get-FileSha256 $path
    if($actual -ne [string]$entry.sha256){ $manifestFailures += "HASH:$($entry.file)" }
}
if($manifestFailures.Count -ne 0){ Fail ("PREWRITE_PACKAGE_MANIFEST_FAILURES:" + ($manifestFailures -join ",")) }

$objectFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.object_freeze)
$providerFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.provider_freeze)
$capabilityFreeze = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.capability_freeze)
$mutationBudget = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.mutation_budget)
$transactionEnvelope = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.transaction_envelope)
$expectedOutcome = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.expected_outcome)
$compensationBoundary = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.compensation_boundary)
$liveContract = Read-JsonFile (Join-Path $PreparedRoot $ExpectedPreparedFiles.live_contract)

if($objectFreeze.object_name -ne $ObjectName -or $objectFreeze.package -ne $Package -or $objectFreeze.destination -ne $Destination){ Fail "OBJECT_FREEZE_TARGET_MISMATCH" }
if($providerFreeze.provider -ne "ADT" -or $providerFreeze.destination -ne $Destination){ Fail "PROVIDER_FREEZE_MISMATCH" }
foreach($capability in @($MutationCapabilities + $ValidationCapabilities)){
    if(@($capabilityFreeze.authorized_capabilities) -notcontains $capability){ Fail "CAPABILITY_FREEZE_MISSING:$capability" }
}
if([int]$mutationBudget.authorized_mutation_count -ne $AuthorizedMutationCount){ Fail "MUTATION_BUDGET_MISMATCH" }
if($transactionEnvelope.object_name -ne $ObjectName -or $transactionEnvelope.package -ne $Package){ Fail "TRANSACTION_ENVELOPE_TARGET_MISMATCH" }
if($expectedOutcome.expected_object_name -ne $ObjectName -or $expectedOutcome.expected_package -ne $Package){ Fail "EXPECTED_OUTCOME_TARGET_MISMATCH" }
if($compensationBoundary.compensation_authority_present -ne $CompensationAuthorityPresent){ Fail "COMPENSATION_AUTHORITY_MISMATCH" }
if($liveContract.live_sap_write_authorized -ne $false){ Fail "PREWRITE_CONTRACT_MUST_REMAIN_UNAUTHORIZED" }

$authContextPath = Join-Path $Base "MCR_R2E_P8_C1A_ADT_AUTH_BINDING_PROBE_R1\ADT_AUTH_CONTEXT_R1.json"
$adtContractPath = Join-Path $Base "MCR_R2E_P8_C2B_FULLSTACK_LIVE_CONTINUATION_R1_HF01\POINT_OF_USE_CONTRACTS\ADT\normalized_contract.json"
Assert-Hash $authContextPath $ExpectedAuthContextHash "ADT_AUTH_CONTEXT"
$adtContract = @(Read-JsonFile $adtContractPath)
$contractHash = Get-TextSha256 (Get-CanonicalJson $adtContract)
if($contractHash -ne $ExpectedAdtContractHash){ Fail "ADT_CONTRACT_HASH_MISMATCH actual=$contractHash expected=$ExpectedAdtContractHash" }

$authContext = Read-JsonFile $authContextPath
if(-not $authContext.protected_token_b64){ Fail "PROTECTED_TOKEN_MISSING" }
$protectedBytes = [Convert]::FromBase64String([string]$authContext.protected_token_b64)
$tokenBytes = [Security.Cryptography.ProtectedData]::Unprotect($protectedBytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
$bearerToken = [Text.Encoding]::UTF8.GetString($tokenBytes)
if([string]::IsNullOrWhiteSpace($bearerToken)){ Fail "TOKEN_UNPROTECT_EMPTY" }
$endpoint = [string]($authContext.mcp_endpoint ?? $authContext.endpoint ?? $authContext.server_url)
if([string]::IsNullOrWhiteSpace($endpoint)){ Fail "MCP_ENDPOINT_MISSING" }

function Invoke-McpHttp {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [Parameter(Mandatory=$true)]$Payload
    )
    $headers = @{ Authorization = "Bearer $bearerToken"; Accept = "application/json, text/event-stream" }
    $json = $Payload | ConvertTo-Json -Depth 100 -Compress
    $response = Invoke-WebRequest -Uri $Uri -Method Post -Headers $headers -ContentType "application/json" -Body $json -UseBasicParsing
    $contentType = [string]$response.Headers["Content-Type"]
    if($contentType -like "*text/event-stream*"){
        $dataLines = @()
        foreach($line in (($response.Content -split "`r?`n"))){
            if($line.StartsWith("data:")){
                $value = $line.Substring(5).Trim()
                if($value -and $value -ne "[DONE]"){ $dataLines += $value }
            }
        }
        if($dataLines.Count -eq 0){ Fail-AfterPartialState "SSE_RESPONSE_WITHOUT_DATA" }
        return ($dataLines[-1] | ConvertFrom-Json -Depth 100)
    }
    return ($response.Content | ConvertFrom-Json -Depth 100)
}

function Invoke-McpRequest {
    param(
        [Parameter(Mandatory=$true)][string]$Method,
        [Parameter(Mandatory=$true)]$Params
    )
    $requestId = Get-TextSha256 ("$Mission|$Method|" + (Get-Date).ToUniversalTime().Ticks)
    Invoke-McpHttp -Uri $endpoint -Payload ([ordered]@{
        jsonrpc="2.0"
        id=$requestId
        method=$Method
        params=$Params
    })
}

function Invoke-McpToolBounded {
    param(
        [Parameter(Mandatory=$true)][string]$ToolName,
        [Parameter(Mandatory=$true)]$Arguments,
        [switch]$Mutation
    )
    if($Mutation){
        $script:MutationCalls += 1
        if($script:MutationCalls -gt $AuthorizedMutationCount){ Fail-AfterPartialState "MUTATION_BUDGET_EXCEEDED" }
    }
    $receiptName = "{0:D2}_{1}_REQUEST_R1.json" -f ($script:BusinessCalls + 1), ($ToolName -replace "[^A-Za-z0-9]+","_")
    Protect-ReceiptWrite $receiptName ([ordered]@{
        tool=$ToolName
        arguments=$Arguments
        mutation=[bool]$Mutation
        timestamp=(Get-Date).ToUniversalTime().ToString("o")
    })
    $script:BusinessCalls += 1
    $result = Invoke-McpRequest -Method "tools/call" -Params ([ordered]@{ name=$ToolName; arguments=$Arguments })
    Protect-ReceiptWrite ("{0:D2}_{1}_RESPONSE_R1.json" -f $script:BusinessCalls, ($ToolName -replace "[^A-Za-z0-9]+","_")) $result
    return $result
}

$initialize = Invoke-McpRequest -Method "initialize" -Params ([ordered]@{
    protocolVersion="2024-11-05"
    capabilities=[ordered]@{}
    clientInfo=[ordered]@{ name=$Mission; version="1.9B" }
})
Protect-ReceiptWrite "01_INITIALIZE_RECEIPT_R1.json" $initialize

$tools = Invoke-McpRequest -Method "tools/list" -Params ([ordered]@{})
Protect-ReceiptWrite "02_TOOLS_LIST_RECEIPT_R1.json" $tools
$toolNames = @($tools.result.tools | ForEach-Object { [string]$_.name })
foreach($required in @("abap_transport-get","abap_creation-run_validation") + $MutationCapabilities + $ValidationCapabilities){
    if($toolNames -notcontains $required){ Fail "LIVE_TOOLS_LIST_MISSING:$required" }
}

$script:MutationCalls = 0
$script:BusinessCalls = 0

$transport = Invoke-McpToolBounded -ToolName "abap_transport-get" -Arguments ([ordered]@{ destination=$Destination })
$validation = Invoke-McpToolBounded -ToolName "abap_creation-run_validation" -Arguments ([ordered]@{ destination=$Destination; objectType=$ObjectType; objectContent=($objectFreeze.object_content); transportRequestNumber="" })

$create = Invoke-McpToolBounded -ToolName "abap_creation-create_object" -Mutation -Arguments ([ordered]@{
    destination=$Destination
    objectType=$ObjectType
    objectContent=($objectFreeze.object_content)
    transportRequestNumber=""
})
$createdFilePath = [string]($create.result.filePath ?? $create.result.content.filePath ?? $create.filePath)
if([string]::IsNullOrWhiteSpace($createdFilePath)){ Fail-AfterPartialState "CREATE_OBJECT_FILEPATH_MISSING" }

$activate = Invoke-McpToolBounded -ToolName "abap_activate_objects" -Mutation -Arguments ([ordered]@{
    uris=@($createdFilePath)
})

$atcRun = Invoke-McpToolBounded -ToolName "abap_atc_run" -Arguments ([ordered]@{
    destination=$Destination
    objects=@([ordered]@{ name=$ObjectName; type=$AtcType })
})
$worklistId = [string]($atcRun.result.worklistId ?? $atcRun.result.content.worklistId ?? $atcRun.worklistId)
if([string]::IsNullOrWhiteSpace($worklistId)){ Fail-AfterPartialState "ATC_WORKLIST_ID_MISSING" }
$atcResult = Invoke-McpToolBounded -ToolName "abap_atc_get_result" -Arguments ([ordered]@{
    destination=$Destination
    worklistId=$worklistId
})

$finalReceipt = [ordered]@{
    mission_id=$Mission
    final_state="LIVE_MUTATION_AND_OUTCOME_OBSERVED"
    object_name=$ObjectName
    package=$Package
    destination=$Destination
    created_file_path=$createdFilePath
    authorized_mutation_count=$AuthorizedMutationCount
    observed_mutation_count=$script:MutationCalls
    business_tool_calls=$script:BusinessCalls
    retries_used=0
    compensation_authority_present=$CompensationAuthorityPresent
    transport_receipt_present=($null -ne $transport)
    validation_receipt_present=($null -ne $validation)
    activation_receipt_present=($null -ne $activate)
    atc_worklist_id=$worklistId
    atc_result_present=($null -ne $atcResult)
    completed_at=(Get-Date).ToUniversalTime().ToString("o")
}
Protect-ReceiptWrite "99_LIVE_FINAL_RECEIPT_R1.json" $finalReceipt
Protect-ReceiptWrite "AUTHORIZATION_CONSUMED_R1.json" ([ordered]@{
    authorization_artifact=$AuthArtifact
    authorization_script_hash=$selfHash
    consumed_at=(Get-Date).ToUniversalTime().ToString("o")
    deletion_performed=$false
    reason="NON_DESTRUCTIVE_SINGLE_USE_CONSUMPTION_MARKER"
})

Write-Output ($finalReceipt | ConvertTo-Json -Depth 100)
# SIG # Begin signature block
# MIIHMAYJKoZIhvcNAQcCoIIHITCCBx0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCRyz7qosBGUbJK
# EgTOiHsWtbAsCt+BJRwOntLk75z3L6CCBBwwggQYMIICgKADAgECAhApojSr80YY
# vUx8MLsjXS5aMA0GCSqGSIb3DQEBCwUAMCQxIjAgBgNVBAMMGUFJLVNBUCBMb2Nh
# bCBDb2RlIFNpZ25pbmcwHhcNMjYwODExMTI0NzU5WhcNMjkwODExMTI1NzU5WjAk
# MSIwIAYDVQQDDBlBSS1TQVAgTG9jYWwgQ29kZSBTaWduaW5nMIIBojANBgkqhkiG
# 9w0BAQEFAAOCAY8AMIIBigKCAYEA+0CoHVn5HMQt9b/KkbtixAcz2wk6GnNE9uSq
# rWFq6z3UZhjeZ/q1eS+xGgI+0AB+ywk6UuHE5/WvX63R4PmYMnkAW0iFbruPvRcv
# gp6G9liwLikJxI/Bd4FPH52EbeoEGYeH+GlIlnHqiekB3Q5yKWUCB8gNj7BbAJ0P
# ea6DYWybUTie0IKIn0BwUCdVuB8xIfsR/0IjD1vJxhMAIy5z5uHE+4JPGJD0SUEg
# hcYMYRkWeWKfqNeogFDFbSmR1yoHU2OY8Xzt9Z02mDnzNhSZ/0NAH6JFa1bMTbpB
# KFEziD/oJcjcc0z5FWtNsYRStwKDV0Hh0KGDMHOVZ4BrZ5bcU/R01lBJKdRM6R2G
# y7DX3fTme1g67yddSIK8j54F/jUTKD465KJ/AcYrulD/5Mvn3jT/KMzFEPLXcPHA
# f2427/12IxzrIqXEzezP2AFHWXjVhtNxL0DX6QrciBh9k1Y28WOPH46ImB3u/8x5
# LI1JhyNequhJFZ49jx1ZQL+PZnkBAgMBAAGjRjBEMA4GA1UdDwEB/wQEAwIHgDAT
# BgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQUIeJF14rNAoB40EJq/1K5XBgq
# P+wwDQYJKoZIhvcNAQELBQADggGBAKNJnzA6dFKwVYrOXDyVOR8hEaYbRZtN+AZs
# j3zIpmRT3MSdpb+d+cM4OhPqFFDi8dLczd8crLI38YGWizKlZX2uz4gzEb0RiD2i
# vy7qc7oNM4Yq9zaox4WqDnND0+pOOwXyC05O1X0GIMOFmIjhNHqjKWvj5BSR7Hfn
# /6DLOxo/+h+knMehDuJ1pRMWIXoPsrk2zpEM0pQ+looewfHAUQT/kMSUxYTlJ90H
# 16lsg8xPtoIWkGe0fCmcE46PLY0b/ar3XRB/VKW1y8dYZQH5PneUYJeGXYuY7/jl
# zprNEc42uOEFY2dfIoAp5rW/uHRgJ46KAzA2fYn6dKHGXQOU7KabXztE5mjNRWlQ
# oBTiRrfaS7DjHkhPz/HUUOnqoEniPmq4knlXrjHymcRidTbTIR5A2XYx48y5/NwH
# 7EJhr6NyqvxCS/NNguPFxYOwPDg+atMepeANdgiei10JYGQsSRNKIfkWRlSxUiC8
# wohYQsAfYUPqEayvhb5YkKLdE8QgjzGCAmowggJmAgEBMDgwJDEiMCAGA1UEAwwZ
# QUktU0FQIExvY2FsIENvZGUgU2lnbmluZwIQKaI0q/NGGL1MfDC7I10uWjANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBnPS8OW8xavin2r6amI8ggKaD71vUMCQ25nTgLSRLB
# AjANBgkqhkiG9w0BAQEFAASCAYASu+7i6M+opMhJnqJtA/0o1gfmsEY/ceNZft8i
# ZMdLITBbwQy7ERWxhUqIFZwrHBKqpYHVUEOIK8jyltcIucRQb+PPOROIztwcdCQY
# wTaHdQYM/P9/g9Oyq/UHduXDDizdnCze5JVz19SLleNV5m4+yTZjY6Xy3CU0Z0zz
# fG/TcIXASnYj9bOvk+nuuyEr2k8/6nV5YqrLBxb2nMCFjjbvtv92vEI55UmHUDfT
# VvK62+gLdPA5lw1C1pFbNrFqiTuv+MgXDf0lgLWJgUFJazkg5cPqlPTwLPv+ap+f
# u3ADJd5mUv7BwMbVRi2EgSQQOK2n0ZgRmUhe/uRH6oix1bcy1U0c7uT4IHqGlF/D
# /bDi74Oi/D1ZGnacmbhVPZ8nOsmv693o3G8/55qOk0+iJxEMfpTFy3Ko0YsaCnEz
# Uu70NTr5OM//WvvH/MPwLYg7BDzuMBOV5A/EbiYcsK9+611mFBUjJte9h8VTuG3N
# UgSopRhB5Eba7Dw/K69zRSZF8DA=
# SIG # End signature block
